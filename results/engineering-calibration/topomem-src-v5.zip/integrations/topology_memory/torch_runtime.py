"""Run generated KV rules against real CUDA storage and fixed block attention."""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass, field
from hashlib import sha256
import heapq
from time import perf_counter_ns

from rsi_memory.compiled_memory import CompiledProgram
from rsi_memory.memory_program import ACTION_DOMAIN, FEATURE_UNITS, candidate_features, transfer_duration_ns
from rsi_memory.topology import fingerprint


SUPPORTED_ACTIONS = frozenset((event, action) for event, actions in ACTION_DOMAIN.items() for action in actions)
SUPPORTED_FEATURES = frozenset(name for name in FEATURE_UNITS if not name.startswith("write_route_"))
ARMS = frozenset({"native_lru", "manual_topology", "generated"})


class InfeasiblePlan(RuntimeError):
    """A policy has no safe decision under the fixed capacities or routes."""


@dataclass
class _Block:
    spec: object
    owner: str
    born_ns: int
    copies: dict[str, int] = field(default_factory=dict)
    refs: int = 1
    reads: int = 0
    last_use: int = 0


@dataclass(frozen=True)
class _Move:
    block: _Block
    route: object
    slots: tuple[int, ...]
    mode: str
    rule: int | None


class _Pool:
    def __init__(self, torch, node, device, block_rows, head_dim, *, pin_host):
        size = block_rows * head_dim * 2 * 4
        self.capacity = node.capacity_bytes // size
        self.tensor = torch.empty((self.capacity, block_rows, 2, head_dim), dtype=torch.float32,
                                  device=device, pin_memory=pin_host and node.kind == "host")
        self.free = list(range(self.capacity))
        self.used = set()
        self.peak = 0

    def take(self):
        if not self.free:
            raise InfeasiblePlan("managed pool capacity exhausted")
        slot = heapq.heappop(self.free)
        self.used.add(slot)
        self.peak = max(self.peak, len(self.used))
        return slot

    def release(self, slot):
        self.used.remove(slot)
        heapq.heappush(self.free, slot)


class _Runtime:
    def __init__(self, torch, topology, scenario, packed, program, arm, devices, verify, *, pin_host=True):
        self.torch, self.topology, self.scenario, self.workload = torch, topology, scenario, packed
        self.program, self.arm, self.verify = None if program is None else CompiledProgram(program), arm, verify
        self.local = scenario.rank_node(0)
        self.devices = devices
        self.hosts = sorted(node for node in devices if topology.node(node).kind == "host")
        self.routes = {(src, dst): tuple(route for route in topology.routes(src, dst) if self._supported_route(route))
                       for src in self.devices for dst in self.devices}
        if not self.hosts or not any(self.routes[self.local, host] and self.routes[host, self.local] for host in self.hosts):
            raise ValueError("runtime requires a bidirectional pinned-host backing route")
        self.pools = {node: _Pool(torch, topology.node(node), device, packed.block_rows, packed.head_dim, pin_host=pin_host)
                      for node, device in self.devices.items()}
        self.route_templates = {}
        if self.program is not None:
            empty = dict.fromkeys(devices, 0)
            for (source, target), paths in self.routes.items():
                for route in paths:
                    self.route_templates[route] = candidate_features(
                        topology, scenario, rank=0, layer=0, block=0, size=packed.block_bytes,
                        target=target, source=source, route=route, usage=empty)
        self.blocks, self.sessions = {}, {}
        self.versions, self.previous_attention = {}, {}
        self.local_owners = set()
        self.timeline, self.access_log, self.semantics = [], [], []
        self.link_bytes, self.group_bytes = Counter(), Counter()
        self.misses, self.reads = Counter(), Counter()
        self.transfer_wall_ns = 0
        self.clock, self.ordinal = 0, 0

    def _supported_route(self, route):
        if any(node not in self.devices for node in route.nodes):
            return False
        for link in route.links:
            src_kind, dst_kind = self.topology.node(link.src).kind, self.topology.node(link.dst).kind
            if src_kind == dst_kind == "gpu":
                src, dst = self.devices[link.src], self.devices[link.dst]
                if link.transport != "cuda_peer" or not self.torch.cuda.can_device_access_peer(src.index, dst.index):
                    return False
            elif src_kind == dst_kind or link.transport != "pinned_host":
                return False
        return True

    def _sync(self, nodes):
        for node in sorted(set(nodes)):
            device = self.devices[node]
            if device.type == "cuda":
                self.torch.cuda.synchronize(device)

    def _tensor(self, state, node):
        return self.pools[node].tensor[state.copies[node]]

    def _source_tensor(self, raw):
        return self.torch.frombuffer(bytearray(raw), dtype=self.torch.float32)

    def _payload(self, tensor):
        return tensor.detach().cpu().contiguous().numpy().tobytes()

    def _features(self, state, route):
        source, target = route.nodes[0], route.nodes[-1]
        fields = self.route_templates[route].copy()
        cap = fields["target_capacity_bytes"]
        size = self.workload.block_bytes
        used = len(self.pools[target].used) * size
        fields.update(layer=state.spec.layer, block=state.spec.index, time_ns=self.clock,
                      age_ns=self.clock-state.born_ns, accesses=state.reads, replicas=max(0, len(state.copies)-1),
                      target_has_copy=int(target in state.copies), target_used_bytes=used, target_free_bytes=cap-used,
                      target_utilization=used/cap if cap else 0, source_used_bytes=len(self.pools[source].used)*size,
                      valid_rows=state.spec.valid_rows, block_rows=self.workload.block_rows, logical_refs=state.refs,
                      prior_version_rows=self.versions.get(state.spec.id, (0, 0))[1],
                      page_accesses=self.reads[state.spec.layer, state.spec.index], last_use_step=state.last_use,
                      recency_steps=self.ordinal-state.last_use)
        return fields

    def _choices(self, state, sources, targets, *, allow_local=False):
        candidates = []
        for src in sorted(sources):
            for dst in sorted(targets):
                if (src == dst and not allow_local) or (dst in state.copies and dst != src):
                    continue
                for route in self.routes[src, dst]:
                    if all(self.pools[node].free for node in route.nodes[1:]):
                        candidates.append((route, None if self.program is None else self._features(state, route)))
        return candidates

    def _drop(self, state, node, action, rule=None):
        if state.refs and state.owner == node:
            raise RuntimeError("attempted to release a live authoritative KV block")
        self.pools[node].release(state.copies.pop(node))
        if node == self.local:
            self.local_owners.discard(state.spec.id)
        self.timeline.append({"step": self.ordinal, "action": action, "block": state.spec.id, "node": node, "rule": rule})

    def _relieve(self, event, *, nodes=None, protected=()):
        options = defaultdict(list)
        for block_id, state in self.blocks.items():
            if block_id in protected:
                continue
            for node in sorted(state.copies):
                if (nodes is not None and node not in nodes) or (state.refs and node == state.owner):
                    continue
                action = "evict" if state.refs else "reclaim"
                options[action].append((state, node))
        if not any(options.values()):
            if self.arm == "manual_topology" and (nodes is None or self.local in nodes):
                return self._demote_manual(protected)
            return False
        if self.program is None:
            action = "reclaim" if options["reclaim"] else "evict"
            state, node = min(options[action], key=lambda row: (self._cache_priority(row[0]), row[0].spec.id, row[1]))
            self._drop(state, node, action)
            return True
        choices = []
        for action, objects in options.items():
            candidates = [((state, node), self._features(state, self.routes[node, node][0])) for state, node in objects]
            choice = self.program.choose(event, action, candidates)
            if choice is not None:
                index, (state, node) = choice
                choices.append((index, action, state, node))
        if not choices:
            return False
        rule, action, state, node = min(choices, key=lambda item: item[0])
        self._drop(state, node, action, rule)
        return True

    def _reserve(self, state, route, mode, rule):
        if not route.links:
            return None
        if state.refs <= 0 or route.nodes[0] not in state.copies or route.nodes[-1] in state.copies:
            raise RuntimeError("invalid transfer endpoints or ownership")
        return _Move(state, route, tuple(self.pools[node].take() for node in route.nodes[1:]), mode, rule)

    def _execute(self, moves):
        if not moves:
            return
        started = perf_counter_ns()
        for stage in range(max(len(move.route.links) for move in moves)):
            synced = set()
            for move in moves:
                if stage >= len(move.route.links):
                    continue
                link = move.route.links[stage]
                source_slot = move.block.copies[link.src] if stage == 0 else move.slots[stage-1]
                self.pools[link.dst].tensor[move.slots[stage]].copy_(self.pools[link.src].tensor[source_slot], non_blocking=True)
                synced.update((link.src, link.dst))
                self.link_bytes[link.id] += self.workload.block_bytes
                for group in link.bottlenecks:
                    self.group_bytes[group] += self.workload.block_bytes
            # A relay hop can consume its source only after prior DMA completes.
            self._sync(synced)
        self.transfer_wall_ns += perf_counter_ns() - started
        for move in moves:
            src, dst = move.route.nodes[0], move.route.nodes[-1]
            state = move.block
            state.copies[dst] = move.slots[-1]
            for node, slot in zip(move.route.nodes[1:-1], move.slots[:-1]):
                self.pools[node].release(slot)
            if move.mode in ("place", "migrate", "baseline_place"):
                if state.owner != src:
                    raise RuntimeError("migration lost its authoritative source")
                state.owner = dst
                if move.mode == "migrate":
                    self._drop(state, src, "migrated_source", move.rule)
            self.timeline.append({"step": self.ordinal, "action": move.mode, "block": state.spec.id, "src": src,
                                  "dst": dst, "links": list(move.route.ids), "rule": move.rule})

    def _best_route(self, candidates):
        return min((route for route, _ in candidates), key=lambda route: (
            transfer_duration_ns(self.topology, route, self.workload.block_bytes), route.ids), default=None)

    def _cache_priority(self, state):
        frequency = self.reads[state.spec.layer, state.spec.index] if self.arm == "manual_topology" else 0
        return frequency, state.last_use

    def _best_backing(self, state):
        targets = tuple(node for node in self.pools if node != self.local)
        routes = [route for route, _ in self._choices(state, (self.local,), targets)
                  if self.routes[route.nodes[-1], self.local]]

        def cost(route):
            size = self.workload.block_bytes
            back = self.routes[route.nodes[-1], self.local]
            return transfer_duration_ns(self.topology, route, size) + min(transfer_duration_ns(self.topology, r, size) for r in back)

        return min(routes, key=lambda route: (cost(route), route.ids), default=None)

    def _demote_manual(self, protected):
        states = (self.blocks[pid] for pid in self.local_owners if pid not in protected)
        for state in sorted(states, key=lambda item: (self._cache_priority(item), item.spec.id)):
            route = self._best_backing(state)
            if route is not None:
                self._execute([self._reserve(state, route, "migrate", None)])
                return True
        return False

    def _choose_place(self, state):
        if self.arm == "generated":
            choices = self._choices(state, (self.local,), self.pools, allow_local=True)
            return self.program.choose("allocate", "place", choices)
        if self.arm == "native_lru":
            route = self._best_route(self._choices(state, (self.local,), self.hosts))
        else:
            owner_limit = max(0, self.pools[self.local].capacity - self.workload.top_k - 2)
            hot = state.spec.valid_rows < self.workload.block_rows or self.reads[state.spec.layer, state.spec.index] >= 2
            if hot and len(self.local_owners) < owner_limit:
                route = self.routes[self.local, self.local][0]
            else:
                route = self._best_backing(state)
        return None if route is None else (None, route)

    def _place_batch(self, states):
        moves = []
        protected = {state.spec.id for state in states}
        for state in states:
            while True:
                choice = self._choose_place(state)
                if choice is not None:
                    rule, route = choice
                    break
                if moves:
                    self._execute(moves)
                    moves = []
                elif not self._relieve("allocate", protected=protected):
                    raise InfeasiblePlan("no safe owner placement")
            self.timeline.append({"step": self.ordinal, "action": "place_owner", "block": state.spec.id,
                                  "node": route.nodes[-1], "rule": rule})
            mode = "place" if self.program is not None else "baseline_place"
            move = self._reserve(state, route, mode, rule)
            if move is None:
                self.local_owners.add(state.spec.id)
            else:
                moves.append(move)
        self._execute(moves)
        if self.program is not None:
            for state in states:
                temporary = state.owner != self.local and self.local in state.copies
                retained = self._optional("allocate", state, retain_source=temporary)
                if temporary and not retained:
                    self._drop(state, self.local, "producer_release")

    def _make_room(self, protected):
        while True:
            if self.pools[self.local].free:
                return
            if not self._relieve("allocate", nodes={self.local}, protected=protected):
                raise InfeasiblePlan("no safe capacity for the compute producer")

    def _movement(self, event, state, *, demand=False, retain_source=False):
        choices = []
        for action in ("replicate", "migrate", "prefetch"):
            sources = (state.owner,) if action == "migrate" else state.copies
            targets = (self.local,) if demand or action == "prefetch" else self.pools
            candidates = self._choices(state, sources, targets)
            if retain_source and action == "replicate":
                route = self.routes[self.local, self.local][0]
                candidates.append((route, self._features(state, route)))
            selected = self.program.choose(event, action, candidates)
            if selected is not None:
                rule, route = selected
                choices.append((rule, action, route))
        return min(choices, key=lambda row: row[0], default=None)

    def _optional(self, event, state, *, retain_source=False):
        choice = self._movement(event, state, retain_source=retain_source)
        if choice is not None:
            rule, mode, route = choice
            if not route.links:
                self.timeline.append({"step": self.ordinal, "action": "retain_producer_replica", "block": state.spec.id,
                                      "node": self.local, "rule": rule})
                return True
            self._execute([self._reserve(state, route, mode, rule)])
        return False

    def _fetch(self, selected):
        protected = {state.spec.id for state in selected}
        moves = []
        for state in selected:
            if self.local in state.copies:
                continue
            self.misses[state.spec.layer, state.spec.index] += 1
            while True:
                if self.program is None:
                    route = self._best_route(self._choices(state, state.copies, (self.local,)))
                    choice = None if route is None else (None, "demand_replica", route)
                else:
                    choice = self._movement("access", state, demand=True)
                if choice is not None:
                    rule, mode, route = choice
                    moves.append(self._reserve(state, route, mode, rule))
                    break
                if self._relieve("access", protected=protected):
                    continue
                if not moves:
                    raise InfeasiblePlan("no safe transfer to the attention rank")
                self._execute(moves)
                moves = []
        self._execute(moves)

    def _release_ref(self, state):
        state.refs -= 1
        if state.refs < 0:
            raise RuntimeError("logical KV reference underflow")
        if state.refs == 0:
            if self.program is None:
                for node in list(state.copies):
                    self._drop(state, node, "reclaim")
            else:
                while self._relieve("release"):
                    pass

    def _allocate(self, spec):
        if spec.id in self.blocks:
            raise RuntimeError("logical block was produced more than once")
        state = _Block(spec, self.local, self.clock, {self.local: self.pools[self.local].take()}, last_use=self.ordinal)
        self.blocks[spec.id] = state
        return state

    def _write_tail(self, session, mutation):
        spec = self.workload.blocks[mutation.block]
        old = self.blocks[mutation.replaces]
        self._fetch([old])
        self._make_room({old.spec.id})
        state = self._allocate(spec)
        dest = self._tensor(state, self.local)
        preserved = mutation.preserved_rows
        suffix = self._source_tensor(spec.payload[preserved*self.workload.row_bytes:]).view(dest[preserved:].shape)
        dest[preserved:].copy_(suffix, non_blocking=True)
        source = self._tensor(old, self.local)
        if source.data_ptr() == dest.data_ptr():
            raise RuntimeError("versioned KV writes require a disjoint destination")
        dest[:preserved].copy_(source[:preserved])
        self._sync((self.local,))
        if self.verify and sha256(self._payload(dest)).hexdigest() != spec.digest:
            raise RuntimeError("producer or physical COW bytes disagree with immutable KV")
        self.versions[spec.id] = (old.spec.id, preserved)
        if old.refs > 1:
            if self.verify and sha256(self._payload(self._tensor(old, self.local))).hexdigest() != old.spec.digest:
                raise RuntimeError("COW changed another branch's physical bytes")
            self.semantics.append({"step": self.ordinal, "action": "copy_on_write", "old": old.spec.id,
                                   "new": spec.id, "session": session, "parent_owners": old.refs,
                                   "preserved_rows": preserved, "old_sha256": old.spec.digest, "new_sha256": spec.digest})
        self._release_ref(old)
        self._place_batch([state])

    def _publish_batch(self, states):
        sources = []
        for state in states:
            dest = self._tensor(state, self.local)
            sources.append(self._source_tensor(state.spec.payload).view(dest.shape))
            dest.copy_(sources[-1], non_blocking=True)
        self._sync((self.local,))
        if self.verify and any(sha256(self._payload(self._tensor(state, self.local))).hexdigest() != state.spec.digest
                               for state in states):
            raise RuntimeError("batch producer bytes disagree with immutable KV")
        self._place_batch(states)

    def _writes(self, step):
        pages = self.sessions[step.session]
        batch = []
        for mutation in step.writes:
            if batch and (mutation.replaces is not None or not self.pools[self.local].free or len(batch) >= 32):
                self._publish_batch(batch)
                batch = []
            if mutation.replaces is not None:
                pages.remove(mutation.replaces)
                self._write_tail(step.session, mutation)
            else:
                self._make_room(())
                batch.append(self._allocate(self.workload.blocks[mutation.block]))
            pages.add(mutation.block)
        if batch:
            self._publish_batch(batch)
        if self.program is not None:
            for pid in step.hints:
                self._optional("hint", self.blocks[pid])

    def _retained_rows(self, previous, current):
        retained = 0
        for old_id, new_id in zip(previous, current):
            same_rows = self.blocks[old_id].spec.valid_rows
            while old_id != new_id and new_id in self.versions:
                new_id, copied = self.versions[new_id]
                same_rows = min(same_rows, copied)
            if old_id != new_id:
                break
            retained += same_rows
        return retained

    def _attention(self, session, request):
        torch = self.torch
        device = self.devices[self.local]
        chosen = [self.blocks[pid] for pid in request.selected]
        started = perf_counter_ns()
        self._fetch(chosen)
        for state in chosen:
            state.reads += 1
            state.last_use = self.ordinal
            self.reads[state.spec.layer, state.spec.index] += 1
        slots = torch.tensor([state.copies[self.local] for state in chosen], device=device, dtype=torch.int64)
        payload = self.pools[self.local].tensor.index_select(0, slots)
        key_values = payload.view(-1, 2, self.workload.head_dim)
        query = self._source_tensor(request.query).to(device)
        valid = torch.tensor([state.spec.valid_rows for state in chosen], device=device)
        mask = (torch.arange(self.workload.block_rows, device=device)[None, :] < valid[:, None]).flatten()
        scores = key_values[:, 0].mv(query).mul_(self.workload.head_dim ** -0.5).masked_fill_(~mask, -torch.inf)
        output = torch.softmax(scores, dim=0) @ key_values[:, 1]
        self._sync((self.local,))
        access_ns = perf_counter_ns() - started
        key = session, request.layer
        previous = self.previous_attention.get(key, ())
        old_rows = sum(self.blocks[pid].spec.valid_rows for pid in previous)
        retained_rows = self._retained_rows(previous, request.blocks)
        if previous and retained_rows != old_rows:
            raise RuntimeError("session update lost rows from its retained prefix")
        self.previous_attention[key] = request.blocks
        observation = {"step": self.ordinal, "session": session, "layer": request.layer,
                       "selected": list(request.selected), "access_ns": access_ns, "retained_rows": retained_rows,
                       "context_rows": sum(self.blocks[pid].spec.valid_rows for pid in request.blocks)}
        if self.verify:
            raw = self._payload(payload)
            if raw != b"".join(state.spec.payload for state in chosen):
                raise RuntimeError("CUDA attention consumed incorrect ordered selected KV bytes")
            dense = self._source_tensor(b"".join(self.workload.blocks[pid].payload for pid in request.blocks))
            dense = dense.view(-1, 2, self.workload.head_dim)
            selected = set(request.selected)
            dense_mask = torch.tensor([pid in selected and offset < self.workload.blocks[pid].valid_rows
                                       for pid in request.blocks for offset in range(self.workload.block_rows)])
            full = (dense[:, 0].mv(self._source_tensor(request.query)) * self.workload.head_dim ** -0.5)
            expected = torch.softmax(full.masked_fill(~dense_mask, -torch.inf), dim=0) @ dense[:, 1]
            actual = output.cpu()
            torch.testing.assert_close(actual, expected, rtol=1e-4, atol=1e-5)
            observation.update(selected_sha256=sha256(raw).hexdigest(), output_sha256=sha256(self._payload(actual)).hexdigest(),
                               max_abs_error=float((actual-expected).abs().max().item()))
        self.access_log.append(observation)
        if self.program is not None:
            for state in chosen:
                self._optional("access", state)

    def _check_state(self):
        ownership = Counter(pid for blocks in self.sessions.values() for pid in blocks)
        occupied = defaultdict(set)
        for pid, state in self.blocks.items():
            if state.refs != ownership[pid] or (state.refs and state.owner not in state.copies):
                raise RuntimeError("physical owner disagrees with the external logical references")
            for node, slot in state.copies.items():
                if slot in occupied[node]:
                    raise RuntimeError("independent KV versions alias a physical slot")
                occupied[node].add(slot)
        if any(occupied[node] != pool.used for node, pool in self.pools.items()):
            raise RuntimeError("runtime has unaccounted physical storage")

    def run(self):
        self._sync(self.devices)
        started = perf_counter_ns()
        for self.ordinal, step in enumerate(self.workload.steps):
            self.clock = step.at_ns
            if step.op == "open":
                self.sessions[step.session] = set()
            elif step.op == "fork":
                parent = self.sessions[step.parent]
                self.sessions[step.session] = parent.copy()
                for pid in parent:
                    self.blocks[pid].refs += 1
                self.semantics.append({"step": self.ordinal, "action": "fork", "parent": step.parent,
                                       "child": step.session, "shared_blocks": sorted(parent),
                                       "owners_after": {pid: self.blocks[pid].refs for pid in sorted(parent)}})
            elif step.op == "close":
                for pid in sorted(self.sessions.pop(step.session)):
                    self._release_ref(self.blocks[pid])
                if self.program is not None:
                    while self._relieve("idle"):
                        pass
            else:
                if step.call_id is not None:
                    self.semantics.append({"step": self.ordinal, "session": step.session,
                                           "action": step.segment_role, "call_id": step.call_id})
                self._writes(step)
                for request in step.attention:
                    if set(request.blocks) != self.sessions[step.session]:
                        # Compare just this layer when a session owns multiple layers.
                        layer_blocks = {pid for pid in self.sessions[step.session] if self.blocks[pid].spec.layer == request.layer}
                        if set(request.blocks) != layer_blocks:
                            raise RuntimeError("attention does not bind its exact live KV versions")
                    self._attention(step.session, request)
            if self.verify:
                self._check_state()
        self._sync(self.devices)
        elapsed_ns = perf_counter_ns() - started
        if self.sessions or any(state.refs for state in self.blocks.values()):
            raise RuntimeError("runtime ended with live KV references")
        if self.workload.kind == "rollout_cow" and len({row["session"] for row in self.semantics
                                                       if row["action"] == "copy_on_write"}) < 2:
            raise RuntimeError("both rollout branches must execute physical copy-on-write")
        residual = {node: len(pool.used)*self.workload.block_bytes for node, pool in self.pools.items()}
        for state in self.blocks.values():
            for node in list(state.copies):
                self._drop(state, node, "teardown")
        if any(pool.used for pool in self.pools.values()):
            raise RuntimeError("runtime ended with outstanding reservations")
        return {"status": "verified" if self.verify else "timed", "elapsed_ns": elapsed_ns,
                "transfer_wall_ns": self.transfer_wall_ns, "accesses": self.access_log, "actions": self.timeline,
                "semantics": self.semantics, "link_bytes": dict(self.link_bytes), "shared_bottleneck_bytes": dict(self.group_bytes),
                "managed_peak_bytes_by_node": {node: pool.peak*self.workload.block_bytes for node, pool in self.pools.items()},
                "managed_reserved_bytes_by_node": {node: pool.capacity*self.workload.block_bytes for node, pool in self.pools.items()},
                "residual_before_teardown_bytes_by_node": residual, "live_references_at_end": 0,
                "page_activity": [{"layer": layer, "page": index, "attention_reads": self.reads[layer, index],
                                   "fetch_misses": self.misses[layer, index]}
                                  for layer, index in sorted(self.reads.keys() | self.misses.keys())],
                "total_fetch_misses": self.misses.total()}


def run_trial(topology, scenario, packed, program=None, *, arm="generated", device_map, verify=True):
    """Use fresh capacity-bounded pools; a diagnostic trial is distinct from timing."""
    import torch

    if arm not in ARMS or (arm == "generated") != (program is not None):
        raise ValueError("arm and generated MemoryProgram disagree")
    if scenario.to_dict() != packed.bind_scenario(scenario.target_sha256, scenario.rank_node(0)).to_dict():
        raise ValueError("packed KV workload or attention differs from its frozen scenario")
    scenario.validate_topology(topology)
    if program is not None:
        program.validate_actions(SUPPORTED_ACTIONS)
        program.validate_features(SUPPORTED_FEATURES)
    expected = {node.id for node in topology.nodes if node.kind == "gpu"}
    if (type(device_map) is not dict or device_map.keys() != expected or len(expected) < 2
            or any(type(index) is not int or not 0 <= index < torch.cuda.device_count() for index in device_map.values())
            or len(set(device_map.values())) != len(device_map)):
        raise ValueError("runtime requires distinct visible CUDA devices bound to all declared GPU nodes")
    before = {node: torch.cuda.memory_allocated(index) for node, index in device_map.items()}
    for index in device_map.values():
        torch.cuda.reset_peak_memory_stats(index)
    devices = {node: torch.device("cuda", index) for node, index in device_map.items()}
    devices.update({node.id: torch.device("cpu") for node in topology.nodes if node.kind == "host"})
    with torch.inference_mode():
        runtime = _Runtime(torch, topology, scenario, packed, program, arm, devices, verify)
        result = runtime.run()
    peaks = {node: torch.cuda.max_memory_allocated(index)-before[node] for node, index in device_map.items()}
    selected = [{key: access[key] for key in ("step", "layer", "selected", "selected_sha256", "output_sha256")}
                for access in result["accesses"]] if verify else None
    return {"schema": 1, "scope": "cuda_text_derived_fixed_block_sparse", "arm": arm,
            "schedule_execution": "ordered_logical_clock_without_wall_waits", "fixture_kind": packed.kind,
            "topology_sha256": topology.fingerprint(), "scenario_sha256": scenario.fingerprint(),
            "workload_sha256": packed.workload_sha256, "schedule_sha256": packed.schedule_sha256,
            "program_sha256": None if program is None else program.fingerprint(),
            "cuda_peak_allocated_bytes_delta_by_node": peaks,
            "selected_and_output_sha256": None if selected is None else fingerprint(selected), **result}
