"""Render an offline evidence viewer from topology RSI runs and GPU receipts."""

from __future__ import annotations

import argparse
from collections import Counter
from contextlib import closing
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3

from .topology_report_assets import PAGE


SCENARIOS = {
    "agent_tools": "Agent · 工具往返",
    "long_document_qa": "LongBench 风格 · 长文问答",
    "chatbot_growth": "Chatbot · 多轮增长",
    "rollout_cow": "Rollout · 分支与写时复制",
}
SHA = re.compile(r"[0-9a-f]{64}")


def _read(path):
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object in {path.name}")
    return value


def _fingerprint(value):
    data = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)
    return hashlib.sha256(data.encode()).hexdigest()


def _take(value, fields):
    return {key: value[key] for key in fields.split() if key in value} if isinstance(value, dict) else {}


def _number(value):
    return value if type(value) in (int, float) and math.isfinite(value) else None


def _metrics(value, depth=0):
    """Project recorded counters and identifiers without embedding prompts or raw evaluator text."""
    if not isinstance(value, dict) or depth > 3:
        return {}
    projected = {}
    for key, item in value.items():
        if type(item) is bool or _number(item) is not None:
            projected[key] = item
        elif isinstance(item, dict):
            nested = _metrics(item, depth + 1)
            if nested:
                projected[key] = nested
        elif key == "receipts" and isinstance(item, list):
            projected[key] = [value for value in item if isinstance(value, str) and len(value) <= 180]
        elif key == "case_metrics" and isinstance(item, list):
            projected[key] = [_metrics(value, depth + 1) for value in item]
        elif isinstance(item, str) and len(item) <= 180 and (
            key in {"scope", "status", "score_unit", "receipt", "receipt_id", "job_id", "arm", "fixture_kind",
                    "case_name", "error_type", "block_id", "backend", "evidence", "name"} or key.endswith("_sha256")
        ):
            projected[key] = item
    return projected


def _call(key, value):
    return {"id": key, **_take(value, "status seconds failure"),
            **_take(value.get("input", {}), "harness_sha256"),
            **_take(value.get("input", {}).get("payload", {}), "model max_tokens reasoning_effort"),
            "usage": _metrics(value.get("result", {}).get("usage", {})),
            **_take(value.get("result", {}), "finish_reason")}


def _evaluation(key, value):
    return {"id": key, **_take(value, "status seconds failure"), **_take(value.get("input", {}), "split"),
            **_take(value.get("result", {}), "score feasible"),
            "metrics": _metrics(value.get("result", {}).get("metrics", {}))}


def _pair(key, value):
    return {"id": key, **_take(value, "status seconds failure"),
            **_take(value.get("input", {}), "split block_ids"),
            "arms": {label: {**_take(arm, "feasible score"), "metrics": _metrics(arm.get("metrics")),
                             "samples": [_metrics(sample) for sample in arm.get("samples", [])]}
                     for label, arm in value.get("result", {}).items()}}


def _decision(value):
    return _take(value, "operator parents evidence rule mode") if isinstance(value, dict) else None


def _trial(value):
    if not isinstance(value, dict):
        return None
    program = value.get("program")
    return {**_take(value, "id status score failure program program_sha256 harness_sha256"),
            "decision": _decision(value.get("decision")), "feedback": _metrics(value.get("feedback")),
            "program_hash_matches": _fingerprint(program) == value.get("program_sha256") if program is not None else None}


def _finalist(value):
    if not isinstance(value, dict):
        return None
    return {**_take(value, "score status"), "trial": _trial(value.get("trial"))}


def _round(value):
    result = _take(value, "round active_before active_after proposed_child_sha256 decision reason source_diff "
                          "matched_context_sha256 child_fallback_to_parent previous_admission_reuse "
                          "paired_validation fixed_meta_failure fixed_meta_discarded_sha256")
    for name in ("parent", "child", "fixed"):
        result[name] = [_trial(trial) for trial in value.get(name, [])]
    for name in ("parent_validation", "child_validation"):
        result[name] = _finalist(value.get(name))
    result["fixed_validation"] = [_finalist(item) for item in value.get("fixed_validation", [])]
    result["adaptive_meta_decision"] = _decision(value.get("adaptive_meta_decision"))
    result["fixed_meta_decision"] = _decision(value.get("fixed_meta_decision"))
    result["controlled_behavior"] = {
        name: {"ast_changed": data.get("ast_changed"), "decisions": [
            {**_take(row, "slot changed_fields"), "before": _decision(row.get("before")),
             "after": _decision(row.get("after"))} for row in data.get("decisions", [])]}
        for name, data in (value.get("controlled_behavior") or {}).items()}
    return result


def _records(directory):
    journal = directory / "journal.sqlite"
    if journal.is_file():
        with closing(sqlite3.connect(journal.resolve().as_uri() + "?mode=ro", uri=True, timeout=3)) as connection:
            connection.execute("PRAGMA query_only=ON")
            rows = connection.execute("SELECT key, data FROM records ORDER BY key").fetchall()
        return {key: json.loads(data) for key, data in rows}, "journal.sqlite"
    report = directory / "report.json"
    exported = _read(report) if report.is_file() else {}
    if not exported:
        manifest = directory / "manifest.json"
        if not manifest.is_file():
            raise ValueError(f"no topology RSI journal, report or manifest in {directory.name}")
        exported = {"manifest": _read(manifest)}
        frozen = directory / "frozen.json"
        if frozen.is_file():
            exported["frozen"] = _read(frozen)
        exported["rounds"] = [_read(path) for path in sorted((directory / "rounds").glob("r*.json"))]
    return {"manifest": exported.get("manifest"), "frozen": exported.get("frozen"),
            "test_comparisons": exported.get("test_comparisons"), "status": exported.get("status"),
            **{f"round/r{row['round']:04d}": row for row in exported.get("rounds", [])},
            **exported.get("calls", {}), **exported.get("evaluations", {}),
            **exported.get("paired_evaluations", {})}, "report.json" if report.is_file() else "JSON checkpoints"


def _source(directory, sha):
    if not isinstance(sha, str) or not SHA.fullmatch(sha):
        return None
    path = directory / "harnesses" / f"{sha}.py"
    if not path.is_file() or not path.resolve().is_relative_to(directory.resolve()):
        return {"status": "missing"}
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != sha:
        return {"status": "hash_mismatch"}
    return {"status": "verified", "source": raw.decode("utf-8")}


def read_run(directory, label=None):
    records, origin = _records(directory)
    manifest = records.get("manifest")
    if not isinstance(manifest, dict) or not isinstance(manifest.get("config"), dict):
        raise ValueError(f"missing topology RSI manifest in {directory.name}")
    rows = [value for key, value in records.items() if key.startswith("round/")]
    rows.sort(key=lambda value: value["round"])
    calls = [_call(key, value) for key, value in records.items() if key.startswith("api/")]
    evaluations = [_evaluation(key, value) for key, value in records.items() if key.startswith("eval/")]
    pairs = [_pair(key, value) for key, value in records.items() if key.startswith("pair/")]
    frozen = records.get("frozen")
    frozen_view = None
    if isinstance(frozen, dict):
        frozen_view = {**_take(frozen, "rounds partial active_harness_sha256 native_validation_score "
                                      "manifest_sha256 rounds_sha256 admitted_harness_sha256s reused_harness_sha256s"),
                       "hashes_match": (frozen.get("manifest_sha256") == _fingerprint(manifest)
                                        and frozen.get("rounds_sha256") == _fingerprint(rows)),
                       "adaptive": _finalist(frozen.get("adaptive")), "fixed": _finalist(frozen.get("fixed")),
                       "adaptive_archive_best": _finalist(frozen.get("adaptive_archive_best"))}
    hashes = {manifest.get("seed_sha256")}
    for row in rows:
        hashes.update(row.get(key) for key in ("active_before", "active_after", "proposed_child_sha256"))
    contract = manifest.get("contract", {})
    return {"label": label or directory.name, "origin": origin, "recorded_status": records.get("status"),
            "manifest_sha256": _fingerprint(manifest), "contract": _metrics(contract),
            "manifest": _take(manifest, "config paired_gate supported_actions started_unix seed_sha256 source_sha256 "
                                        "candidate_slots_per_arm_per_round provider_calls_per_arm_per_round_cap"),
            "rounds": [_round(row) for row in rows], "frozen": frozen_view,
            "test_comparisons": records.get("test_comparisons"), "calls": calls,
            "evaluations": evaluations, "pairs": pairs,
            "sources": {sha: _source(directory, sha) for sha in sorted(sha for sha in hashes if isinstance(sha, str))}}


def _case(value, max_actions):
    diagnostic = value.get("diagnostic", {})
    actions = diagnostic.get("actions", [])
    return {**_take(value, "name case_sha256 median_elapsed_ns"),
            "diagnostic": {**_take(diagnostic, "status scope arm fixture_kind schedule_execution elapsed_ns transfer_wall_ns "
                                              "managed_peak_bytes_by_node managed_reserved_bytes_by_node "
                                              "cuda_peak_allocated_bytes_delta_by_node link_bytes shared_bottleneck_bytes "
                                              "live_references_at_end total_fetch_misses workload_sha256 schedule_sha256 "
                                              "program_sha256 topology_sha256 scenario_sha256 selected_and_output_sha256"),
                           "action_count": len(actions),
                           "action_types": dict(Counter(row.get("action", "unknown") for row in actions)),
                           "actions": actions[:max_actions], "semantics": diagnostic.get("semantics", [])},
            "timings_elapsed_ns": [row.get("elapsed_ns") for row in value.get("timings", [])]}


def read_receipt(path, max_actions):
    value = _read(path)
    if value.get("schema") != 2 or not isinstance(value.get("job_id"), str):
        raise ValueError(f"expected a GPU execution v2 receipt in {path.name}")
    result = value.get("result")
    digest_matches = isinstance(result, dict) and value.get("result_canonical_sha256") == _fingerprint(result)
    return {"file": path.name, **_take(value, "job_id status request_sha256 source_manifest_sha256 gpu_indices gpu_uuids "
                                             "utc_start utc_end elapsed_seconds returncode failure timeout environment_conflict "
                                             "result_sha256 result_canonical_sha256 log_sha256 remaining_compute_pids "
                                             "after_query_failure result_failure replayed_receipt"),
            "canonical_result_matches": digest_matches if result is not None else None,
            "result": ({**_take(result, "scope score score_unit feasible hardware error_type"),
                        "cases": [_case(case, max_actions) for case in result.get("cases", [])]}
                       if digest_matches else None)}


def _scenario(path, kind=None):
    value = _read(path)
    recorded_kind = value.get("kind")
    if recorded_kind in SCENARIOS and kind not in (None, recorded_kind):
        raise ValueError(f"scenario kind does not match {path.name}")
    if kind in SCENARIOS and {"rank_placement", "attention", "target_sha256", "workload_sha256", "schedule_sha256"} <= value.keys():
        return {"kind": kind, "file": path.name, "binding_sha256": _fingerprint(value),
                "binding": _take(value, "rank_placement attention target_sha256 workload_sha256 schedule_sha256")}
    if recorded_kind not in SCENARIOS:
        raise ValueError(f"unknown scenario kind in {path.name}")
    return {**_take(value, "kind name page_rows"), "file": path.name, "fixture_sha256": _fingerprint(value),
            "segments": len(value.get("segments", [])),
            "events": dict(Counter(row.get("kind", row.get("op", "unknown")) for row in value.get("events", [])))}


def render(output, *, runs=(), receipts=(), topologies=(), scenarios=(), max_actions=200):
    if not 0 <= max_actions <= 10000:
        raise ValueError("max_actions must be between 0 and 10000")
    graphs = []
    for path in topologies:
        value = _read(path)
        if not isinstance(value.get("nodes"), list) or not isinstance(value.get("links"), list):
            raise ValueError(f"expected topology nodes and links in {path.name}")
        graphs.append({"name": path.name, "sha256": _fingerprint(value),
                       **_take(value, "nodes links bottlenecks")})
    data = {"runs": [read_run(path, label) for label, path in runs],
            "receipts": [read_receipt(path, max_actions) for path in receipts], "topologies": graphs,
            "scenarios": [_scenario(*entry) if isinstance(entry, tuple) else _scenario(entry) for entry in scenarios],
            "scenario_labels": SCENARIOS}
    embedded = json.dumps(data, ensure_ascii=False, allow_nan=False).replace("&", "\\u0026").replace("<", "\\u003c")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(PAGE.replace("/* EMBEDDED_RUN_DATA */", embedded, 1))
    return data


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run", action="append", default=[], metavar="[LABEL=]DIRECTORY")
    parser.add_argument("--receipt", type=Path, action="append", default=[])
    parser.add_argument("--receipts", type=Path, action="append", default=[], metavar="DIRECTORY")
    parser.add_argument("--topology", type=Path, action="append", default=[])
    parser.add_argument("--scenario", action="append", default=[], metavar="[KIND=]JSON")
    parser.add_argument("--max-actions", type=int, default=200)
    args = parser.parse_args(argv)
    runs = []
    for entry in args.run:
        label, separator, path = entry.partition("=")
        runs.append((label, Path(path)) if separator else (None, Path(entry)))
    receipts = dict.fromkeys([*args.receipt, *(path for directory in args.receipts
                            for path in sorted(directory.glob("*.json")))])
    scenarios = []
    for entry in args.scenario:
        kind, separator, path = entry.partition("=")
        scenarios.append((Path(path), kind) if separator else Path(entry))
    render(args.output, runs=runs, receipts=receipts, topologies=args.topology, scenarios=scenarios,
           max_actions=args.max_actions)
    print(args.output.resolve())


if __name__ == "__main__":
    main()
