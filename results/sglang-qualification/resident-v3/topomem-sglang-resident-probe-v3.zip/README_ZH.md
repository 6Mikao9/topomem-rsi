# HiSparse 全驻留冷池省略原型

状态为 `built_unverified`。本目录是独立草稿。现有 SGLang runner、发布候选和已冻结实验未被接线或改动。本原语由人工实现，生成器尚未提出或选择它。当前九项 CPU 契约测试通过。实机 A/A、跨臂字节及调度资格、内存实测和性能均待执行。

`compile_proof(engine, requests, device_rows=...)` 绑定原生 DP2 GLM DSA 引擎、6144 hot slots、2048 top-k、64 行页和实际设备分配器容量。`requests` 包含 `phase`、`rid`、`rank`、`input_ids`、`max_new_tokens`，每个 warmup/requests 阶段每 rank 恰一条。校验使用实际 token ID 摘要与最大解码预算。原生算法在页对齐结果达到 hot 容量时还分配一个保留页。编译时计入保留页，并保守累加同 rank 两个请求的最大占用。运行时在入队、prefill 分配、decode 分配前校验，同一 CPU 长度再进入原生 newest slot remap。超出合同的 worker 失败，由外层进程组裁判回收。模型、拓扑、外部调度和源身份仍由原 launcher 绑定。

在每个专用 worker 的原生调度器构建前调用 `resident_only.install(proof, engine=..., rank=..., report=...)`。它使用原生 `MLATokenToKVPoolHost` 的 allocator-only dummy 构造，并为原生短路径 launch 提供六个独立 CUDA 占位行。完整冷 KV payload 不分配。占位数据逻辑大小为 3,936 B，实际 CUDA 分配还受 allocator 粒度影响。原有 hot pool、索引、各层 LRU、请求映射、空冷映射、页分配器、保留页和短序列 kernel 继续使用原生路径。`skip_io` 必须为 false，直接从冷数据转入的路径与任何意外冷读写均失败。

prefill 转接保留生产者到 staging stream 的事件、完成事件和 ack 队列。原生 `collect_ready_reqs` 保留已有的 prefill 设备行并建立 buffer 索引。decode 仅省略冷备份，原生增长和 newest 映射继续运行。正常 finish、staging abort、生产者等待和回收顺序仍调用原函数。现几何估计原生冷 payload 为 129,226,752 B/rank，省略冷池主要影响固定页 DRAM 与 D2H 写回，主热池 HBM 保持原几何。指标应以新实测为准。

诊断时构建 `PackedProducerOracle(torch_row_reader(torch))`，在 resident 模式传 `diagnostic=oracle`。stock 模式可在同样的诊断 worker 中对原生类调用 `attach_oracle(HiSparseCoordinator, HiSparseDSATokenToKVPool, oracle)`。prefill 影子在 `alloc_device_buffer` 清除初始逻辑映射前，从 `req_to_token` 与 producer pool 读取完整 656 B 行。decode 影子通过 `out_cache_loc` 的 producer 映射，并在 `set_mla_kv_buffer` 完成后独立保存实际 packed 行。随后通过原生 swap 返回的物理行逐字节校验有序历史选集和 newest。遗漏某层的 producer 写入、重复写入、错误物理行、释放遗漏和覆盖不足都会失败。runner 须调用 `oracle.result(expected_decode_steps)`，将摘要、覆盖数和输出 IDs、实际 global DP trace、owner/cap 检查一并封存。计时 worker 不实例化该 oracle。CPU 测试验证独立坐标和单字节错误拒绝，尚未验证 CUDA stream 或实际模型是否每层通过该 producer 接口。

关键资格风险是去掉 prefill D2H 后，staging 完成事件的可见时点会改变。即使请求入口在两 rank 同轮释放，后续全局 prefill/decode/IDLE 向量也必须重新核验。若同一新合同内跨臂 shape 或 packed 摘要漂移，保留失败并停止该合同的性能比较。运行时不模拟延迟，不重写 attention、TopK、调度、算子输出或旧实验数据。

诊断逐行核对 native short path 返回的物理地址与生产者观察到的地址，并比较完整 656 B。该路径在 staging 后保留已有的 prefill 行，decode 只追加设备行。重复逻辑选行拒绝，超出 native `num_real_reqs` 的 padding 行须全为 `-1`。地址相等要求只适用于这个已封存的短路径。

## 独立资格包

`pack_resident_probe.py --native-transfer <frozen-native-transfer.zip> --output <new.zip>` 校验源包 SHA 和逐成员清单，逐字节保留原生 runner 与 6144 案例。原 launch 配置由操作员留在包外。新包附源码和案例清单，在 Linux 使用已资格 GPU 和隔离 NCCL，通过同一受信租约串行运行。新 worker 使用原始 tokenization 与 ingress 绑定。

```sh
python3 -B -m unittest discover -s tests
python3 -B run_resident_qualification.py --expected-manifest-sha256 "$SOURCE_SHA" --verify-only
python3 -B run_resident_qualification.py --expected-manifest-sha256 "$SOURCE_SHA" \
  --launch-config "$PRIVATE_LAUNCH" --gated-run "$NATIVE_GATE_RUN" --expected-gate-sha256 "$NATIVE_GATE_SHA" \
  --output "$NEW_PARITY_RUN"
```

原生三容量 gate 必须通过，6144 的两份原始回执及其摘要也须存在。资格矩阵使用四次新进程，顺序为 stock、resident、resident、stock。两臂共用逐字节 producer oracle。资格要求四次观测的实际全局轨迹、派发、输出、分词、运行环境、热几何和各 rank packed 摘要一致。可与原 gate 直接比较的轨迹、派发、分词和输出字段也须一致。每轮按原有 supervisor 方法验证两 worker 实际加载的 NCCL 映射和进程退出。

只有新资格通过后，才可用同样的参数及 `--phase performance --qualified-run "$NEW_PARITY_RUN" --expected-qualified-sha256 "$PARITY_SHA"` 启动四次独立计时，指定另一新输出目录。计时 worker 没有 packed oracle，仍校验同臂同序号的实际全局轨迹、派发与输出。两对计时用于机制探测。统计上的稳定收益需要后续独立预算。资格失败或进程异常保留已生成的原始证据。

[原生转接与回收源码](https://github.com/sgl-project/sglang/blob/94602c9c2b7cbdb8efd5c52802dac6a1c180089e/python/sglang/srt/managers/hisparse_coordinator.py) · [原生 allocator-only host pool](https://github.com/sgl-project/sglang/blob/94602c9c2b7cbdb8efd5c52802dac6a1c180089e/python/sglang/srt/mem_cache/pool_host/mla.py#L152-L212) · [原生短序列 kernel](https://github.com/sgl-project/sglang/blob/94602c9c2b7cbdb8efd5c52802dac6a1c180089e/python/sglang/kernels/jit/csrc/kvcacheio/hisparse.cuh#L385-L417)
