#!/usr/bin/env python3
"""Run isolated paired DP2 resident backing checks with the pinned native supervisor."""

import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path, PurePosixPath
import signal
import subprocess
import sys
import time

import native_probe_support as native


BASE_MANIFEST = "b63b60225e6df9e7c2d6e42ac0ccce4d67d0c0ebcfdd49cdfd3f1e7dae8ade70"
ORDERS = (("stock", "resident"), ("resident", "stock"))
COMMON = ("target_sha256", "scenario_sha256", "topology_sha256", "schedule_inputs_sha256", "resident_proof_sha256",
          "input_tokenization_sha256", "ingress_contract_sha256", "runtime", "global_ticks_sha256",
          "effective_schedule_sha256", "dispatch_sha256", "output_ids_sha256")
OLD_COMMON = ("effective_schedule_sha256", "dispatch_sha256", "output_ids_sha256", "global_ticks_sha256",
              "input_tokenization_sha256", "ingress_contract_sha256")


def read(path, expected=None):
    if path.is_symlink() or expected is not None and native.hash_file(path) != expected:
        raise ValueError("changed probe input: " + path.name)
    return json.loads(path.read_bytes())


def verify_source(root, expected):
    manifest = read(root / "SOURCE_MANIFEST.json", expected)
    if (manifest.get("schema") != 1 or manifest.get("kind") != "paired_resident_only_6144_probe"
            or manifest.get("base_transfer_manifest_sha256") != BASE_MANIFEST):
        raise ValueError("unexpected resident probe source contract")
    files = manifest["files"]
    for relative, digest in files.items():
        path = PurePosixPath(relative)
        member = root / path
        if (path.is_absolute() or path.as_posix() != relative or ".." in path.parts or "\\" in relative
                or member.is_symlink() or not member.resolve(strict=True).is_relative_to(root)
                or native.hash_file(member) != digest):
            raise ValueError("resident probe member changed: " + relative)
    actual = {path.relative_to(root).as_posix() for path in root.rglob("*") if path.is_file() or path.is_symlink()}
    if actual != {*files, "SOURCE_MANIFEST.json"}:
        raise ValueError("resident probe source has missing or extra files")
    return manifest


def verify_case(case):
    fixture, target, external = (read(case / f"{name}.json") for name in ("fixture", "target", "external_schedule"))
    pool, engine = target["pool"], external["engine"]
    hot, page = pool["hot_slots"], pool["page_size"]
    if (hot, page, pool["layers"], target["attention_dp_size"]) != (6144, 64, 6, 2):
        raise ValueError("original case no longer binds the fixed resident geometry")
    lengths, reservations = [], [0, 0]
    for group in external["ingress_rendezvous"]["groups"]:
        rows = {row["rid"]: row for row in fixture[group["phase"]]}
        for member in group["members"]:
            row = rows[member["rid"]]
            length = member["input_tokens"] + row["max_new_tokens"]
            if not 1 <= length <= hot or row["routed_dp_rank"] != member["rank"]:
                raise ValueError("original tokenization commitment does not fit the resident range")
            rounded = (length + page - 1) // page * page
            reservations[member["rank"]] += rounded + (page if rounded == hot else 0)
            lengths.append(length)
    if len(lengths) != 4 or max(reservations) > engine["max_total_tokens"]:
        raise ValueError("original committed case exceeds the native resident page budget")
    return {"maximum_committed_tokens": max(lengths), "conservative_pages_by_rank": [count // page for count in reservations],
            "device_rows_per_rank": engine["max_total_tokens"]}


def load_native_gate(directory, expected, case):
    gate = read(directory / "gated_qualification.json", expected)
    if (gate.get("qualification_passed") is not True or gate.get("cross_capacity_all_fields_equal") is not True
            or gate.get("repeat_count") != 2 or gate.get("transfer_manifest_sha256") != BASE_MANIFEST
            or gate.get("same_capacity_aa", {}).get("6144") != {"mismatches": []}):
        raise ValueError("resident probe requires successful frozen native gated qualification")
    rows = [read(directory / f"round-{number:02d}" / "hot-6144" / "result.json",
                 gate["observations"][str(number)]["6144"]["result_sha256"]) for number in (1, 2)]
    case_manifest = read(case / "manifest.json")
    for number, row in enumerate(rows, 1):
        if (row.get("status") != "completed" or row.get("arm") != "native" or row.get("phase") != "parity"
                or row.get("scenario_sha256") != case_manifest["scenario_sha256"]
                or row.get("schedule_inputs_sha256") != case_manifest["schedule_sha256"]
                or any(row.get(field) != gate["observations"][str(number)]["6144"]["comparison_fields"][field]
                       for field in native.QUALIFICATION_FIELDS)):
            raise ValueError("resident probe baseline does not bind the exact original native 6144 case")
    if any(rows[0][field] != rows[1][field] for field in native.QUALIFICATION_FIELDS):
        raise ValueError("original native 6144 observations disagree")
    return rows[0]


def compare(results, old_native, *, parity, qualified=None):
    failures = []
    if len(results) != 4:
        raise ValueError("resident probe needs the four fixed fresh worker trials")
    reference = results[0]
    for trial, row in enumerate(results):
        mode = ORDERS[trial // 2][trial % 2]
        if row.get("status") != "completed" or row.get("mode") != mode:
            failures.append([trial, "invalid_status_or_mode"])
            continue
        for field in COMMON:
            if row.get(field) is None or row.get(field) != reference.get(field):
                failures.append([trial, field])
        for field in OLD_COMMON:
            if row.get(field) != old_native.get(field):
                failures.append([trial, "original_native_" + field])
        geometry = [rank["worker"]["hot_geometry"] for rank in row["ranks"]]
        if geometry != [rank["worker"]["hot_geometry"] for rank in reference["ranks"]]:
            failures.append([trial, "native_hot_geometry"])
        if parity:
            packed = row.get("producer_and_selected_sha256_by_rank")
            if type(packed) is not list or len(packed) != 2 or any(not value for value in packed) or packed != reference.get("producer_and_selected_sha256_by_rank"):
                failures.append([trial, "producer_and_selected_sha256_by_rank"])
        else:
            if row.get("producer_and_selected_sha256_by_rank") is not None or any(rank["worker"]["oracle"] is not None for rank in row["ranks"]):
                failures.append([trial, "timing_oracle_present"])
            if qualified is None or any(row[field] != qualified[trial][field] for field in COMMON):
                failures.append([trial, "same_trial_parity_binding"])
    return failures


def run_trial(root, output, index, mode, phase, python, env, launch, supervisor, version, timeout, source_sha):
    case = root / "case"
    directory = output / f"{index:02d}-{mode}"
    argv = [python, "-B", "-m", "resident_probe", "--model", launch["model"], "--mode", mode, "--phase", phase,
            "--manifest-sha256", source_sha, "--output", str(directory)]
    for name in ("target", "topology", "scenario", "fixture", "external_schedule"):
        argv.extend(("--" + name.replace("_", "-"), str(case / (name + ".json"))))
    for item in sorted((case / "link_evidence").iterdir()):
        argv.extend(("--link-evidence", str(item)))
    state = [{"rank": rank, "pid": None, "process_starttime": None, "maps_samples": 0, "maps_samples_after_decode": 0,
              "libraries": {}} for rank in range(2)]
    fields = "uuid,memory.used,utilization.gpu,temperature.gpu,power.draw"
    indices = launch["gpu_indices"]
    receipt = {"schema": 1, "mode": mode, "phase": phase, "argv": argv, "nccl_workers": state,
               "utc_start": datetime.now(timezone.utc).isoformat(), "gpu_before": supervisor.query(indices, fields)}
    process, failure = None, None
    started = time.monotonic()
    try:
        with (output / f"{index:02d}-{mode}.process.log").open("xb") as log:
            process = subprocess.Popen(argv, cwd=root / "worker", env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            receipt["leader_pid"] = process.pid
            while process.poll() is None:
                for rank, observation in enumerate(state):
                    native._sample_worker(directory, process.pid, supervisor, rank, observation)
                if time.monotonic() - started >= timeout:
                    raise TimeoutError("resident qualification exceeded its process timeout")
                time.sleep(.04)
        if process.returncode != 0:
            raise RuntimeError("resident qualification trial failed")
    except BaseException as exc:
        failure = exc
    finally:
        try:
            if process is not None:
                cleanup, remains = supervisor._clean_group(process)
                receipt.update(process_group_cleanup_required=cleanup, process_group_remaining=remains, returncode=process.poll())
                if cleanup or remains:
                    raise RuntimeError("probe did not exit with a clean process group")
            receipt["gpu_after"] = supervisor.query(indices, fields)
            receipt["remaining_compute_pids"] = supervisor.query(indices, "pid", "compute-apps")
            if receipt["remaining_compute_pids"]:
                raise RuntimeError("selected GPUs have a remaining compute process")
        except BaseException as exc:
            failure = failure or exc
        try:
            if not native._finish_nccl(state, Path(env["SGLANG_NCCL_SO_PATH"]), env["TOPOMEM_EXPECTED_NCCL_SHA256"], version):
                raise RuntimeError("both owned workers must attest the isolated NCCL mapping during decode")
            result_path = directory / "result.json"
            result = read(result_path)
            receipt["result_sha256"] = native.hash_file(result_path)
            if (result.get("status"), result.get("mode"), result.get("phase"), result.get("source_manifest_sha256")) != (
                    "completed", mode, phase, source_sha):
                raise ValueError("the raw resident trial does not bind the expected stage")
        except BaseException as exc:
            failure = failure or exc
        receipt.update(status="completed" if failure is None else "failed", elapsed_seconds=time.monotonic() - started,
                       utc_end=datetime.now(timezone.utc).isoformat())
        if failure is not None:
            receipt["failure"] = {"type": type(failure).__name__, "message": str(failure)}
        supervisor.atomic(output / f"{index:02d}-{mode}.probe.json", receipt)
    if failure is not None:
        raise failure
    return result, receipt["result_sha256"]


def load_paired_proof(directory, digest, source_sha, gate_sha):
    report = read(directory / "qualification.json", digest)
    if (report.get("qualified") is not True or report.get("phase") != "parity"
            or report.get("source_manifest_sha256") != source_sha or report.get("gated_qualification_sha256") != gate_sha):
        raise ValueError("timing needs completed parity from this exact resident probe and gate")
    if len(report["result_sha256s"]) != 4:
        raise ValueError("timing needs all four fresh parity observations")
    results = []
    for index, (mode, expected) in enumerate(zip((arm for order in ORDERS for arm in order), report["result_sha256s"]), 1):
        row = read(directory / f"{index:02d}-{mode}" / "result.json", expected)
        receipt = read(directory / f"{index:02d}-{mode}.probe.json")
        if (row.get("source_manifest_sha256") != source_sha or row.get("phase") != "parity"
                or receipt.get("result_sha256") != expected or receipt.get("status") != "completed"):
            raise ValueError("the original resident parity process receipt is missing or mismatched")
        results.append(row)
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-manifest-sha256", required=True)
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--launch-config", type=Path)
    parser.add_argument("--gated-run", type=Path)
    parser.add_argument("--expected-gate-sha256")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--phase", choices=("parity", "performance"), default="parity")
    parser.add_argument("--qualified-run", type=Path)
    parser.add_argument("--expected-qualified-sha256")
    parser.add_argument("--process-timeout", type=int, default=900)
    args = parser.parse_args()
    sys.dont_write_bytecode = True
    root = Path(__file__).resolve().parent
    verify_source(root, args.expected_manifest_sha256)
    commitment = verify_case(root / "case")
    if args.verify_only:
        print(json.dumps({"status": "verified_source_and_original_6144_case", "manifest_sha256": args.expected_manifest_sha256,
                          "token_commitment": commitment}))
        return
    if (sys.platform != "linux" or not all((args.launch_config, args.gated_run, args.expected_gate_sha256, args.output))
            or not 650 <= args.process_timeout <= 3600 or args.output.resolve().is_relative_to(root)
            or (args.phase == "performance") != bool(args.qualified_run and args.expected_qualified_sha256)):
        parser.error("use leased Linux, an external launcher, successful gate, and a new external output directory")
    old = load_native_gate(args.gated_run, args.expected_gate_sha256, root / "case")
    prior = (load_paired_proof(args.qualified_run, args.expected_qualified_sha256, args.expected_manifest_sha256,
                              args.expected_gate_sha256) if args.phase == "performance" else None)
    if prior is not None and compare(prior, old, parity=True):
        raise ValueError("resident parity proof no longer satisfies the exact paired gate")
    launcher = native.load_module("resident_probe_launcher", root / "support" / "sglang_launch.py")
    supervisor = native.load_module("resident_probe_supervisor", root / "support" / "execution_worker.py")
    launch_raw = args.launch_config.read_bytes()
    launch = json.loads(launch_raw)
    wheel = read(root / "support" / "sglang_nccl_manifest.json")
    env = {key: val for key, val in os.environ.items() if key in supervisor.INHERITED_ENVIRONMENT}
    env.update(CUDA_VISIBLE_DEVICES=",".join(launch["gpu_uuids"]), PYTHONPATH=str(root / "worker"),
               PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1")
    python, env = launcher.prepare(launch_raw, ["-B", "-m", launcher.MODULE, "--input", "unused", "--output", "unused"], env, wheel)
    env["TOPOMEM_EXPECTED_NCCL_SHA256"] = launcher.NCCL_SHA256

    def stop(_signal, _frame):
        raise KeyboardInterrupt("resident probe stop requested")

    signal.signal(signal.SIGTERM, stop)
    with supervisor.gpu_leases(launch["gpu_uuids"]):
        ids = launch["gpu_indices"]
        if supervisor.query(ids, "uuid").splitlines() != launch["gpu_uuids"] or supervisor.query(ids, "pid", "compute-apps"):
            raise RuntimeError("target GPU identities differ or GPU is already occupied")
        args.output.mkdir(parents=True, exist_ok=False)
        report = {"schema": 1, "phase": args.phase, "qualified": False, "orders": ORDERS,
                  "source_manifest_sha256": args.expected_manifest_sha256, "gated_qualification_sha256": args.expected_gate_sha256,
                  "launch_sha256": sha256(launch_raw).hexdigest(), "result_sha256s": []}
        try:
            version = native._nccl_version(python, env, Path(env["SGLANG_NCCL_SO_PATH"]))
            results = []
            for index, mode in enumerate((arm for order in ORDERS for arm in order), 1):
                result, digest = run_trial(root, args.output, index, mode, args.phase, python, env, launch, supervisor, version,
                                           args.process_timeout, args.expected_manifest_sha256)
                results.append(result)
                report["result_sha256s"].append(digest)
            report["mismatches"] = compare(results, old, parity=args.phase == "parity", qualified=prior)
            report["qualified"] = not report["mismatches"]
        except BaseException as exc:
            report["failure"] = {"type": type(exc).__name__, "message": str(exc)}
            raise
        finally:
            supervisor.atomic(args.output / "qualification.json", report)
    if not report["qualified"]:
        raise RuntimeError("resident pair failed its exact held configuration, trajectory, output or packed-byte gate")
    print(json.dumps({"status": "completed", "phase": args.phase, "qualification_sha256": native.hash_file(args.output / "qualification.json")}))


if __name__ == "__main__":
    main()
