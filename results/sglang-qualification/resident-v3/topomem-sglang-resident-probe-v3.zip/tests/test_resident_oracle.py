from pathlib import Path
import sys
from types import SimpleNamespace as Obj
import unittest

if Path(__file__).parent.name == "tests":
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "worker"))

from resident_only import LAYERS, ROW_BYTES, TOP_K
from resident_oracle import PackedProducerOracle, attach_oracle


class Vec(list):
    def tolist(self):
        return list(self)

    def long(self):
        return self


def packed(layer, token):
    return bytes([layer, token]) * (ROW_BYTES // 2)


def fixture():
    pool = Obj(size=64, page_size=64, translate_loc_from_full_to_hisparse_device=lambda ids: Vec(
        [{100: 2, 101: 3, 102: 4}[value] for value in ids]))
    storage = {(layer, location): packed(layer, token) for layer in range(LAYERS)
               for token, location in [(0, 2), (1, 3), (2, 4), (0, 11), (1, 12), (2, 13)]}

    class LogicalTable:
        def __getitem__(self, key):
            if key != (0, slice(None, 2)):
                raise AssertionError(key)
            return Vec([100, 101])

    class HotTable:
        newest = 4

        def __getitem__(self, key):
            return self.newest

    coord = Obj(mem_pool_device=pool, req_to_token_pool=Obj(req_to_token=LogicalTable()),
                req_device_buffer_token_locs=HotTable(), num_real_reqs=Obj(item=lambda: 1))
    req = Obj(rid="r0", kv=Obj(req_pool_idx=0), extend_range=Obj(end=2))
    oracle = PackedProducerOracle(lambda _pool, layer, locations: [storage[layer, location] for location in locations])
    oracle.capture_prefill(coord, req)
    oracle.plan_decode(coord, Vec([102]), Vec([3]), Vec([0]))
    return coord, req, oracle, storage


class TestOracle(unittest.TestCase):
    def test_producer_and_consumer_independent_coordinates_and_all_bytes(self):
        coord, req, oracle, _storage = fixture()
        topk = Vec([[1, 0, 2] + [-1] * (TOP_K - 3)])
        output = Vec([[3, 2, 4] + [-1] * (TOP_K - 3)])
        for layer in range(LAYERS):
            oracle.capture_producer_store(coord.mem_pool_device, layer, Vec([102]))
            oracle.check_selected(coord, Vec([0]), Vec([3]), topk, output, layer)
        oracle.release(coord, req)
        result = oracle.result({"r0": 1})
        self.assertEqual(result["verified_swaps"], 6)
        self.assertEqual(result["verified_selected_history_rows"], 12)
        self.assertEqual(result["verified_newest_rows"], 6)
        self.assertEqual(result["captured_prefill_rows"], 12)
        self.assertEqual(len(result["producer_and_selected_sha256"]), 64)
        self.assertFalse(oracle.pending)

    def test_single_byte_corruption_and_missing_producer_fail(self):
        coord, _req, oracle, storage = fixture()
        topk = Vec([[0, 1, 2] + [-1] * (TOP_K - 3)])
        output = Vec([[2, 3, 4] + [-1] * (TOP_K - 3)])
        with self.assertRaisesRegex(RuntimeError, "independently observed"):
            oracle.check_selected(coord, Vec([0]), Vec([3]), topk, output, 0)
        oracle.capture_producer_store(coord.mem_pool_device, 0, Vec([102]))
        original = storage[0, 3]
        storage[0, 3] = original[:-1] + bytes([original[-1] ^ 1])
        with self.assertRaisesRegex(RuntimeError, "independently captured"):
            oracle.check_selected(coord, Vec([0]), Vec([3]), topk, output, 0)

    def test_same_bytes_at_wrong_addresses_and_duplicate_tokens_fail(self):
        coord, _req, oracle, storage = fixture()
        oracle.capture_producer_store(coord.mem_pool_device, 0, Vec([102]))
        tail = [-1] * (TOP_K - 3)
        self.assertEqual(storage[0, 2], storage[0, 11])
        self.assertEqual(storage[0, 4], storage[0, 13])
        with self.assertRaisesRegex(RuntimeError, "selected KV location"):
            oracle.check_selected(coord, Vec([0]), Vec([3]), Vec([[0, 1, 2] + tail]), Vec([[11, 3, 4] + tail]), 0)
        with self.assertRaisesRegex(RuntimeError, "duplicate logical token"):
            oracle.check_selected(coord, Vec([0]), Vec([3]), Vec([[0, 0, 2] + tail]), Vec([[2, 2, 4] + tail]), 0)
        coord.req_device_buffer_token_locs.newest = 13
        with self.assertRaisesRegex(RuntimeError, "newest KV location"):
            oracle.check_selected(coord, Vec([0]), Vec([3]), Vec([[0, 1, 2] + tail]), Vec([[2, 3, 4] + tail]), 0)

    def test_native_real_request_count_separates_eager_padding(self):
        coord, _req, oracle, _storage = fixture()
        oracle.capture_producer_store(coord.mem_pool_device, 0, Vec([102]))
        tail = [-1] * (TOP_K - 3)
        pad = [-1] * TOP_K
        topk = Vec([[0, 1, 2] + tail, [0] * TOP_K])
        output = Vec([[2, 3, 4] + tail, pad])
        oracle.check_selected(coord, Vec([0, 0]), Vec([3, 0]), topk, output, 0)
        self.assertEqual(oracle.swaps, 1)
        coord.num_real_reqs = Obj(item=lambda: 0)
        oracle.check_selected(coord, Vec([0]), Vec([0]), Vec([[0] * TOP_K]), Vec([pad]), 0)
        self.assertEqual(oracle.swaps, 1)
        with self.assertRaisesRegex(RuntimeError, "padded request has a live KV location"):
            oracle.check_selected(coord, Vec([0]), Vec([0]), Vec([[0] * TOP_K]), Vec([[2] + pad[1:]]), 0)
        coord.num_real_reqs = Obj(item=lambda: 2)
        with self.assertRaisesRegex(RuntimeError, "consumer geometry"):
            oracle.check_selected(coord, Vec([0]), Vec([0]), Vec([[0] * TOP_K]), Vec([pad]), 0)

    def test_attachment_keeps_producer_and_consumer_native_operations(self):
        trace = []

        class Coord:
            def admit_request_into_staging(self, req):
                trace.append("native-staging")

            def map_last_loc_to_buffer(self, *_args):
                trace.append("native-map")

            def swap_in_selected_pages(self, *_args):
                trace.append("native-swap")
                return "returned-slots"

            def request_finished(self, req):
                trace.append("native-finish")

            abort_staging_request = request_finished

        class Pool:
            start_layer = 0

            def set_mla_kv_buffer(self, *_args):
                trace.append("native-produce")

        oracle = PackedProducerOracle(None)
        oracle.capture_prefill = lambda *_args: trace.append("prefill-copy")
        oracle.plan_decode = lambda *_args: trace.append("producer-coordinates")
        oracle.capture_producer_store = lambda *_args: trace.append("producer-bytes")
        oracle.check_selected = lambda *_args: trace.append("consumer-bytes")
        oracle.release = lambda *_args: trace.append("oracle-release")
        attach_oracle(Coord, Pool, oracle)
        coord = Coord()
        coord.admit_request_into_staging(None)
        coord.map_last_loc_to_buffer(None, None, None, None, None)
        Pool().set_mla_kv_buffer(Obj(layer_id=0), None, None, None)
        self.assertEqual(coord.swap_in_selected_pages(None, None, None, 0), "returned-slots")
        coord.request_finished(None)
        self.assertEqual(trace, ["prefill-copy", "native-staging", "native-map", "producer-coordinates",
                                 "native-produce", "producer-bytes", "native-swap", "consumer-bytes",
                                 "native-finish", "oracle-release"])


if __name__ == "__main__":
    unittest.main()
