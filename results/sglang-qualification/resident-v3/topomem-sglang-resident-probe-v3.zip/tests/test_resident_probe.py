from pathlib import Path
import sys
import types
import unittest


ROOT = Path(__file__).resolve().parent
if ROOT.name == "tests":
    sys.path.insert(0, str(ROOT.parent))
    sys.path.insert(0, str(ROOT.parent / "worker"))
else:
    # The draft itself has no frozen transfer files until packed.
    sys.modules.setdefault("native_probe_support", types.ModuleType("native_probe_support"))

from run_resident_qualification import COMMON, OLD_COMMON, ORDERS, compare


def trials(phase):
    common = {field: field for field in COMMON}
    old = {field: common[field] for field in OLD_COMMON}
    rows = []
    for order in ORDERS:
        for mode in order:
            oracle = {"verified_swaps": 756} if phase == "parity" else None
            ranks = [{"worker": {"oracle": oracle, "hot_geometry": {"slots": 6144}}} for _ in (0, 1)]
            rows.append({**common, "status": "completed", "mode": mode, "ranks": ranks,
                         "producer_and_selected_sha256_by_rank": ["a", "b"] if phase == "parity" else None})
    return rows, old


class TestProbe(unittest.TestCase):
    def test_parity_rejects_drift_or_lost_producer_evidence(self):
        rows, old = trials("parity")
        self.assertEqual(compare(rows, old, parity=True), [])
        rows[1]["producer_and_selected_sha256_by_rank"] = ["a", "c"]
        rows[2]["global_ticks_sha256"] = "changed"
        rows[3]["ranks"][1]["worker"]["hot_geometry"]["slots"] = 8192
        self.assertEqual(compare(rows, old, parity=True), [[1, "producer_and_selected_sha256_by_rank"],
                         [2, "global_ticks_sha256"], [2, "original_native_global_ticks_sha256"], [3, "native_hot_geometry"]])

    def test_timing_requires_same_trial_and_no_shadow(self):
        rows, old = trials("performance")
        parity, _ = trials("parity")
        self.assertEqual(compare(rows, old, parity=False, qualified=parity), [])
        rows[1]["ranks"][1]["worker"]["oracle"] = {"unexpected": True}
        parity[2]["output_ids_sha256"] = "not the timed outputs"
        self.assertEqual(compare(rows, old, parity=False, qualified=parity), [[1, "timing_oracle_present"], [2, "same_trial_parity_binding"]])


if __name__ == "__main__":
    unittest.main()
