from contextlib import contextmanager
import json
from pathlib import Path
import sys
from types import SimpleNamespace as Obj
import unittest

if Path(__file__).parent.name == "tests":
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "worker"))

from resident_only import (ENGINE_FIELDS, HOT_SLOTS, LAYERS, PAGE_ROWS, ROW_BYTES, TOP_K,
                           _patched_classes, check_request, compile_proof, reserved_rows)


def engine(rows=16384):
    return {**ENGINE_FIELDS, "max_total_tokens": rows, "hisparse_config": json.dumps(
        {"device_buffer_size": HOT_SLOTS, "top_k": TOP_K, "host_to_device_ratio": 2})}


def requests(prompt=5100, new=106):
    return [{"phase": phase, "rid": f"{phase}-{rank}", "rank": rank, "input_ids": list(range(prompt)),
             "max_new_tokens": new} for phase in ("warmup", "requests") for rank in (0, 1)]


class Vec(list):
    def tolist(self):
        return list(self)


class TestProof(unittest.TestCase):
    def test_actual_token_identity_and_conservative_rank_overlap(self):
        cases = requests()
        p = compile_proof(engine(), cases, device_rows=16384)
        self.assertEqual(p.reserved_rows_by_rank, (10496, 10496))
        self.assertEqual(p.for_rank(0)["requests-0"].length, 5206)
        self.assertEqual(p.fingerprint(), compile_proof(engine(), cases, device_rows=16384).fingerprint())
        request = cases[2]
        check_request(p.for_rank(0), request["rid"], request["input_ids"], request["max_new_tokens"])
        with self.assertRaisesRegex(ValueError, "token IDs differ"):
            check_request(p.for_rank(0), request["rid"], request["input_ids"][::-1], request["max_new_tokens"])
        with self.assertRaisesRegex(ValueError, "sealed"):
            check_request(p.for_rank(1), request["rid"], request["input_ids"], request["max_new_tokens"])

    def test_hot_boundary_charges_native_reserved_page(self):
        self.assertEqual(reserved_rows(HOT_SLOTS - 64), HOT_SLOTS - 64)
        self.assertEqual(reserved_rows(HOT_SLOTS - 63), HOT_SLOTS + PAGE_ROWS)
        self.assertEqual(reserved_rows(HOT_SLOTS), HOT_SLOTS + PAGE_ROWS)
        with self.assertRaisesRegex(ValueError, "hot range"):
            compile_proof(engine(), requests(HOT_SLOTS, 1), device_rows=16384)
        with self.assertRaisesRegex(ValueError, "physical page budget"):
            compile_proof(engine(10240), requests(), device_rows=10240)

    def test_rejects_other_scope_or_duplicate_rid(self):
        for changes in ({"speculative_algorithm": "EAGLE"}, {"enable_dp_attention": False},
                        {"enable_hierarchical_cache": True}, {"disable_overlap_schedule": False}):
            with self.assertRaises(ValueError):
                compile_proof({**engine(), **changes}, requests(), device_rows=16384)
        cases = requests()
        cases[3]["rid"] = cases[2]["rid"]
        with self.assertRaisesRegex(ValueError, "unique request"):
            compile_proof(engine(), cases, device_rows=16384)


class TestWorker(unittest.TestCase):
    def test_real_hook_paths_with_cpu_doubles(self):
        events, gpu_allocs, reports = [], [], []
        cases = requests(80, 5)
        proof = compile_proof(engine(), cases, device_rows=16384)
        cuda = Obj(type="cuda")
        pool = Obj(size=16384, page_size=PAGE_ROWS, layer_num=LAYERS, layer_shard_enabled=False,
                   kv_cache_dim=ROW_BYTES, store_dtype=Obj(itemsize=1), kv_buffer=[Obj(device=cuda) for _ in range(LAYERS)])

        class Event:
            def record(self):
                events.append("event-recorded")

            def wait(self, stream):
                events.append(("event-wait", stream))

        @contextmanager
        def stream(value):
            events.append(("enter-stream", value))
            yield
            events.append(("exit-stream", value))

        def gpu_empty(shape, **kwargs):
            gpu_allocs.append((shape, kwargs))
            return Obj(shape=shape, device=kwargs["device"])

        class Host:
            def __init__(self, **kwargs):
                self._is_dummy = kwargs["is_dummy"]
                self.pin_memory = kwargs["pin_memory"]

        class Coord:
            def __init__(self):
                self.mem_pool_host = module.MLATokenToKVPoolHost(device_pool=pool, page_size=PAGE_ROWS,
                                      layout="layer_first", host_to_device_ratio=2, host_size=0)
                self.is_dsv4_hisparse, self.compress_ratio, self.page_size, self.item_size_bytes = False, 1, PAGE_ROWS, ROW_BYTES
                self.device_buffer_size, self.top_k = HOT_SLOTS, TOP_K
                self.enable_prefetch = self.skip_io = self._has_pending_backup = False
                self.ack_staging_queue = []
                self._skip_first_backup = [True]
                self.req_to_host_pool_allocated_len = [0]
                self.write_staging_stream = "staging"

            def swap_in_selected_pages(self, *_args):
                events.append("stock-kernel")
                return "hot-indices"

            def request_finished(self, req):
                events.append(("native-finish", req.rid))

            def abort_staging_request(self, req):
                events.append(("native-abort", req.rid))

        class Scheduler:
            def _add_request_to_queue(self, req, is_retracted=False):
                events.append(("native-queue", req.rid, is_retracted))

        class ScheduleBatch:
            def prepare_for_extend(self):
                events.append("native-extend-allocation")

            def prepare_for_decode(self):
                events.append("native-decode-allocation")

        module = Obj(HiSparseCoordinator=Coord, MLATokenToKVPoolHost=Host,
                     device_module=Obj(Event=Event, stream=stream), HiSparseAct=lambda *args: args)
        _patched_classes(proof, 0, Obj(empty=gpu_empty), module, Scheduler, ScheduleBatch, reports.append, None)
        coord = Coord()
        self.assertIs(module.MLATokenToKVPoolHost, Host)
        self.assertTrue(coord.mem_pool_host._is_dummy)
        self.assertFalse(coord.mem_pool_host.pin_memory)
        self.assertEqual([shape for shape, _ in gpu_allocs], [(1, 1, ROW_BYTES)] * LAYERS)
        self.assertEqual(reports[0]["cold_payload_bytes"], 0)
        self.assertEqual(reports[0]["cold_pointer_sentinel_hbm_bytes"], LAYERS * ROW_BYTES)
        with self.assertRaisesRegex(RuntimeError, "cannot allocate"):
            coord.mem_pool_host.alloc_paged_token_slots(None)
        with self.assertRaisesRegex(RuntimeError, "cannot allocate"):
            coord._preload_to_device_buffer(None)

        req = Obj(rid="warmup-0", origin_input_ids=list(range(80)), sampling_params=Obj(max_new_tokens=5),
                  kv=Obj(req_pool_idx=0, kv_allocated_len=80), extend_range=Obj(end=80), hisparse_staging=False)
        scheduler = Scheduler()
        scheduler.ps, scheduler.enable_overlap, scheduler.hisparse_coordinator = Obj(tp_rank=0), False, coord
        scheduler._add_request_to_queue(req)
        batch = ScheduleBatch()
        batch.reqs, batch.seq_lens_cpu = [req], Vec([80])
        batch.prepare_for_extend()
        batch.prepare_for_decode()
        batch.seq_lens_cpu = Vec([85])
        with self.assertRaisesRegex(ValueError, "resident-only proof"):
            batch.prepare_for_decode()
        self.assertEqual(events.count("native-decode-allocation"), 1)
        req.extend_range.end = 86
        with self.assertRaisesRegex(ValueError, "resident-only proof"):
            batch.prepare_for_extend()
        self.assertEqual(events.count("native-extend-allocation"), 1)
        req.extend_range.end = 80

        coord.admit_request_into_staging(req)
        self.assertEqual(events[-5:], ["event-recorded", ("enter-stream", "staging"), ("event-wait", "staging"),
                                        "event-recorded", ("exit-stream", "staging")])
        self.assertEqual(len(coord.ack_staging_queue), 1)
        self.assertTrue(req.hisparse_staging)
        coord._eager_backup_previous_token(None, None, Vec([81]), Vec([0]))
        self.assertFalse(coord._skip_first_backup[0])
        with self.assertRaisesRegex(ValueError, "resident-only proof"):
            coord._eager_backup_previous_token(None, None, Vec([86]), Vec([0]))
        self.assertEqual(coord.swap_in_selected_pages(None, None, None, 0), "hot-indices")
        coord.request_finished(req)
        self.assertEqual(events[-1], ("native-finish", "warmup-0"))
        self.assertEqual(coord._resident_bounds_by_slot, {})
        with self.assertRaisesRegex(RuntimeError, "duplicate"):
            scheduler._add_request_to_queue(req)

        req.rid = "requests-0"
        scheduler._add_request_to_queue(req)
        coord.admit_request_into_staging(req)
        coord.abort_staging_request(req)
        self.assertEqual(events[-1], ("native-abort", "requests-0"))
        self.assertEqual(coord._resident_bounds_by_slot, {})


if __name__ == "__main__":
    unittest.main()
