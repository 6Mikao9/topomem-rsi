"""Rebind the three published native hot cases to their observed tokenizer commitments."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

from rsi_memory.memory_program import MemoryProgram, MemoryScenario
from rsi_memory.topology import HardwareTopology, fingerprint

from . import sglang_ingress_gate as ingress, sglang_serving as serving
from .sglang_observe import save


CAPACITIES = (4096, 6144, 8192)
OLD_TRANSFER = "68fed3bde713843765f7c97360d555d5235fb796827e58f3a232bf59fc48f4a5"
EVIDENCE = ("5e869567ab8475d8e6efba0a6878a2ebb5a1c15b71d03d34f1335f364d69df27",
            "d0706e049004d1fa98e38cb6d2894e6c45ddcab87f1848ab8478454831b8f644")
PREFIXES = ("hot-native-parity-v1", "hot-native-parity-v1-aa-repeat")


def _open_checked(path, expected):
    if serving._hash_file(path) != expected:
        raise ValueError(f"immutable prior archive differs: {path.name}")
    return ZipFile(path)


def _commitments(archives, old_manifests):
    observed = None
    result_digests = {}
    for archive, prefix in zip(archives, PREFIXES, strict=True):
        for slots in CAPACITIES:
            old = old_manifests[slots]
            raw = archive.read(f"{prefix}/hot-{slots}/result.json")
            result = json.loads(raw)
            if ((result["status"], result["arm"], result["phase"], result["attention_dp_size"])
                    != ("completed", "native", "parity", 2)
                    or (result["target_sha256"], result["scenario_sha256"], result["topology_sha256"], result["schedule_inputs_sha256"])
                    != (old["target_sha256"], old["scenario_sha256"], old["topology_sha256"], old["schedule_sha256"])):
                raise ValueError("token commitments are not from the actual prior bound case")
            tokens = {row["rid"]: {key: row[key] for key in ("input_tokens", "input_ids_sha256")}
                      for phase in ingress.PHASES for row in result[phase]}
            if len(tokens) != 4 or (observed is not None and tokens != observed):
                raise ValueError("actual prior model tokenization differed across runs")
            observed = tokens
            result_digests[f"{prefix}/{slots}"] = sha256(raw).hexdigest()
    return observed, result_digests


def rebind(old_path, evidence_path, repeat_path, output):
    with (_open_checked(old_path, OLD_TRANSFER) as old,
          _open_checked(evidence_path, EVIDENCE[0]) as evidence,
          _open_checked(repeat_path, EVIDENCE[1]) as repeat):
        transfer = json.loads(old.read("TRANSFER_MANIFEST.json"))

        def read(slots, name):
            key = f"cases/{slots}/{name}"
            raw = old.read(key)
            if sha256(raw).hexdigest() != transfer["files"][key]:
                raise ValueError("prior case member differs from its immutable binding")
            return raw

        prior = {slots: json.loads(read(slots, "manifest.json")) for slots in CAPACITIES}
        commitments, receipt_digests = _commitments((evidence, repeat), prior)
        output.mkdir(parents=True, exist_ok=False)
        rebound = {}
        for slots in CAPACITIES:
            raw = {name: read(slots, f"{name}.json") for name in ("fixture", "target", "topology", "scenario", "external_schedule")}
            fixture, target, graph, scenario, schedule = (json.loads(value) for value in raw.values())
            fixture = serving.validate_fixture(fixture)
            scenario = MemoryScenario.from_dict(scenario)
            graph = HardwareTopology.from_dict(graph)
            base = serving.schedule_inputs(fixture, 2, scenario.selector, attention_dp_size=2, hot_slots=slots)
            if (base != schedule or target["pool"]["hot_slots"] != slots or prior[slots]["target_sha256"] != fingerprint(target)
                    or prior[slots]["workload_sha256"] != fingerprint(fixture) or prior[slots]["schedule_sha256"] != fingerprint(base)
                    or prior[slots]["topology_sha256"] != graph.fingerprint() or prior[slots]["scenario_sha256"] != scenario.fingerprint()):
                raise ValueError("prior case is incompatible with frozen schedule construction")
            gated = ingress.bind_schedule(base, commitments)
            scenario = MemoryScenario.from_dict({**scenario.to_dict(), "schedule_sha256": fingerprint(gated)})
            plan, _ = serving._compile_plan(target, graph, scenario, MemoryProgram.from_dict(serving._PROGRAM), native=True)
            case = output / str(slots)
            case.mkdir()
            for name in ("fixture", "target", "topology"):
                with (case / f"{name}.json").open("xb") as stream:
                    stream.write(raw[name])
            for digest, relative in prior[slots]["link_evidence"].items():
                if relative != f"link_evidence/{digest}.data":
                    raise ValueError("invalid prior link evidence path")
                data = read(slots, relative)
                if sha256(data).hexdigest() != digest:
                    raise ValueError("prior link evidence content differs")
                (case / "link_evidence").mkdir(exist_ok=True)
                with (case / relative).open("xb") as stream:
                    stream.write(data)
            manifest = {**prior[slots], "scenario_sha256": scenario.fingerprint(), "schedule_sha256": scenario.schedule_sha256,
                        "compiled_preview_sha256": {"native": fingerprint(plan)}}
            provenance = {"schema": 1, "kind": "dp2_ingress_rebind_of_prior_native_case", "status": "bound_unverified",
                          "prior_transfer_sha256": OLD_TRANSFER, "prior_case_manifest_sha256": transfer["case_manifest_sha256"][str(slots)],
                          "token_evidence_zip_sha256s": list(EVIDENCE), "token_evidence_result_sha256s": receipt_digests,
                          "input_tokenization_sha256": fingerprint(commitments), "fixture_file_sha256": sha256(raw["fixture"]).hexdigest(),
                          "target_file_sha256": sha256(raw["target"]).hexdigest(), "topology_file_sha256": sha256(raw["topology"]).hexdigest(),
                          "ingress_contract_sha256": fingerprint(gated[ingress.EXTERNAL_FIELD])}
            for name, value in (("external_schedule", gated), ("scenario", scenario.to_dict()), ("native_plan_preview", plan),
                                ("ingress_rebind", provenance), ("manifest", manifest)):
                save(case / f"{name}.json", value)
            rebound[str(slots)] = serving._hash_file(case / "manifest.json")
    return rebound


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("old-transfer", "token-evidence", "token-repeat-evidence", "output"):
        parser.add_argument(f"--{key}", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(rebind(args.old_transfer, args.token_evidence, args.token_repeat_evidence, args.output), sort_keys=True))


if __name__ == "__main__":
    main()
