"""Worker-side paired resident-only qualification for the frozen 6144 case."""

import argparse
from dataclasses import asdict
from functools import wraps
import inspect
import json
import os
from pathlib import Path
import time

from integrations.topology_memory import sglang_backing as backing
from integrations.topology_memory import sglang_dependency as dependency
from integrations.topology_memory import sglang_global_ticks as global_ticks
from integrations.topology_memory import sglang_ingress_gate as ingress
from integrations.topology_memory import sglang_observe as observe
from integrations.topology_memory import sglang_serving as serving
from rsi_memory.topology import fingerprint

import resident_only
from resident_oracle import PackedProducerOracle, attach_oracle, torch_row_reader


def _request_bindings(fixture, tokenized):
    return [{"phase": phase, "rid": row["rid"], "rank": row["routed_dp_rank"],
             "input_ids": tokenized[row["rid"]], "max_new_tokens": row["max_new_tokens"]}
            for phase in resident_only.PHASES for row in fixture[phase]]


def _make_proof(engine, rows):
    return resident_only.compile_proof(engine, rows, device_rows=engine["max_total_tokens"])


def _worker(*args, **kwargs):
    import torch
    from sglang.srt.managers import hisparse_coordinator as coordinator
    from sglang.srt.managers.scheduler import Scheduler, run_scheduler_process

    directory = Path(os.environ["TOPOMEM_RESIDENT_RUN"])
    job = serving._load(directory / "worker_input.json")
    bound = inspect.signature(run_scheduler_process).bind(*args, **kwargs).arguments
    rank, gpu_id = bound["tp_rank"], bound["gpu_id"]
    info = job["plans"][rank]
    plan = backing.RankBacking(**{**info, "layer_tiers": tuple(info["layer_tiers"])})
    if plan.rank != rank or plan.compute_device != gpu_id:
        raise RuntimeError("actual worker rank differs from the fixed DP2 binding")
    proof = _make_proof(job["engine"], job["requests"])
    if proof.fingerprint() != job["proof_sha256"]:
        raise ValueError("worker resident proof differs from the parent binding")
    oracle = PackedProducerOracle(torch_row_reader(torch)) if job["phase"] == "parity" else None
    report = lambda event: observe.append(directory / f"backing-rank-{rank}.jsonl", event)
    dependency.install(directory / f"backup-rank-{rank}.jsonl")
    if job["mode"] == "stock":
        backing.install(plan, report)
        if oracle is not None:
            attach_oracle(coordinator.HiSparseCoordinator, coordinator.HiSparseDSATokenToKVPool, oracle)
    elif job["mode"] == "resident":
        resident_only.install(proof, engine=job["engine"], rank=rank, report=report, diagnostic=oracle)
    else:
        raise ValueError("unknown trusted backing mode")
    ingress.install(job["gate"], rank, directory)
    expected = {rid: item.max_new_tokens - 1 for rid, item in proof.for_rank(rank).items()}
    observe.install_scheduler_observer(directory, plan, list(expected), None, record_global_ticks=True)
    original_process = Scheduler.process_batch_result
    marker = directory / f"kv-rank-{rank}.jsonl"
    output = directory / f"resident-worker-rank-{rank}.json"

    @wraps(original_process)
    def complete(self, batch, *process_args, **process_kwargs):
        result = original_process(self, batch, *process_args, **process_kwargs)
        if not marker.exists() and (oracle is not None and oracle.swaps > 0 or batch.forward_mode.is_decode() and batch.reqs):
            observe.append(marker, {"rank": rank, "pid": os.getpid(), "event": "resident_probe_real_decode"})
        if not output.exists() and (directory / f"dispatch-rank-{rank}.json").is_file():
            coordinator = self.hisparse_coordinator
            pool = coordinator.mem_pool_host
            cold_bytes = sum(buffer.numel() * buffer.element_size() for buffer in pool.kv_buffer)
            resident = job["mode"] == "resident"
            expected_bytes = resident_only.LAYERS * resident_only.ROW_BYTES if resident else plan.pinned_host_bytes
            if cold_bytes != expected_bytes or bool(pool._is_dummy) != resident or bool(pool.pin_memory) == resident:
                raise RuntimeError("actual cold storage does not match the selected backing mode")
            hot_metadata = (coordinator.req_to_device_buffer, coordinator.req_device_buffer_tokens,
                            coordinator.req_device_buffer_token_locs, coordinator._lru_init, coordinator.lru_slots,
                            coordinator._device_buffer_arange_i32, coordinator.req_to_host_pool)
            hot = {"physical_rows": coordinator.mem_pool_device.kv_buffer[0].shape[0],
                   "logical_device_rows": coordinator.mem_pool_device.size, "slots": coordinator.device_buffer_size,
                   "metadata_bytes": sum(tensor.nbytes for tensor in hot_metadata),
                   "packed_device_payload_bytes": sum(tensor.nbytes for tensor in coordinator.mem_pool_device.kv_buffer)}
            observe.publish(output, {"rank": rank, "pid": os.getpid(), "mode": job["mode"], "proof_sha256": proof.fingerprint(),
                                     "cold_payload_bytes": 0 if resident else cold_bytes,
                                     "cuda_pointer_sentinel_logical_bytes": cold_bytes if resident else 0,
                                     "hot_geometry": hot,
                                     "oracle": None if oracle is None else oracle.result(expected)})
        return result

    Scheduler.process_batch_result = complete
    return run_scheduler_process(*args, **kwargs)


def _rank_evidence(directory, plans, rows, mode, phase, proof):
    records, observations = [], []
    for plan in plans:
        rank = plan.rank
        expected = proof.for_rank(rank)
        assigned = [row for row in rows if row["routed_dp_rank"] == rank]
        if {row["rid"] for row in assigned} != set(expected) or any(len(row["output_ids"]) != expected[row["rid"]].max_new_tokens for row in assigned):
            raise ValueError("serving did not finish the exact fixed request token budget")
        schedule = serving._load(directory / f"schedule-rank-{rank}.json")
        dispatch = serving._load(directory / f"dispatch-rank-{rank}.json")
        worker = serving._load(directory / f"resident-worker-rank-{rank}.json")
        observed = serving._load(directory / f"global-ticks-rank-{rank}.json")
        if (worker["rank"] != dispatch["rank"] or worker["rank"] != observed["rank"] or worker["rank"] != rank
                or worker["pid"] != schedule["pid"] or worker["pid"] != observed["pid"] or worker["mode"] != mode
                or worker["proof_sha256"] != proof.fingerprint() or dispatch["finished"] != sorted(expected)
                or {rid for batch in dispatch["batches"] for rid in batch["request_ids"]} != set(expected)):
            raise ValueError("resident worker evidence does not bind actual requests, rank and process")
        parallel = schedule["parallel"]
        if parallel["attention_dp_size"] != 2 or parallel["attention_dp_rank"] != rank or parallel["attention_tp_size"] != 1:
            raise ValueError("resident qualification changed the actual attention partition")
        backup = [json.loads(line)["event"] for line in (directory / f"backup-rank-{rank}.jsonl").read_bytes().splitlines()]
        expected_backup = ["backup_dependency_installed"] + (["backup_dependency_exercised"] if mode == "stock" else [])
        bytes_total = sum(dispatch["backup_payload_bytes_by_tier"].values())
        if backup != expected_backup or (bytes_total == 0) != (mode == "resident"):
            raise ValueError("actual backup dependency or D2H payload differs from backing mode")
        if (worker["oracle"] is not None) != (phase == "parity"):
            raise ValueError("diagnostic and timing observations were mixed")
        events = [json.loads(line) for line in (directory / f"backing-rank-{rank}.jsonl").read_bytes().splitlines()]
        name = "hisparse_cold_backing_bound" if mode == "stock" else "resident_only_installed"
        binds = [entry for entry in events if entry["event"] == name]
        if len(binds) != 1:
            raise ValueError("worker lacked one actual backing binding")
        if mode == "stock":
            if binds[0]["cuda_device"] != plan.compute_device or tuple(binds[0]["layer_tiers"]) != plan.layer_tiers:
                raise ValueError("stock arm did not keep all-host backing")
        elif binds[0]["proof_sha256"] != proof.fingerprint() or binds[0]["rank"] != rank:
            raise ValueError("resident binding does not match the input proof")
        records.append({"schedule": schedule["effective"], "dispatch": dispatch, "backing": binds[0], "worker": worker})
        observations.append(observed)
    return records, observations


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("model", "target", "topology", "scenario", "fixture", "external-schedule", "output"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    parser.add_argument("--mode", choices=("stock", "resident"), required=True)
    parser.add_argument("--phase", choices=("parity", "performance"), required=True)
    parser.add_argument("--link-evidence", type=Path, action="append", default=[])
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--deadline", type=int, default=300)
    args = parser.parse_args()
    args.arm, args.program, args.require_remote = "native", None, False
    directory = args.output.resolve()
    directory.mkdir(parents=True, exist_ok=False)
    result = {"schema": 1, "mode": args.mode, "phase": args.phase, "status": "started",
              "source_manifest_sha256": args.manifest_sha256, "scope": "tiny GLM DSA fixed replay with original native hot pool"}
    engine = None
    try:
        import sglang
        import torch
        from sglang.srt.entrypoints.engine import Engine

        backing.check_sources(sglang)
        target, fixture, scenario, external, model, compiled, plans, tokenized = serving._bind(args)
        gate = external[ingress.EXTERNAL_FIELD]
        requests = _request_bindings(fixture, tokenized)
        proof = _make_proof(external["engine"], requests)
        fixed_env = {name: os.environ.get(name) for name in ("SGLANG_DSA_FUSE_TOPK", "SGLANG_DISABLE_HISPARSE_PREFETCH")}
        if fixed_env != {"SGLANG_DSA_FUSE_TOPK": "0", "SGLANG_DISABLE_HISPARSE_PREFETCH": "1"}:
            raise ValueError("resident probe requires the frozen selector and prefetch settings")
        result.update(target_sha256=scenario.target_sha256, scenario_sha256=scenario.fingerprint(),
                      topology_sha256=compiled["topology_sha256"], schedule_inputs_sha256=fingerprint(external),
                      input_tokenization_sha256=fingerprint(serving._token_commitments(tokenized)),
                      ingress_contract_sha256=fingerprint(gate), resident_proof_sha256=proof.fingerprint(),
                      runtime={"gpus": serving._observed_gpus(torch, target), "sglang": sglang.__version__,
                               "torch": str(torch.__version__), "cuda_build": torch.version.cuda, "fixed_environment": fixed_env,
                               "nccl_sha256": serving._hash_file(Path(os.environ["SGLANG_NCCL_SO_PATH"]))})
        observe.save(directory / "worker_input.json", {"engine": external["engine"], "gate": gate, "requests": requests,
                     "plans": [asdict(plan) for plan in plans], "proof_sha256": proof.fingerprint(),
                     "mode": args.mode, "phase": args.phase})
        os.environ["TOPOMEM_RESIDENT_RUN"] = str(directory)

        class ResidentEngine(Engine):
            run_scheduler_process_func = staticmethod(_worker)

        engine = ResidentEngine(model_path=str(model), **external["engine"])
        if engine.tokenizer_manager.incremental_streaming_output:
            raise ValueError("resident probe requires the audited cumulative streaming interface")

        async def replay():
            warmup = await serving._replay(engine, fixture["warmup"], tokenized, args.deadline)
            measured = await serving._replay(engine, fixture["requests"], tokenized, args.deadline)
            return warmup, measured

        warmup, measured = engine.loop.run_until_complete(replay())
        deadline = time.monotonic() + 15
        paths = [directory / f"{prefix}-rank-{rank}.json" for rank in range(2)
                 for prefix in ("dispatch", "global-ticks", "resident-worker")]
        while time.monotonic() < deadline and not all(path.is_file() for path in paths):
            time.sleep(.02)
        if not all(path.is_file() for path in paths):
            raise TimeoutError("resident probe did not publish both workers' complete evidence")
        rows = [*warmup, *measured]
        rank_records, observations = _rank_evidence(directory, plans, rows, args.mode, args.phase, proof)
        releases = [[json.loads(line) for line in (directory / f"ingress-rank-{rank}.jsonl").read_bytes().splitlines()] for rank in range(2)]
        ingress_report = ingress.verify_ingress_events(releases, gate)
        if any(releases[rank][0]["pid"] != record["worker"]["pid"] for rank, record in enumerate(rank_records)):
            raise ValueError("global shape evidence and the ingress worker identities differ")
        ticks = global_ticks.verify_global_ticks([row["ticks"] for row in observations], gate)
        result.update(status="completed", warmup=warmup, requests=measured, ranks=rank_records, ingress=ingress_report,
                      global_ticks=ticks, global_ticks_sha256=ticks["global_ticks_sha256"],
                      effective_schedule_sha256=fingerprint([rank["schedule"] for rank in rank_records]),
                      dispatch_sha256=fingerprint([rank["dispatch"]["batches"] for rank in rank_records]),
                      output_ids_sha256=fingerprint([(row["rid"], row["input_ids_sha256"], row["output_ids"]) for row in rows]),
                      producer_and_selected_sha256_by_rank=[rank["worker"]["oracle"]["producer_and_selected_sha256"] for rank in rank_records]
                      if args.phase == "parity" else None)
        if args.phase == "performance":
            result["metrics"] = serving._metrics(measured)
    except Exception as exc:
        result.update(status="failed", error_type=type(exc).__name__, error=str(exc))
        raise
    finally:
        try:
            if engine is not None:
                engine.shutdown()
        finally:
            observe.save(directory / "result.json", result)


if __name__ == "__main__":
    main()
