"""Proof and worker hooks for the fixed CUDA GLM HiSparse short path."""

from dataclasses import asdict, dataclass
from functools import wraps
from hashlib import sha256
import json
from pathlib import Path


HOT_SLOTS = 6144
TOP_K = 2048
PAGE_ROWS = 64
ROW_BYTES = 656
LAYERS = 6
PHASES = ("warmup", "requests")
ENGINE_FIELDS = {
    "tp_size": 2, "dp_size": 2, "pp_size": 1, "enable_dp_attention": True,
    "enable_hisparse": True, "disable_radix_cache": True,
    "disable_cuda_graph": True, "disable_overlap_schedule": True,
    "kv_cache_dtype": "fp8_e4m3", "dsa_prefill_backend": "flashinfer_sparse_mla",
    "dsa_decode_backend": "flashinfer_sparse_mla", "dsa_topk_backend": "torch",
}
EXTRA_SOURCES = {
    "srt/mem_cache/allocator/hisparse.py": "7905663ae85954276fea4e752d2ce5caa3cb9434f450bb68a82ea72a3d4db712",
    "srt/mem_cache/hisparse_memory_pool.py": "fb266ef79ef763b0a2401112a5e9cd696bb8dac4421f8c2f6c909d4521fb2118",
    "srt/mem_cache/pool_host/hisparse.py": "0f94fd23d74613556ac5dbca59d8399fd3c5f6cbfc8758775bedb5fb5b8f9e01",
}


def fingerprint(value):
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
    return sha256(raw.encode()).hexdigest()


def _round_page(length):
    return (length + PAGE_ROWS - 1) // PAGE_ROWS * PAGE_ROWS


def reserved_rows(length):
    if type(length) is not int or not 1 <= length <= HOT_SLOTS:
        raise ValueError("request exceeds the resident-only hot range")
    rounded = _round_page(length)
    return rounded + (PAGE_ROWS if rounded == HOT_SLOTS else 0)


def _tokens(ids):
    values = list(ids)
    if not values or any(type(token) is not int or token < 0 for token in values):
        raise ValueError("resident-only requires exact nonnegative token IDs")
    return values


@dataclass(frozen=True)
class RequestBound:
    phase: str
    rid: str
    rank: int
    prompt_length: int
    prompt_sha256: str
    max_new_tokens: int

    @property
    def length(self):
        return self.prompt_length + self.max_new_tokens


@dataclass(frozen=True)
class ResidentProof:
    engine_sha256: str
    device_rows: int
    reserved_rows_by_rank: tuple[int, int]
    requests: tuple[RequestBound, ...]

    def fingerprint(self):
        return fingerprint(asdict(self))

    def for_rank(self, rank):
        if type(rank) is not int or rank not in (0, 1):
            raise ValueError("resident-only worker requires a fixed rank 0 or 1")
        return {request.rid: request for request in self.requests if request.rank == rank}


def compile_proof(engine, requests, *, device_rows):
    """Bind tokenized warmup and measured requests to native per-rank hot capacity."""
    if type(engine) is not dict or any(type(engine.get(key)) is not type(value) or engine[key] != value
                                       for key, value in ENGINE_FIELDS.items()):
        raise ValueError("resident-only requires the fixed DP2 GLM DSA engine")
    if (engine.get("speculative_algorithm") is not None or engine.get("disaggregation_mode", "null") != "null"
            or engine.get("enable_prefill_cp", False) or engine.get("attn_dcp_size", 1) != 1
            or engine.get("enable_hierarchical_cache", False) or engine.get("disaggregation_decode_enable_offload_kvcache", False)
            or engine.get("sleep_on_idle", False) or engine.get("scheduler_recv_interval", 1) != 1):
        raise ValueError("resident-only forbids speculative, prefix/offload and alternate scheduler paths")
    try:
        pool = json.loads(engine["hisparse_config"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("resident-only requires a bound native HiSparse configuration") from exc
    if pool != {"device_buffer_size": HOT_SLOTS, "top_k": TOP_K, "host_to_device_ratio": 2}:
        raise ValueError("resident-only requires unchanged 6144-slot native hot geometry")
    if (type(device_rows) is not int or device_rows <= 0 or device_rows % PAGE_ROWS
            or engine.get("max_total_tokens") != device_rows):
        raise ValueError("resident-only requires the measured native device allocator size")

    bounds = []
    for request in requests:
        if type(request) is not dict or request.keys() != {"phase", "rid", "rank", "input_ids", "max_new_tokens"}:
            raise ValueError("invalid resident-only request binding")
        phase, rid, rank, maximum = (request[key] for key in ("phase", "rid", "rank", "max_new_tokens"))
        if (phase not in PHASES or type(rid) is not str or not 1 <= len(rid) <= 160
                or type(rank) is not int or rank not in (0, 1) or type(maximum) is not int or maximum < 1):
            raise ValueError("resident-only requires four fixed routed text requests")
        ids = _tokens(request["input_ids"])
        bounds.append(RequestBound(phase, rid, rank, len(ids), fingerprint(ids), maximum))
    if (len(bounds) != 4 or len({bound.rid for bound in bounds}) != 4
            or {(bound.phase, bound.rank) for bound in bounds} != {(phase, rank) for phase in PHASES for rank in (0, 1)}):
        raise ValueError("resident-only requires one unique request per phase and rank")
    # Do not rely on warmup cleanup racing measured arrival. Charge both requests at their maximum.
    rows = tuple(sum(reserved_rows(bound.length) for bound in bounds if bound.rank == rank) for rank in (0, 1))
    if any(count > device_rows for count in rows):
        raise ValueError("resident-only proof exceeds the existing physical page budget")
    return ResidentProof(fingerprint(engine), device_rows, rows, tuple(bounds))


def check_request(bounds, rid, ids, max_new_tokens):
    bound = bounds.get(rid)
    if bound is None or type(max_new_tokens) is not int or max_new_tokens != bound.max_new_tokens:
        raise ValueError("request differs from the sealed resident-only input")
    values = _tokens(ids)
    if len(values) != bound.prompt_length or fingerprint(values) != bound.prompt_sha256:
        raise ValueError("request token IDs differ from the sealed resident-only input")
    return bound


def check_length(bound, length):
    if type(length) is not int or not 1 <= length <= bound.length or length > HOT_SLOTS:
        raise ValueError("live request exceeds its resident-only proof")


def _no_cold_allocations(coordinator):
    if coordinator._has_pending_backup or not coordinator.mem_pool_host._is_dummy:
        raise RuntimeError("resident-only encountered an active cold backup path")


def _stage_without_backup(coordinator, req, device_module, staging_record):
    _no_cold_allocations(coordinator)
    req.hisparse_staging = True
    start_event = device_module.Event()
    finish_event = device_module.Event()
    start_event.record()
    with device_module.stream(coordinator.write_staging_stream):
        start_event.wait(coordinator.write_staging_stream)
        finish_event.record()
    coordinator.ack_staging_queue.append(staging_record(start_event, finish_event, req))


def _patched_classes(proof, rank, torch, coordinator_module, scheduler, schedule_batch, report, diagnostic):
    """Install only on a dedicated worker before any coordinator is initialized."""
    bounds = proof.for_rank(rank)
    admitted = set()
    coordinator = coordinator_module.HiSparseCoordinator
    if (getattr(coordinator, "_resident_only_installed", False)
            or getattr(coordinator, "_rsi_cold_backing", False)):
        raise RuntimeError("resident-only requires a fresh non-tiered scheduler worker")
    host_cls = coordinator_module.MLATokenToKVPoolHost

    def unavailable(*_args, **_kwargs):
        raise RuntimeError("resident-only worker cannot allocate or transfer cold KV")

    def dummy_host(*args, **kwargs):
        pool = kwargs.get("device_pool")
        if (args or pool is None or kwargs.get("layout") != "layer_first" or kwargs.get("page_size") != PAGE_ROWS
                or kwargs.get("host_to_device_ratio") != 2 or kwargs.get("host_size") != 0
                or pool.size != proof.device_rows or pool.page_size != PAGE_ROWS or pool.layer_num != LAYERS
                or pool.kv_cache_dim * pool.store_dtype.itemsize != ROW_BYTES or pool.layer_shard_enabled):
            raise RuntimeError("resident-only worker differs from the proved native device geometry")
        if len(pool.kv_buffer) != LAYERS or any(buffer.device.type != "cuda" for buffer in pool.kv_buffer):
            raise RuntimeError("resident-only requires six CUDA packed KV slabs")
        host = host_cls(**kwargs, is_dummy=True, pin_memory=False)
        # The stock launch resolves a host_cache TensorView pointer even on its no-miss path.
        # Independent CUDA sentinels keep that ABI valid without allocating cold KV pages.
        host.kv_buffer = [torch.empty((1, 1, pool.kv_cache_dim), dtype=pool.store_dtype,
                                      device=buffer.device) for buffer in pool.kv_buffer]
        host.alloc_paged_token_slots = unavailable
        host.backup_from_device_all_layer = unavailable
        host.load_to_device_per_layer = unavailable
        return host

    init = coordinator.__init__

    @wraps(init)
    def initialize(self, *args, **kwargs):
        if coordinator_module.MLATokenToKVPoolHost is not host_cls:
            raise RuntimeError("resident-only cold pool constructor is already altered")
        coordinator_module.MLATokenToKVPoolHost = dummy_host
        try:
            init(self, *args, **kwargs)
        finally:
            coordinator_module.MLATokenToKVPoolHost = host_cls
        if (self.is_dsv4_hisparse or self.compress_ratio != 1 or self.page_size != PAGE_ROWS or self.item_size_bytes != ROW_BYTES
                or self.device_buffer_size != HOT_SLOTS or self.top_k != TOP_K
                or self.enable_prefetch or self.skip_io or not self.mem_pool_host._is_dummy):
            raise RuntimeError("resident-only requires unchanged stock short-path dispatch")
        self._resident_bounds_by_slot = {}
        self._resident_proof = proof
        report({"event": "resident_only_installed", "rank": rank, "proof_sha256": proof.fingerprint(),
                "reserved_rows_bound": proof.reserved_rows_by_rank[rank], "device_rows": proof.device_rows,
                "cold_payload_bytes": 0, "cold_pointer_sentinel_hbm_bytes": LAYERS * ROW_BYTES,
                "diagnostic_enabled": diagnostic is not None})

    add_request = scheduler._add_request_to_queue

    @wraps(add_request)
    def queue_request(self, req, is_retracted=False):
        if (is_retracted or req.rid in admitted or self.ps.tp_rank != rank or self.enable_overlap
                or self.hisparse_coordinator._resident_proof != proof):
            raise RuntimeError("unexpected retraction, duplicate or scheduler in resident-only replay")
        check_request(bounds, req.rid, req.origin_input_ids, req.sampling_params.max_new_tokens)
        admitted.add(req.rid)
        return add_request(self, req, is_retracted=is_retracted)

    prepare_extend = schedule_batch.prepare_for_extend
    prepare_decode = schedule_batch.prepare_for_decode

    @wraps(prepare_extend)
    def extend(self):
        for req in self.reqs:
            bound = bounds.get(req.rid)
            if req.rid not in admitted or bound is None:
                raise RuntimeError("unproved request reached resident prefill allocation")
            check_length(bound, req.extend_range.end)
        return prepare_extend(self)

    @wraps(prepare_decode)
    def decode(self):
        lengths = self.seq_lens_cpu.tolist()
        if len(lengths) != len(self.reqs):
            raise RuntimeError("resident decode request/length cardinality differs")
        for req, length in zip(self.reqs, lengths):
            bound = bounds.get(req.rid)
            if req.rid not in admitted or bound is None:
                raise RuntimeError("unproved request reached resident decode allocation")
            check_length(bound, length + 1)
        return prepare_decode(self)

    def stage(self, req):
        slot = req.kv.req_pool_idx
        bound = bounds.get(req.rid)
        if req.rid not in admitted or bound is None or slot in self._resident_bounds_by_slot:
            raise RuntimeError("unproved or reused request slot reached resident staging")
        check_length(bound, req.extend_range.end)
        check_length(bound, req.kv.kv_allocated_len)
        self._resident_bounds_by_slot[slot] = bound
        _stage_without_backup(self, req, coordinator_module.device_module, coordinator_module.HiSparseAct)

    def omit_decode_backup(self, _seq_lens, _req_pool_indices, seq_lens_cpu, req_pool_indices_cpu):
        _no_cold_allocations(self)
        lengths, slots = seq_lens_cpu.tolist(), req_pool_indices_cpu.tolist()
        if len(lengths) != len(slots):
            raise RuntimeError("resident backup metadata cardinality differs")
        for slot, length in zip(slots, lengths):
            check_length(self._resident_bounds_by_slot[slot], length)
            if self.req_to_host_pool_allocated_len[slot]:
                raise RuntimeError("resident-only request acquired cold slots")
            self._skip_first_backup[slot] = False

    for method in ("request_finished", "abort_staging_request"):
        original = getattr(coordinator, method)

        def wrap_release(native):
            @wraps(native)
            def release(self, req):
                _no_cold_allocations(self)
                slot = req.kv.req_pool_idx
                outcome = native(self, req)
                self._resident_bounds_by_slot.pop(slot, None)
                return outcome
            return release

        setattr(coordinator, method, wrap_release(original))

    coordinator.__init__ = initialize
    coordinator.admit_request_into_staging = stage
    coordinator._eager_backup_previous_token = omit_decode_backup
    coordinator.admit_request_direct = unavailable
    coordinator._preload_to_device_buffer = unavailable
    coordinator.naive_load_topk = unavailable
    coordinator._resident_only_installed = True
    scheduler._add_request_to_queue = queue_request
    schedule_batch.prepare_for_extend = extend
    schedule_batch.prepare_for_decode = decode
    if diagnostic is not None:
        from resident_oracle import attach_oracle

        attach_oracle(coordinator, coordinator_module.HiSparseDSATokenToKVPool, diagnostic)


def install(proof, *, engine, rank, report, diagnostic=None):
    """Bind the draft in an isolated worker. The launcher must supply the proved engine."""
    import sglang
    import torch
    from integrations.topology_memory.sglang_sources import check_sources
    from sglang.srt.environ import envs
    from sglang.srt.managers import hisparse_coordinator
    from sglang.srt.managers.schedule_batch import ScheduleBatch
    from sglang.srt.managers.scheduler import Scheduler

    if type(proof) is not ResidentProof or not callable(report):
        raise TypeError("resident-only requires a compiler proof and trusted reporting callback")
    if fingerprint(engine) != proof.engine_sha256:
        raise ValueError("resident-only engine differs from the compiled proof")
    root = check_sources(sglang)
    for relative, expected in EXTRA_SOURCES.items():
        if sha256((Path(root) / relative).read_bytes()).hexdigest() != expected:
            raise ValueError(f"resident-only source identity differs for {relative}")
    if envs.SGLANG_DSA_FUSE_TOPK.get() or not envs.SGLANG_DISABLE_HISPARSE_PREFETCH.get():
        raise ValueError("resident-only requires the already qualified unfused selector and no prefetch")
    if getattr(hisparse_coordinator, "MLATokenToKVPoolHost", None) is None:
        raise ValueError("resident-only requires the stock CUDA MLA host constructor")
    _patched_classes(proof, rank, torch, hisparse_coordinator, Scheduler, ScheduleBatch, report, diagnostic)
