from pathlib import Path
import subprocess,json,hashlib,time
r=Path('/home/liuyuntao/experiments/rsi-topology-20261110')
base=['python3','-B',str(r/'resident-probe-stage-v3/run_resident_qualification.py'),'--expected-manifest-sha256','0f64a120aafa242f65efcef4cdf2cfaa9caa268bf8a10c5362d639ad28a66fff','--launch-config',str(r/'ingress-probe-stage-v1/profile-tools/sglang_launch.json'),'--gated-run',str(r/'ingress-native-parity-v1'),'--expected-gate-sha256','a8c385514f2ebe7732f5bffcf8e4dd4f2c66171e7a1462dea30bfec413648012']
for phase in ('parity','performance'):
    cmd=base+['--phase',phase,'--output',str(r/f'resident-{phase}-v3')]
    if phase=='performance':
        q=r/'resident-parity-v3/qualification.json';proof=json.loads(q.read_bytes())
        assert proof['qualified'] is True
        cmd+=['--qualified-run',str(q.parent),'--expected-qualified-sha256',hashlib.sha256(q.read_bytes()).hexdigest()]
    start=time.time()
    with (r/f'resident-{phase}-v3.controller.log').open('xb') as log:
        code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
    print(json.dumps({'phase':phase,'returncode':code,'elapsed_s':time.time()-start}),flush=True)
    if code: raise SystemExit(code)
