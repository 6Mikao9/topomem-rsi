#!/usr/bin/env python3
"""Run and attest the three stock native HiSparse capacity probes on leased GPUs."""

import argparse
from datetime import datetime, timezone
from hashlib import sha256
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import signal
import subprocess
import sys
import time


CAPACITIES = (4096, 6144, 8192)
NCCL_VERSION_CODE = 23203


def hash_file(path):
    digest = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024**2), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_stage(root, expected):
    path = root / "TRANSFER_MANIFEST.json"
    if path.is_symlink() or hash_file(path) != expected:
        raise ValueError("hot probe transfer manifest digest differs")
    manifest = json.loads(path.read_bytes())
    if manifest.get("schema") != 1 or manifest.get("capacities") != list(CAPACITIES):
        raise ValueError("unexpected hot probe transfer format")
    files = manifest["files"]
    for name, digest in files.items():
        member = PurePosixPath(name)
        if member.is_absolute() or member.as_posix() != name or ".." in member.parts or "\\" in name:
            raise ValueError("invalid hot probe transfer path")
        target = root / member
        if target.is_symlink() or not target.resolve(strict=True).is_relative_to(root) or hash_file(target) != digest:
            raise ValueError("hot probe transfer member changed: " + name)
    actual = set()
    for item in root.rglob("*"):
        if item.is_symlink():
            raise ValueError("hot probe transfer cannot contain symlinks")
        if item.is_file():
            actual.add(item.relative_to(root).as_posix())
    if actual != {*files, "TRANSFER_MANIFEST.json"}:
        raise ValueError("unexpected or missing files in the immutable hot probe stage")
    return manifest


def _mapped_nccl(lines):
    records = {}
    for line in lines.splitlines():
        parts = line.split(maxsplit=5)
        if len(parts) != 6 or not parts[5].startswith("/"):
            continue
        path = parts[5]
        if not Path(path.removesuffix(" (deleted)")).name.startswith("libnccl.so"):
            continue
        key = (parts[3], parts[4], path)
        records.setdefault(key, []).append(line)
    return records


def _sample_worker(directory, leader, supervisor, rank, state):
    schedule = directory / f"schedule-rank-{rank}.json"
    if not schedule.is_file():
        return
    record = json.loads(schedule.read_bytes())
    pid = record["pid"]
    if record["rank"] != rank or type(pid) is not int or pid <= 0:
        raise ValueError("unexpected scheduler worker identity")
    try:
        if os.getpgid(pid) != leader:
            raise ValueError("scheduler receipt PID is outside the process group owned by this probe")
        started = supervisor._proc_starttime(pid)
        if started is None:
            return
        lines = (Path("/proc") / str(pid) / "maps").read_text()
        if os.getpgid(pid) != leader or supervisor._proc_starttime(pid) != started:
            return
    except ProcessLookupError:
        return
    except FileNotFoundError:
        return
    if state["pid"] not in (None, pid) or state["process_starttime"] not in (None, started):
        raise ValueError("owned worker PID identity changed during the probe")
    state["pid"], state["process_starttime"] = pid, started
    observed_env = dict(item.split(b"=", 1) for item in (Path("/proc") / str(pid) / "environ").read_bytes().split(b"\0") if b"=" in item)
    workspace = observed_env.get(b"CUBLAS_WORKSPACE_CONFIG", b"").decode("ascii")
    if workspace != ":16:8":
        raise ValueError("owned worker did not inherit the frozen cuBLAS workspace")
    state["cublas_workspace_config"] = workspace
    observed = _mapped_nccl(lines)
    state["maps_samples"] += 1
    diagnostic = directory / f"kv-rank-{rank}.jsonl"
    if observed and diagnostic.is_file() and diagnostic.stat().st_size:
        state["maps_samples_after_decode"] += 1
    for (device, inode, path), raw in observed.items():
        key = f"{device}/{inode}/{path}"
        if key not in state["libraries"]:
            state["libraries"][key] = {"path": path, "maps_device": device, "maps_inode": inode, "lines": raw}


def _finish_nccl(states, expected, digest, version):
    expected_path = expected.resolve(strict=True)
    stat = expected_path.stat()
    hashed = {}
    valid = True
    for state in states:
        libraries = list(state.pop("libraries").values())
        state["libraries"] = libraries
        for record in libraries:
            path = Path(record["path"])
            try:
                major, minor = (int(value, 16) for value in record["maps_device"].split(":"))
                actual = path.stat()
                same_inode = actual.st_ino == int(record["maps_inode"]) and (os.major(actual.st_dev), os.minor(actual.st_dev)) == (major, minor)
                key = (actual.st_dev, actual.st_ino)
                if same_inode and key not in hashed:
                    hashed[key] = hash_file(path)
                record["sha256"] = hashed.get(key) if same_inode else None
                record["qualified"] = (same_inode and path.resolve(strict=True) == expected_path and actual.st_ino == stat.st_ino
                                        and actual.st_dev == stat.st_dev and record["sha256"] == digest)
            except (OSError, ValueError):
                record.update(sha256=None, qualified=False)
            if record["qualified"]:
                record["nccl_get_version"] = version
        if (not state["maps_samples_after_decode"] or len(libraries) != 1 or not libraries[0]["qualified"]
                or state.get("cublas_workspace_config") != ":16:8"):
            valid = False
    return valid


def _nccl_version(python, env, nccl):
    code = """import ctypes,sys
lib = ctypes.CDLL(sys.argv[1])
value = ctypes.c_int()
lib.ncclGetVersion.argtypes = [ctypes.POINTER(ctypes.c_int)]
lib.ncclGetVersion.restype = ctypes.c_int
if lib.ncclGetVersion(ctypes.byref(value)) != 0:
    raise RuntimeError('ncclGetVersion failed')
print(value.value)
"""
    value = int(subprocess.check_output([python, "-B", "-c", code, str(nccl)], env=env, text=True, timeout=30).strip())
    if value != NCCL_VERSION_CODE:
        raise ValueError("qualified NCCL binary reported the wrong version")
    return value


def _run_one(root, runs, slots, python, environment, launch, supervisor, timeout, version):
    case = root / "cases" / str(slots)
    output = runs / f"hot-{slots}"
    evidence = sorted((case / "link_evidence").iterdir())
    command = [python, "-B", "-m", "integrations.topology_memory.sglang_serving", "--model", launch["model"],
               "--target", str(case / "target.json"), "--topology", str(case / "topology.json"),
               "--scenario", str(case / "scenario.json"), "--fixture", str(case / "fixture.json"), "--output", str(output),
               "--arm", "native", "--phase", "parity", "--deadline", "300"]
    for item in evidence:
        command.extend(("--link-evidence", str(item)))
    fields = "uuid,memory.used,utilization.gpu,temperature.gpu,power.draw"
    indices = launch["gpu_indices"]
    state = [{"rank": rank, "pid": None, "process_starttime": None, "maps_samples": 0, "maps_samples_after_decode": 0,
              "libraries": {}} for rank in range(2)]
    receipt = {"schema": 1, "status": "started", "hot_slots": slots, "argv": command,
               "utc_start": datetime.now(timezone.utc).isoformat(), "gpu_before": supervisor.query(indices, fields), "nccl_workers": state}
    process = None
    failure = None
    clock = time.monotonic()
    try:
        with (runs / f"hot-{slots}.process.log").open("xb") as log:
            process = subprocess.Popen(command, cwd=root / "hot-control-src", env=environment, stdout=log, stderr=subprocess.STDOUT,
                                       start_new_session=True)
            receipt["leader_pid"] = process.pid
            while process.poll() is None:
                for rank, item in enumerate(state):
                    _sample_worker(output, process.pid, supervisor, rank, item)
                if time.monotonic() - clock >= timeout:
                    raise TimeoutError("native parity exceeded the fixed process timeout")
                time.sleep(.04)
        if process.returncode != 0:
            raise RuntimeError("stock native hot parity did not finish successfully")
    except BaseException as exc:
        failure = exc
    finally:
        try:
            if process is not None:
                cleanup, remains = supervisor._clean_group(process)
                receipt.update(process_group_cleanup_required=cleanup, process_group_remaining=remains, returncode=process.poll())
                if cleanup or remains:
                    failure = failure or RuntimeError("native runner left a process group requiring cleanup")
            receipt["gpu_after"] = supervisor.query(indices, fields)
            receipt["remaining_compute_pids"] = supervisor.query(indices, "pid", "compute-apps")
            if receipt["remaining_compute_pids"]:
                failure = failure or RuntimeError("selected GPU has a remaining compute process")
        except BaseException as exc:
            failure = failure or exc
        try:
            maps_valid = _finish_nccl(state, Path(environment["SGLANG_NCCL_SO_PATH"]), environment["TOPOMEM_EXPECTED_NCCL_SHA256"], version)
            if not maps_valid:
                failure = failure or RuntimeError("owned workers did not both show one exact NCCL2.32.3 mapping after real decode")
            result_path = output / "result.json"
            if result_path.is_file():
                result = json.loads(result_path.read_bytes())
                receipt["raw_result_sha256"] = hash_file(result_path)
                if result.get("status") != "completed" or result.get("arm") != "native" or result.get("phase") != "parity":
                    failure = failure or RuntimeError("native runner did not produce a completed parity receipt")
            else:
                failure = failure or RuntimeError("native runner produced no raw result")
        except BaseException as exc:
            failure = failure or exc
        receipt.update(status="completed" if failure is None else "failed", elapsed_seconds=time.monotonic() - clock,
                       utc_end=datetime.now(timezone.utc).isoformat())
        if failure is not None:
            receipt["failure"] = {"type": type(failure).__name__, "message": str(failure)}
        supervisor.atomic(runs / f"hot-{slots}.probe.json", receipt)
    if failure is not None:
        raise failure


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-manifest-sha256", required=True)
    parser.add_argument("--runs", type=Path)
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--process-timeout", type=int, default=900)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    manifest = verify_stage(root, args.expected_manifest_sha256)
    if args.verify_only:
        print(json.dumps({"status": "verified_transfer", "cases": manifest["case_manifest_sha256"]}, sort_keys=True))
        return
    if args.runs is None or not 650 <= args.process_timeout <= 3600 or sys.platform != "linux":
        parser.error("real probes require Linux, a new --runs directory, and a timeout covering both 300-second phases")
    runs = args.runs.resolve()
    if runs.is_relative_to(root):
        parser.error("run evidence must be outside the immutable transfer stage")
    sys.dont_write_bytecode = True
    tools = root / "profile-tools"
    launcher = load_module("probe_launcher", tools / "sglang_launch.py")
    supervisor = load_module("probe_supervisor", tools / "rsi_memory" / "execution_worker.py")
    launch_raw = (tools / "sglang_launch.json").read_bytes()
    launch = json.loads(launch_raw)
    wheel = json.loads((tools / "sglang_nccl_manifest.json").read_bytes())
    base_environment = {key: value for key, value in os.environ.items() if key in supervisor.INHERITED_ENVIRONMENT}
    base_environment.update(CUDA_VISIBLE_DEVICES=",".join(launch["gpu_uuids"]), PYTHONPATH=str(root / "hot-control-src"),
                            PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1")
    python, environment = launcher.prepare(launch_raw, ["-B", "-m", launcher.MODULE, "--input", "unused", "--output", "unused"],
                                           base_environment, wheel)
    environment["TOPOMEM_EXPECTED_NCCL_SHA256"] = launcher.NCCL_SHA256
    environment["CUBLAS_WORKSPACE_CONFIG"] = ":16:8"

    def stop(_signal, _frame):
        raise KeyboardInterrupt("hot probe stop requested")

    signal.signal(signal.SIGTERM, stop)
    with supervisor.gpu_leases(launch["gpu_uuids"]):
        indices = launch["gpu_indices"]
        if supervisor.query(indices, "uuid").splitlines() != launch["gpu_uuids"] or supervisor.query(indices, "pid", "compute-apps"):
            raise RuntimeError("selected GPU identity differs or selected GPUs already have a compute process")
        runs.mkdir(parents=True, exist_ok=False)
        version = _nccl_version(python, environment, Path(environment["SGLANG_NCCL_SO_PATH"]))
        supervisor.atomic(runs / "probe_contract.json", {"schema": 1, "transfer_manifest_sha256": args.expected_manifest_sha256,
                          "launch_sha256": sha256(launch_raw).hexdigest(), "capacities": list(CAPACITIES),
                          "numeric_environment": {"CUBLAS_WORKSPACE_CONFIG": ":16:8"},
                          "diagnostic_scope": "environment-only native A/A; unchanged attention, scheduler and byte gate",
                          "gpu_uuids": launch["gpu_uuids"], "nccl_sha256": launcher.NCCL_SHA256, "nccl_get_version": version,
                          "nccl_map_scope": "sampled owned scheduler workers during real decode; mapped device and inode checked"})
        for slots in CAPACITIES:
            _run_one(root, runs, slots, python, environment, launch, supervisor, args.process_timeout, version)
    profile = runs / "hot_metadata_profile.json"
    command = [python, "-B", "-m", "topomem_sglang_rsi.collect_hot_profile", "--base-case", str(root / "cases" / "4096"), "--output", str(profile)]
    for slots in CAPACITIES:
        command.extend(("--probe", str(slots), str(root / "cases" / str(slots)), str(runs / f"hot-{slots}" / "result.json")))
    collector_env = {**base_environment, "CUDA_VISIBLE_DEVICES": "", "PYTHONPATH": str(tools)}
    subprocess.run(command, cwd=tools, env=collector_env, check=True, timeout=60)
    print(json.dumps({"status": "profile_collected", "profile_sha256": hash_file(profile), "profile": str(profile)}, sort_keys=True))


if __name__ == "__main__":
    main()
