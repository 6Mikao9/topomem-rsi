"""Untimed CPU metadata diagnostic; leaves native admission and numeric modes alone."""
from functools import wraps
import os
from pathlib import Path


def install(directory, rank, expected_rids):
    from sglang.srt.managers.scheduler import Scheduler
    from sglang.srt.model_executor.forward_batch_info import ForwardBatch
    from .sglang_global_ticks import scheduler_tick, prepared_tick
    from .sglang_observe import save, append

    directory = Path(directory)
    expected, finished, rows = set(expected_rids), set(), []
    ticks_path = directory / f"global-ticks-rank-{rank}.jsonl"
    with ticks_path.open("x", encoding="utf-8"):
        pass
    state = {"pending": None, "prepared": False, "saved": False}
    original_init = Scheduler.__init__
    original_run = Scheduler.run_batch
    original_complete = Scheduler.process_batch_result
    original_prepare = ForwardBatch.prepare_mlp_sync_batch

    @wraps(original_init)
    def initialize(self, *args, **kwargs):
        result = original_init(self, *args, **kwargs)
        save(directory / f"numeric-env-rank-{rank}.json", {
            "rank": rank, "pid": os.getpid(),
            "CUBLAS_WORKSPACE_CONFIG": os.environ.get("CUBLAS_WORKSPACE_CONFIG"),
            "NCCL_ALGO": os.environ.get("NCCL_ALGO"),
            "NCCL_MIN_NCHANNELS": os.environ.get("NCCL_MIN_NCHANNELS"),
            "NCCL_MAX_NCHANNELS": os.environ.get("NCCL_MAX_NCHANNELS"),
        })
        return result

    @wraps(original_prepare)
    def prepare(self, *args, **kwargs):
        result = original_prepare(self, *args, **kwargs)
        if state["pending"] is not None:
            if state["prepared"]:
                raise RuntimeError("global trace saw duplicate model preparation")
            row = prepared_tick(state["pending"], self)
            rows.append(row)
            append(ticks_path, row)
            state["prepared"] = True
        return result

    @wraps(original_run)
    def run(self, batch, *args, **kwargs):
        if state["pending"] is not None:
            raise RuntimeError("global trace requires the frozen non-overlap execution")
        state["pending"] = scheduler_tick(rank, self.forward_ct + 1, batch)
        state["prepared"] = False
        try:
            result = original_run(self, batch, *args, **kwargs)
            if not state["prepared"]:
                raise RuntimeError("active DP forward did not prepare its model batch")
            return result
        finally:
            state["pending"] = None

    @wraps(original_complete)
    def complete(self, batch, *args, **kwargs):
        requests = tuple(batch.reqs)
        result = original_complete(self, batch, *args, **kwargs)
        if not state["saved"]:
            finished.update(req.rid for req in requests if req.finished())
            if expected <= finished:
                save(directory / f"global-local-completion-rank-{rank}.json", {
                    "schema": 1, "rank": rank, "pid": os.getpid(),
                    "scope": "native ungated global-forward CPU metadata diagnostic",
                    "finished": sorted(finished), "last_local_forward_iter": rows[-1]["forward_iter"],
                    "trace_path": ticks_path.name,
                })
                state["saved"] = True
        return result

    Scheduler.__init__ = initialize
    Scheduler.run_batch = run
    Scheduler.process_batch_result = complete
    ForwardBatch.prepare_mlp_sync_batch = prepare
