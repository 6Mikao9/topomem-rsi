# SGLang 双卡三容量到达组资格包

这是新绑定的固定外部到达实验。它使用同一个公开 archive 回放的 4096、6144 和 8192 热槽三档。每档原始 `fixture.json`、`target.json`、`topology.json` 和链路证据保持逐字节一致。用例脚本从两批已完成原生回放的六份真实结果读取四个分词承诺，逐一校验目标、原场景和调度摘要。六份结果的实际 token 长度及 token IDs 摘要一致。启动时本地 tokenizer 重新生成 IDs，确认与承诺一致后使用同一份 IDs 启动请求。

门禁将每阶段两份已分词请求保存在原生入队入口之前。两个 rank 以既有 Gloo 组在同一票次释放，同一原生空闲门槛用于进入下一组。第二组释放后停止额外投票。实测窗口从提交计时，包含该组门禁等待。SGLang 原生分块、staging、decode、attention 和 KV 管理按同一原生路径执行。

每个活动 forward 保留两 rank 的原生全局 token 向量、原生局部 mode、请求、序列形状和实际模型 padding。观察器只读 CPU 字段并在两 rank 都完成且全局无 forward 后一次落盘。单 rank 的 `IDLE` 保留。首次 prefill 同 tick 是额外门禁。packed KV 一致性仍由原有 656 B 逐选择读回裁判完成。后续性能调用须提供同臂、同源、同外部调度及同全局轨迹的 parity 回执，计时过程保留共同的 CPU shape 观察。

## 启动

解包至新的可信 Linux staging 目录。固定启动配置沿用已资格化的 GPU0/1 和隔离 NCCL 2.32.3。GPU 作业在同一租约内串行运行，并检查已拥有 worker 的库映射与进程退出。`--runs` 必须是 staging 目录外的新目录。

```text
python3 -B run_hot_native_parity.py --expected-manifest-sha256 <transfer-manifest-sha256> --verify-only
python3 -B run_hot_native_parity.py --expected-manifest-sha256 <transfer-manifest-sha256> --runs <new-outside-stage-directory> --repeat-count 2
```

默认执行两轮新进程，第一轮按 4096、6144、8192，第二轮按 8192、6144、4096。逐档 A/A 和跨档都要求完整全局轨迹、实际派发、输出、完整 packed KV 及运行环境摘要一致。通过后生成 `hot_metadata_profile.json`。单轮 `--repeat-count 1` 仅保存观察，不生成合格 profile。失败保留原始回执和拒绝原因，按相同计划重跑须另立结果目录并保留先前失败。

## 本地验证

从 stage 运行 `python -B -m unittest discover -s tests` 检查三档裁决。从 `hot-control-src` 运行相同命令检查绑定、原生入口、CPU 轨迹和性能 parity 规则。`rebind_ingress_cases` 可用原公开 probe transfer 和两批固定证据重新生成案例。

此包的 GPU A/A 需要新回执。结果范围为 tiny GLM 架构集成及固定公开回放，生成策略、生产负载和任务质量均须独立评估。
