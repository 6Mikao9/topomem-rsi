from hashlib import sha256
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from run_hot_native_parity import CAPACITIES, QUALIFICATION_FIELDS, _summarize


class ProbeTest(unittest.TestCase):
    def store(self, directory, repeat, slots, **updates):
        root = directory / f"round-{repeat:02d}"
        result = root / f"hot-{slots}" / "result.json"
        result.parent.mkdir(parents=True, exist_ok=True)
        evidence = {field: "same" for field in QUALIFICATION_FIELDS}
        evidence.update(status="completed", runtime={"torch": "mock"}, ingress={}, global_ticks={})
        evidence.update(updates)
        raw = json.dumps(evidence).encode()
        result.write_bytes(raw)
        (root / f"hot-{slots}.probe.json").write_text(json.dumps({"status": "completed", "raw_result_sha256": sha256(raw).hexdigest()}))

    def test_same_capacity_and_cross_capacity_gates_are_independent(self):
        with TemporaryDirectory() as tmp:
            directory = Path(tmp)
            for repeat in (1, 2):
                for slots in CAPACITIES:
                    self.store(directory, repeat, slots)
            self.assertFalse(_summarize(directory, 1, "mock")["qualification_passed"])
            self.assertTrue(_summarize(directory, 2, "mock")["qualification_passed"])
            self.store(directory, 2, 6144, global_ticks_sha256="different")
            result = _summarize(directory, 2, "mock")
            self.assertFalse(result["qualification_passed"])
            self.assertEqual(result["same_capacity_aa"]["6144"]["mismatches"], ["global_ticks_sha256"])
            self.assertFalse(result["cross_capacity_all_fields_equal"])
            self.store(directory, 1, 6144, global_ticks_sha256="different")
            result = _summarize(directory, 2, "mock")
            self.assertFalse(result["qualification_passed"])
            self.assertEqual(result["same_capacity_aa"]["6144"]["mismatches"], [])


if __name__ == "__main__":
    unittest.main()
