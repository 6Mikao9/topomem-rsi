"""Packaged HTML, CSS and JavaScript for the offline topology evidence report."""

PAGE = r'''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'">
<title>TopoMem RSI · 实验记录</title>
<style>
:root{--ink:#132227;--muted:#4c6065;--border:#ccd9d7;--bg:#edf3f1;--paper:#fff;--accent:#066354;--warn:#8b4f06;--fail:#943838;--mono:Consolas,"Courier New",monospace}
*{box-sizing:border-box}body{margin:0;color:var(--ink);background:var(--bg);font:15px/1.55 "Segoe UI","Microsoft YaHei",system-ui,sans-serif}main{width:min(1500px,100%);margin:auto;padding:34px 30px 65px}header{padding:22px 0 26px}h1{font-size:clamp(29px,4vw,52px);letter-spacing:-.06em;margin:4px 0 12px;line-height:1.1}h2{font-size:22px;letter-spacing:-.025em;margin:0 0 12px}h3{font-size:16px;margin:16px 0 8px}p{margin:6px 0 12px}.eyebrow{font:700 12px/1.3 var(--mono);letter-spacing:.12em;color:var(--accent)}.muted,small{color:var(--muted)}.brief{max-width:75ch}.panel{padding:22px;background:var(--paper);border:1px solid var(--border);border-radius:15px;min-width:0}.stack{display:grid;gap:16px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.wide{grid-column:1/-1}.toolbar{display:flex;gap:14px;flex-wrap:wrap;align-items:end;border-top:1px solid var(--border);padding-top:16px}.toolbar label{display:grid;gap:4px;color:var(--muted);font-size:13px}.toolbar select{min-width:140px}.pills{display:flex;gap:7px;flex-wrap:wrap;margin:7px 0 13px}.pill{border-radius:100px;background:#e5eeec;padding:4px 10px;font:650 12px/1.35 "Segoe UI",system-ui,sans-serif;overflow-wrap:anywhere}.pass{background:#d9f0e8;color:#075349}.fail{background:#fae3e1;color:var(--fail)}.warn{background:#fbefd8;color:var(--warn)}select,button{font:inherit;border:1px solid #9db4b0;border-radius:8px;color:var(--ink);background:white;padding:7px 10px;max-width:100%}select:disabled{opacity:.6}button{cursor:pointer}button:hover,button[aria-pressed=true]{background:#d9f0e8;border-color:var(--accent)}button:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid var(--accent);outline-offset:2px}.metrics{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:9px;margin:8px 0 12px}.metric{background:#f3f7f6;border-radius:8px;padding:10px;min-width:0}.metric strong{display:block;font-size:20px}.metric small{overflow-wrap:anywhere}.empty{padding:15px;border:1px dashed #aebfbc;border-radius:9px;background:#f7f9f8;color:var(--muted)}.clip{overflow:auto;max-height:380px;border:1px solid var(--border);border-radius:8px;margin:8px 0 13px}.tablewrap{overflow:auto;margin:5px 0 13px}table{width:100%;border-collapse:collapse;font-size:13px;text-align:left}th,td{padding:8px 10px;border-bottom:1px solid var(--border);vertical-align:top}th{background:#e9f1ef;font-weight:700;white-space:nowrap}td{overflow-wrap:anywhere}tbody tr:last-child td{border-bottom:0}code,pre,.mono{font-family:var(--mono);font-size:12px}pre{margin:0;padding:13px;white-space:pre-wrap;overflow-wrap:anywhere;background:#f4f8f6;color:#24383c}.diffline{display:block;white-space:pre-wrap}.add{background:#dbf1e5}.del{background:#fbe5e3}.hash{overflow-wrap:anywhere;word-break:break-word}details{border-top:1px solid var(--border);padding-top:8px;margin-top:8px}summary{cursor:pointer;color:var(--accent);font-weight:650}.timeline{display:flex;gap:8px;flex-wrap:wrap}.timeline button{font-size:13px}.scene-nav{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px}.scene-nav button{font-size:13px}.surface{background:#f0f7f4;border-radius:12px;margin:7px 0 13px;overflow:hidden}.surface svg{display:block;width:100%;max-height:295px}.section-kicker{color:var(--accent);font-size:13px;font-weight:750;margin-bottom:3px}.legend{font-size:13px;color:var(--muted)}footer{color:var(--muted);font-size:13px;margin-top:20px}.nowrap{white-space:nowrap}
@media(max-width:900px){main{padding:20px 16px 45px}.grid{grid-template-columns:1fr}.panel{padding:17px}.wide{grid-column:auto}}@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto}}
</style>
</head>
<body>
<main>
<header><div class="eyebrow">TOPOMEM RSI / OFFLINE EVIDENCE</div><h1>多 GPU 显存管理实验</h1>
<p class="brief muted">查看生成的显存程序、改写它的生成器，以及裁判记录的实际结果。比较按运行、后端和场景分别展示。</p>
<div class="toolbar"><label>运行<select id="run"></select></label><label>迭代<select id="iteration"></select></label><label>硬件拓扑<select id="topology"></select></label></div>
</header>
<noscript><p class="empty">此离线报告需要 JavaScript 来读取同一文件中的实验数据。</p></noscript>
<div class="stack">
<section class="panel" aria-labelledby="run-heading"><h2 id="run-heading">运行状态与预算</h2><div id="overview"></div></section>
<div class="grid">
<section class="panel" aria-labelledby="manager-heading"><div class="section-kicker">任务一</div><h2 id="manager-heading">生成显存管理程序</h2><div id="manager"></div></section>
<section class="panel" aria-labelledby="generator-heading"><div class="section-kicker">任务二</div><h2 id="generator-heading">改进生成器</h2><div id="generator"></div></section>
<section class="panel wide" aria-labelledby="paired-heading"><h2 id="paired-heading">配对验证与留出测试</h2><div id="paired"></div></section>
<section class="panel" aria-labelledby="topology-heading"><h2 id="topology-heading">实际拓扑与绑定</h2><div id="graph"></div></section>
<section class="panel" aria-labelledby="scene-heading"><h2 id="scene-heading">独立场景证据</h2><div id="scene"></div></section>
<section class="panel wide" aria-labelledby="ledger-heading"><h2 id="ledger-heading">调用与裁判台账</h2><div id="ledger"></div></section>
</div>
</div>
<footer>原始记录离线嵌入。输入、源码和结果摘要的匹配状态随各记录显示。完整物理运行和计时口径以对应的裁判回执为准。</footer>
</main>
<script type="application/json" id="data">/* EMBEDDED_RUN_DATA */</script>
<script>
'use strict';
const data = JSON.parse(document.getElementById('data').textContent);
const q = id => document.getElementById(id);
const state = {run: 0, round: 0, topology: 0, scene: Object.keys(data.scenario_labels)[0]};
const labels = {parent:'父代',child:'子代',fixed:'固定生成器',fixed_a:'固定 A',fixed_b:'固定 B',adaptive:'递归生成器',native:'原生对照',manual:'手写对照'};
const statuses = {admitted:'晋级',rejected:'拒绝',completed:'完成',pending:'待完成',interrupted_unknown:'中断，状态未知',failed:'失败',timed_out:'超时',environment_conflict:'环境冲突',feasible:'可行',infeasible:'不可行'};
const number = new Intl.NumberFormat('zh-CN',{maximumFractionDigits:6});
const receiptRequests = new Map();for(const receipt of data.receipts){if(!receiptRequests.has(receipt.job_id))receiptRequests.set(receipt.job_id,new Set());receiptRequests.get(receipt.job_id).add(receipt.request_sha256);}
function txt(value) { return value == null || value === '' ? '—' : typeof value === 'boolean' ? (value?'是':'否') : String(value); }
function num(value) { return typeof value === 'number' && Number.isFinite(value) ? number.format(value) : '—'; }
function seconds(value) { return typeof value === 'number' ? `${num(value)} s` : '—'; }
function ms(value) { return typeof value === 'number' ? `${num(value/1e6)} ms` : '—'; }
function mib(value) { return typeof value === 'number' ? `${num(value/1048576)} MiB` : '—'; }
function short(value) { return typeof value === 'string' && value.length > 14 ? value.slice(0,12)+'…' : txt(value); }
function el(tag, content, css) {const n=document.createElement(tag);if(content!=null)n.textContent=content;if(css)n.className=css;return n;}
function pill(value, css) {return el('span',statuses[value] || txt(value),`pill ${css||''}`);}
function empty(parent,value) {parent.append(el('p',value,'empty'));}
function scalar(parent,value) {const n=el('code',txt(value),'hash');parent.append(n);}
function table(headers,rows) {const wrap=el('div',null,'tablewrap'), t=el('table'), h=el('thead'), b=el('tbody'), header=el('tr');
  for(const name of headers){const n=el('th',name);n.scope='col';header.append(n);}h.append(header);
  for(const values of rows){const tr=el('tr');for(const item of values){const td=el('td');item instanceof Node ? td.append(item) : td.textContent=txt(item);tr.append(td);}b.append(tr);}
  t.append(h,b);wrap.append(t);return wrap;}
function block(value) {const wrap=el('div',null,'clip');wrap.append(el('pre',typeof value==='string'?value:JSON.stringify(value,null,2)));return wrap;}
function details(parent,title,value) {const d=el('details');d.append(el('summary',title),block(value));parent.append(d);}
function stat(parent,label,value) {const n=el('div',null,'metric');n.append(el('strong',value),el('small',label));parent.append(n);}
function configure(select,values,active,placeholder) {
  select.replaceChildren();
  if(!values.length){select.append(new Option(placeholder,''));select.disabled=true;return;}
  select.disabled=false;values.forEach(([value,label])=>select.append(new Option(label,value)));select.value=String(active);
}
function current(){return data.runs[state.run];}
function round(){return current()?.rounds[state.round];}
function statusClass(value){return ['admitted','completed','feasible'].includes(value)?'pass':value==='pending'?'warn':'fail';}
function trialOrigin(run,trial){if(!trial)return '—';
  for(const row of run.rounds){if(row.fixed.some(x=>x.id===trial.id))return '固定生成器';if(row.parent.some(x=>x.id===trial.id))return '该轮活动父代';
    if(row.child.some(x=>x.id===trial.id))return row.child_fallback_to_parent?'子代槽的父代回退':row.decision==='admitted'&&row.proposed_child_sha256===trial.harness_sha256?'该轮晋级子代':'未晋级的实验子代';}
  return '来源轮次未导入';
}
function receiptIDs(run){const ids=new Set();if(!run)return ids;
  const add=x=>{if(typeof x==='string')ids.add(x);};
  for(const e of run.evaluations){add(e.metrics?.receipt_id);for(const x of e.metrics?.receipts||[])add(x);}
  for(const p of run.pairs)for(const arm of Object.values(p.arms)){add(arm.metrics?.receipt_id);for(const x of arm.metrics?.receipts||[])add(x);for(const s of arm.samples)add(s.receipt_id);}
  return ids;
}
function usage(calls){const totals={calls:calls.length,known:0,reported:{},seconds:0,unknown:0};
  for(const c of calls){if(typeof c.seconds==='number')totals.seconds+=c.seconds;if(c.status==='interrupted_unknown'||c.status==='pending')totals.unknown++;
    if(Object.keys(c.usage).length)totals.known++;
    for(const [key,value] of Object.entries(c.usage)){
      if(typeof value==='number')totals.reported[key]=(totals.reported[key]||0)+value;
      else if(value&&typeof value==='object')for(const [sub,n] of Object.entries(value))if(typeof n==='number')totals.reported[`${key}.${sub}`]=(totals.reported[`${key}.${sub}`]||0)+n;
    }}return totals;}
function isFixed(call){return call.id.split('/')[2]?.startsWith('fixed');}
function showOverview(){const p=q('overview'),r=current();p.replaceChildren();
  if(!r){empty(p,'尚未导入拓扑 RSI 运行。此报告可以独立展示已导入的拓扑、场景和回执。');return;}
  const cfg=r.manifest.config, count=el('div',null,'metrics');
  stat(count,'已结算迭代 / 计划',`${r.rounds.length} / ${num(cfg.rounds)}`);stat(count,'生成器晋级',num(r.rounds.filter(x=>x.decision==='admitted').length));
  stat(count,'每臂每轮候选槽',num(r.manifest.candidate_slots_per_arm_per_round));stat(count,'每臂每轮 API 调用上限',num(r.manifest.provider_calls_per_arm_per_round_cap));p.append(count);
  p.append(el('p',`${r.origin} · ${r.recorded_status||'读取已落盘状态'} · ${cfg.model||'模型未记录'} · 每调用输出上限 ${num(cfg.max_output_tokens)} tokens · 发现阶段墙钟上限 ${seconds(cfg.wall_seconds)}`,'muted'));
  const arms=[['递归生成器',r.calls.filter(c=>!isFixed(c))],['固定生成器',r.calls.filter(isFixed)]];
  p.append(table(['生成器','实际调用','含用量','未知/待完成','输入 tokens','输出 tokens','总 tokens','推理 tokens','记录耗时合计'],arms.map(([label,items])=>{const u=usage(items), t=u.reported;return [label,u.calls,u.known,u.unknown,num(t.prompt_tokens??t.input_tokens),num(t.completion_tokens??t.output_tokens),num(t.total_tokens),num(t['completion_tokens_details.reasoning_tokens']),u.calls?seconds(u.seconds):'—'];})));
  const pending=r.calls.filter(c=>['pending','interrupted_unknown'].includes(c.status)).length;
  if(pending)p.append(pill(`${pending} 个未知或待完成调用`,'warn'));
  if(r.frozen)p.append(pill(r.frozen.hashes_match?'已封存，摘要匹配':'封存摘要不匹配',r.frozen.hashes_match?'pass':'fail'));
  const timeline=el('div',null,'timeline');
  for(const [index,row] of r.rounds.entries()) {const b=el('button',`R${row.round} · ${statuses[row.decision]||txt(row.decision)}`);b.type='button';b.title=txt(row.reason);b.setAttribute('aria-pressed',String(index===state.round));b.onclick=()=>{state.round=index;q('iteration').value=String(index);showRun();};timeline.append(b);}
  if(r.rounds.length)p.append(el('h3','所有已结算迭代'),timeline);
  else empty(p,'暂无已结算迭代。已有调用或裁判记录会出现在台账中。');
}
function showManager(){const p=q('manager'),r=round();p.replaceChildren();if(!r){empty(p,'暂无本轮候选程序。');return;}
  const candidates=['parent','child','fixed'].flatMap(arm=>r[arm].map(x=>[arm,x]));
  if(!candidates.length){empty(p,'本轮未记录候选槽。');return;}
  p.append(table(['候选','生成臂','操作','训练分值','状态'],candidates.map(([arm,x])=>[el('code',x.id),labels[arm],x.decision?.operator,num(x.score),pill(x.status,statusClass(x.status))])));
  const selector=el('select');selector.setAttribute('aria-label','候选程序');
  const initial=Math.max(0,candidates.findIndex(([arm,x])=>arm==='child'&&x.program));
  configure(selector,candidates.map(([arm,x],i)=>[i,`${labels[arm]} · ${x.id}`]),initial,'无候选');
  const body=el('div');p.append(selector,body);
  const render=()=>{const [arm,x]=candidates[Number(selector.value)];body.replaceChildren();
    body.append(el('h3','程序与生成来源'));if(!x.program){empty(body,`本槽未产出可读取的程序。${x.failure||statuses[x.status]||x.status||''}`);return;}
    body.append(pill(x.program_hash_matches?'程序摘要匹配':'程序摘要不匹配',x.program_hash_matches?'pass':'fail'),pill(trialOrigin(current(),x)));
    body.append(table(['生成器 SHA-256','程序 SHA-256'],[[el('code',txt(x.harness_sha256),'hash'),el('code',txt(x.program_sha256),'hash')]]));
    const rules=x.program.rules||[];body.append(table(['规则','触发事件','动作'],rules.map((rule,i)=>[i,rule.event,rule.action])));
    details(body,'完整生成程序',x.program);if(x.decision)details(body,'父代、证据与规则编号',x.decision);
    const matches=data.receipts.flatMap(rec=>(rec.result?.cases||[]).filter(c=>c.diagnostic.program_sha256===x.program_sha256).map(c=>[rec,c]));
    if(matches.length){body.append(el('p',`有 ${matches.length} 条同程序摘要的已导入场景观测。`,'muted'),table(['回执','场景','观测动作数','计时中位数'],matches.map(([rec,c])=>[rec.job_id,c.name,c.diagnostic.action_count,ms(c.median_elapsed_ns)])));
      for(const [rec,c] of matches){const d=c.diagnostic;details(body,`${rec.job_id} · ${c.name} · 实际动作 ${d.actions.length}/${d.action_count}`,{scope:d.scope||rec.result.scope,topology_sha256:d.topology_sha256,counts:d.action_types,actions:d.actions});}}
    else body.append(el('p','未导入与此程序摘要匹配的运行时动作回执。','muted'));
  };selector.onchange=render;render();
}
function planDetails(parent,plan,caption){if(!plan)return;const d=el('details');d.open=true;
  d.append(el('summary',caption),table(['计划项','提出内容'],[['观察到的问题',plan.observed_problem],['机制变化',plan.mechanism_change],['预期效果（假设）',plan.expected_effect],['证伪条件',plan.falsification],['选择的训练证据 ID',plan.training_evidence_ids?.join(' · ')]]));parent.append(d);}
function showGenerator(){const p=q('generator'),run=current(),r=round();p.replaceChildren();if(!r){
  if(run?.meta_plans.length){for(const entry of run.meta_plans){p.append(el('h3',entry.id));planDetails(p,entry.plan,'已落盘的评估前方案');if(entry.failure)p.append(el('p',entry.failure,'muted'));}empty(p,'暂无已结算的机制比较。');}
  else empty(p,'暂无生成器版本改写。');return;}
  planDetails(p,r.adaptive_meta_plan,'评估前方案 · 递归臂');
  planDetails(p,r.fixed_meta_plan,'评估前方案 · 固定臂元产物弃用');
  p.append(el('h3','实测裁决与版本变化'));
  p.append(pill(r.decision,statusClass(r.decision)),el('p',txt(r.reason),'mono'));
  if(r.parent_validation?.score!=null||r.child_validation?.score!=null)
    p.append(table(['父代验证分值','子代槽验证分值','子代槽是否回退'],[[num(r.parent_validation?.score),num(r.child_validation?.score),txt(r.child_fallback_to_parent)]]));
  p.append(table(['来源','版本 SHA-256'],[['轮前活动版本',el('code',txt(r.active_before),'hash')],['提议子代',el('code',txt(r.proposed_child_sha256),'hash')],['轮后活动版本',el('code',txt(r.active_after),'hash')]]));
  if(r.child_fallback_to_parent)p.append(el('p','子代槽使用父代回退。本轮子代槽的分数应按回退证据读取。','muted'));
  const next=run.rounds.find(x=>x.round===r.round+1), incoming=r.previous_admission_reuse, outgoing=next?.previous_admission_reuse;
  const reuse=x=>`任务调用 ${num(x.task_api_completed)} 次完成 · 程序 ${num(x.task_program_trial_ids?.length)} 个 · 自修订调用${x.meta_api_completed?'完成':'未完成'}`;
  if(incoming){p.append(el('p',`本轮复用上一轮晋级版本 · ${reuse(incoming)}`));details(p,'复用的真实调用与程序 ID',incoming);}
  if(r.decision==='admitted')p.append(el('p',outgoing?.source_sha256===r.active_after?`本轮晋级版本在下一轮 · ${reuse(outgoing)}`:'尚无下一轮已结算的复用记录。','muted'));
  if(r.adaptive_meta_decision)details(p,'实际元修订模式与所选训练证据',r.adaptive_meta_decision);
  if(r.fixed_meta_decision||r.fixed_meta_failure)details(p,'固定对照的元调用槽', {decision:r.fixed_meta_decision,failure:r.fixed_meta_failure,discarded_source_sha256:r.fixed_meta_discarded_sha256});
  if(Object.keys(r.controlled_behavior).length)details(p,'同起点行为对比',r.controlled_behavior);
  const source=el('select');source.setAttribute('aria-label','生成器源码视图');configure(source,[['diff','源码差异'],['before','轮前源码'],['child','提议子代源码'],['after','轮后活动源码']],'diff','');
  const box=el('div');p.append(el('h3','版本代码'),source,box);
  const render=()=>{box.replaceChildren();if(source.value==='diff'){
    if(!r.source_diff?.length){empty(box,'本轮无已保存的源码差异。');return;}
    const content=el('pre'),wrap=el('div',null,'clip');for(const line of r.source_diff)content.append(el('span',line||' ','diffline '+(line.startsWith('+')?'add':line.startsWith('-')?'del':'')));wrap.append(content);box.append(wrap);
  }else{const id={before:r.active_before,child:r.proposed_child_sha256,after:r.active_after}[source.value], record=run.sources[id];
    if(record?.status==='verified'){box.append(block(record.source));return;}empty(box,record?.status==='hash_mismatch'?'归档源码与摘要不匹配。':'没有导入此版本的归档源码。');}};
  source.onchange=render;render();
}
function comparison(parent,values){if(!values||!Object.keys(values).length)return;
  parent.append(table(['比较','裁决','配对差中位数','原因'],Object.entries(values).map(([key,v])=>[key,pill(v.passed?'通过':'未通过',v.passed?'pass':'fail'),num(v.median_improvement),v.reason])));
  const rows=Object.entries(values).flatMap(([name,v])=>(v.deltas||[]).map(d=>[name,d.block_id,num(d.reference_minus_candidate)]));
  if(rows.length)details(parent,'逐区块差值 · 对照减候选',rows);
}
function pairedRecord(parent,record){if(!record){empty(parent,'未记录配对区块。');return;}
  parent.append(pill(record.status,statusClass(record.status)));
  if(record.failure)parent.append(el('p',record.failure,'muted'));
  const entries=Object.entries(record.arms), units=[...new Set(entries.map(([,a])=>a.metrics.score_unit).filter(Boolean))];
  parent.append(el('p',`裁判原始分值，越低越好${units.length?' · '+units.join(' / '):''} · ${seconds(record.seconds)}`,'muted'));
  if(!entries.length)return;
  const order=entries.find(([,a])=>a.metrics.execution_order?.length)?.[1].metrics.execution_order;
  parent.append(table(['区块',...entries.map(([label])=>labels[label]||label)],
    [['裁判可行',...entries.map(([,arm])=>txt(arm.feasible))],['中位数',...entries.map(([,arm])=>num(arm.score))],...(record.block_ids||[]).map(blockId=>[blockId,...entries.map(([,arm])=>num(arm.samples.find(s=>s.block_id===blockId)?.score))])]));
  if(order)parent.append(table(['区块','记录的执行顺序'],order.map(row=>[row.block_id,row.order.map(label=>labels[label]||label).join(' → ')])));
  const refs=entries.flatMap(([label,arm])=>arm.samples.filter(s=>s.receipt_id).map(s=>[labels[label]||label,s.block_id,s.receipt_id]));
  if(refs.length)parent.append(table(['生成臂','区块','关联回执 ID'],refs));
}
function showPaired(){const p=q('paired'),run=current(),r=round();p.replaceChildren();if(!run){empty(p,'暂无验证或留出测试记录。');return;}
  p.append(el('p',txt(run.manifest.paired_gate),'muted'),el('h3','本轮验证'));
  if(r?.paired_validation){const v=r.paired_validation;pairedRecord(p,run.pairs.find(x=>x.id===`pair/${v.effect_id}`));comparison(p,v.comparisons);}
  else if(r){const values=[r.parent_validation,r.child_validation,...r.fixed_validation];p.append(table(['生成臂','入围候选','验证分值','状态'],['父代','子代','固定 A','固定 B'].map((label,i)=>[label,values[i]?.trial?.id,num(values[i]?.score),values[i]?.status])));}
  else empty(p,'暂无本轮验证记录。');
  p.append(el('h3','封存后的留出测试'));
  if(!run.frozen){empty(p,'未发现封存记录。');return;}
  const f=run.frozen;p.append(pill(f.hashes_match?'封存摘要匹配':'封存摘要不匹配',f.hashes_match?'pass':'fail'));
  if(f.partial)p.append(pill('部分轮次封存','warn'));
  if(f.admitted_harness_sha256s)details(p,'主结果的准入谱系与实际复用版本',{admitted_harness_sha256s:f.admitted_harness_sha256s,reused_harness_sha256s:f.reused_harness_sha256s});
  p.append(table(['封存臂','验证候选','验证分值','生成来源','生成器摘要','程序摘要'],['adaptive','fixed'].map(arm=>[labels[arm],f[arm]?.trial?.id,num(f[arm]?.score),trialOrigin(run,f[arm]?.trial),el('code',txt(f[arm]?.trial?.harness_sha256),'hash'),el('code',txt(f[arm]?.trial?.program_sha256),'hash')])));
  if(f.adaptive_archive_best){const best=f.adaptive_archive_best;
    p.append(el('h3','实验档案最佳 · 验证分值'),table(['候选','验证分值','生成来源','程序摘要'],[[best.trial?.id,num(best.score),trialOrigin(run,best.trial),el('code',txt(best.trial?.program_sha256),'hash')]]));}
  const test=run.pairs.find(x=>x.id==='pair/frozen/test');
  if(test){pairedRecord(p,test);comparison(p,run.test_comparisons);}
  else{const rows=run.evaluations.filter(e=>e.split==='test');if(rows.length)p.append(table(['评估 ID','分值','状态'],rows.map(e=>[e.id,num(e.score),e.status])));else empty(p,'暂无封存后测试记录。');}
}
function svgEl(tag,attributes,text){const n=document.createElementNS('http://www.w3.org/2000/svg',tag);for(const [k,v] of Object.entries(attributes))n.setAttribute(k,v);if(text)n.textContent=text;return n;}
function showTopology(){const p=q('graph'),g=data.topologies[state.topology],r=current();p.replaceChildren();
  const contract=r?.contract||{};if(Object.keys(contract).length)details(p,'运行固定契约中的已投影字段',contract);
  if(!g){empty(p,'未导入拓扑图。场景回执仍可查看各自记录的拓扑摘要。');return;}
  scalar(p,g.sha256);const known=[contract.topology_sha256,...data.receipts.flatMap(rec=>(rec.result?.cases||[]).map(x=>x.diagnostic.topology_sha256))].filter(Boolean);
  p.append(el('p',known.includes(g.sha256)?'与至少一条已导入记录的拓扑摘要匹配。':'已导入拓扑文件。当前数据未提供匹配摘要。','muted'));
  if(g.nodes.length<=20&&g.nodes.length){const svg=svgEl('svg',{viewBox:'0 0 580 300',role:'img','aria-label':'已导入的有向硬件拓扑'});
    const defs=svgEl('defs',{}),arrow=svgEl('marker',{id:'arrow',viewBox:'0 0 10 10',refX:9,refY:5,markerWidth:6,markerHeight:6,orient:'auto-start-reverse'});arrow.append(svgEl('path',{d:'M 0 0 L 10 5 L 0 10 z',fill:'#558278'}));defs.append(arrow);svg.append(defs);
    const pos=new Map();g.nodes.forEach((node,i)=>{const angle=2*Math.PI*i/g.nodes.length-Math.PI/2;pos.set(node.id,[290+190*Math.cos(angle),150+95*Math.sin(angle)]);});
    for(const link of g.links){const a=pos.get(link.src),b=pos.get(link.dst);if(!a||!b)continue;const length=Math.hypot(a[0]-b[0],a[1]-b[1]);if(!length)continue;
      const dx=(b[0]-a[0])/length,dy=(b[1]-a[1])/length;svg.append(svgEl('line',{x1:a[0]+dx*24+dy*4,y1:a[1]+dy*24-dx*4,x2:b[0]-dx*28+dy*4,y2:b[1]-dy*28-dx*4,stroke:'#558278','stroke-width':2,'marker-end':'url(#arrow)'}));}
    for(const node of g.nodes){const [x,y]=pos.get(node.id);svg.append(svgEl('circle',{cx:x,cy:y,r:22,fill:node.kind==='gpu'?'#0a6656':'#49676a'}),svgEl('text',{x,y:y+4,'text-anchor':'middle',fill:'white','font-size':11},node.kind),svgEl('text',{x,y:y+38,'text-anchor':'middle',fill:'#203537','font-size':13},node.id));}
    const surface=el('div',null,'surface');surface.append(svg);p.append(surface);
  }
  p.append(table(['节点','类型','KV 容量','物理容量'],g.nodes.map(n=>[n.id,n.kind,mib(n.capacity_bytes),mib(n.physical_bytes)])));
  p.append(table(['有向连接','传输','GB/s','延迟 ns'],g.links.map(l=>[`${l.src} → ${l.dst}`,l.transport,num(l.bandwidth_bytes_per_s/1e9),num(l.latency_ns)])));
}
function showScene(){const p=q('scene'),nav=el('div',null,'scene-nav');p.replaceChildren();
  for(const [kind,name] of Object.entries(data.scenario_labels)){const b=el('button',name);b.type='button';b.setAttribute('aria-pressed',String(kind===state.scene));b.onclick=()=>{state.scene=kind;showScene();};nav.append(b);}p.append(nav);
  const inputs=data.scenarios.filter(x=>x.kind===state.scene),fixtures=inputs.filter(x=>!x.binding),matches=data.receipts.flatMap(rec=>(rec.result?.cases||[]).filter(c=>c.diagnostic.fixture_kind===state.scene).map(c=>[rec,c]));
  if(fixtures.length)p.append(el('h3','已导入输入'),table(['场景文件','内容段','外部事件'],fixtures.map(f=>[f.name||f.file,f.segments,JSON.stringify(f.events)])));
  for(const item of inputs.filter(x=>x.binding))details(p,`${item.file} · ${matches.some(([,c])=>c.diagnostic.scenario_sha256===item.binding_sha256)?'绑定摘要匹配回执':'已导入绑定'}`,{scenario_sha256:item.binding_sha256,...item.binding});
  if(!matches.length){empty(p,'此场景没有可显示的已导入 GPU 观测。');return;}
  const ids=receiptIDs(current()), select=el('select'), content=el('div');select.setAttribute('aria-label','场景 GPU 回执');
  configure(select,matches.map(([rec,c],i)=>[i,`${rec.job_id} · ${c.name} · ${c.diagnostic.arm||'臂未记录'}`]),0,'无回执');p.append(el('h3','实际后端观测'),select,content);
  const render=()=>{content.replaceChildren();const [rec,c]=matches[Number(select.value)],d=c.diagnostic,scope=d.scope||rec.result.scope;
    content.append(pill(rec.status,statusClass(rec.status)),el('p',`${txt(scope)} · ${txt(d.schedule_execution)}`,'mono'));
    if(typeof rec.result.feasible==='boolean')content.append(pill(rec.result.feasible?'裁判可行':'裁判拒绝',rec.result.feasible?'pass':'fail'));
    if(scope==='cuda_text_derived_fixed_block_sparse')content.append(el('p','文本派生的 CUDA 分块稀疏注意力测量。时间是该执行器的测量值。','muted'));
    content.append(el('p',receiptRequests.get(rec.job_id).size>1?'多个输入回执使用相同作业 ID 且请求摘要不同，无法按 ID 唯一归属。':ids.has(rec.job_id)?'当前运行台账通过回执 ID 引用此观测。':'此回执未由当前运行台账的回执 ID 引用。','muted'));
    content.append(table(['运行臂','场景中位数','动作总数','fetch misses','退出时引用'],[[d.arm,ms(c.median_elapsed_ns),d.action_count,num(d.total_fetch_misses),num(d.live_references_at_end)]]));
    const keys=[...new Set([...Object.keys(d.managed_peak_bytes_by_node||{}),...Object.keys(d.cuda_peak_allocated_bytes_delta_by_node||{})])];
    if(keys.length)content.append(table(['节点','管理 KV 峰值','CUDA 分配峰值增量'],keys.map(k=>[k,mib(d.managed_peak_bytes_by_node?.[k]),mib(d.cuda_peak_allocated_bytes_delta_by_node?.[k])])));
    details(content,'观测绑定与时间样本',{request_sha256:rec.request_sha256,source_manifest_sha256:rec.source_manifest_sha256,case_sha256:c.case_sha256,workload_sha256:d.workload_sha256,schedule_sha256:d.schedule_sha256,scenario_sha256:d.scenario_sha256,topology_sha256:d.topology_sha256,program_sha256:d.program_sha256,selected_and_output_sha256:d.selected_and_output_sha256,timings_elapsed_ns:c.timings_elapsed_ns,link_bytes:d.link_bytes,shared_bottleneck_bytes:d.shared_bottleneck_bytes});
    if(d.action_count)details(content,`实际动作 ${d.actions.length} / ${d.action_count} 条`,{counts:d.action_types,events:d.actions});
    if(d.semantics?.length)details(content,'场景语义事件',d.semantics);
  };select.onchange=render;render();
}
function showLedger(){const p=q('ledger'),r=current();p.replaceChildren();
  if(!r?.calls.length)empty(p,'没有导入 API 调用记录。');
  else{p.append(el('h3','API 调用 · 含失败与待完成'),table(['调用','状态','完成原因','来源 SHA','用量合计','耗时'],r.calls.map(c=>[el('code',c.id),pill(c.status,statusClass(c.status)),c.finish_reason||c.failure,short(c.harness_sha256),num(c.usage.total_tokens),seconds(c.seconds)])));}
  if(r&&(r.evaluations.length||r.pairs.length))p.append(el('h3','训练、验证与测试裁判'),table(['评估','拆分','状态','裁判可行','分值','耗时'],[...r.evaluations,...r.pairs].map(e=>[el('code',e.id),e.split,pill(e.status,statusClass(e.status)),txt(e.feasible),num(e.score),seconds(e.seconds)])));
  if(r?.meta_plans.length)p.append(el('h3','评估前方案台账'),table(['记录 ID','状态','前代','提议子代'],r.meta_plans.map(entry=>[el('code',entry.id),entry.status,short(entry.parent_sha256),short(entry.proposed_child_sha256)])));
  if(!data.receipts.length){p.append(el('p','未导入独立 GPU 回执文件。','muted'));return;}
  p.append(el('h3','独立 GPU 回执 · 按文件来源'),table(['作业','进程状态','裁判可行','后端范围','结果摘要','GPU UUID','运行耗时'],data.receipts.map(x=>[x.job_id,pill(x.status,statusClass(x.status)),txt(x.result?.feasible),x.result?.scope,x.canonical_result_matches==null?'无结果':x.canonical_result_matches?'匹配':'不匹配',x.gpu_uuids?.join(', '),seconds(x.elapsed_seconds)])));
}
function showRun(){showOverview();showManager();showGenerator();showPaired();showTopology();showScene();showLedger();}
function configureRound(){configure(q('iteration'),(current()?.rounds||[]).map((row,index)=>[index,`R${row.round} · ${statuses[row.decision]||txt(row.decision)}`]),state.round,'暂无迭代');}
configure(q('run'),data.runs.map((r,i)=>[i,r.label]),state.run,'暂无运行');configureRound();
configure(q('topology'),data.topologies.map((g,i)=>[i,g.name]),state.topology,'暂无拓扑');
q('run').onchange=()=>{state.run=Number(q('run').value);state.round=0;configureRound();showRun();};
q('iteration').onchange=()=>{state.round=Number(q('iteration').value);showRun();};
q('topology').onchange=()=>{state.topology=Number(q('topology').value);showTopology();};
showRun();
</script>
</body>
</html>
'''
