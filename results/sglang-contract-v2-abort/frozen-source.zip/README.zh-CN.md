# TopoMem RSI 中文说明

[English](README.md) · [显存程序契约](docs/MEMORY_PROGRAM_CONTRACT_ZH.md) · [研究框架复核](docs/RSI_FRAMEWORK_REEVALUATION_20261110_ZH.md)

## 两项任务

1. **生成显存管理程序。** 给定稀疏注意力、实际 GPU 拓扑和固定场景，模型生成 `MemoryProgram`。规则可选择 KV 放置、副本、迁移、压力降级、预取、驱逐和回收。受信执行器校验事件、动作、特征、路线、容量和引用，再在原生、手写和生成臂上测量。
2. **改进程序生成器。** 生成器有 `build_prompt` 和 `build_meta_prompt` 两个入口。前者选择构造、变异或交叉，并指定父代、证据及规则。后者选择下一次修订策略。改写前先登记观察、机制、预期和证伪条件。控制器用同起点候选与配对验证决定晋级，记录源码差异和后续实际任务及元调用。

目标合同固定注意力实现和选集、物理 GPU 与有向连接、计算 rank、显存容量、请求生命周期、外部调度、批次和安全点。模型只接触训练范围的目标描述、候选档案和反馈。裁判保管验证及留出信息，决定可行性和分值。主结果从种子和晋级生成器的产出中选，实验档案的验证最佳另列。

## 当前证据

| 实验 | 已观察到的状态 |
| --- | --- |
| CUDA v6 Agent | 结算 R0 后停止。子代两个 AST 均变化，同起点算子、父代、证据和元模式相同，未晋级。验证 12 个区块中子代均慢于项目的直写/LRU 参考。区块分值中位数为子代 146.529 ms、参考臂 120.898 ms。五个实测臂的第二张 GPU 管理 KV 峰值均为 0 B。审计复核了 66 份回执，保留 R1 部分调用和未知状态。 |
| CUDA v7 Agent | 六轮 DeepSeek 生成和 12 个留出区块均已结算。唯一晋级的是 R2 生成器源码，其内存程序恢复已观察到的历史最佳行为，相对当轮父代 12/12 胜、配对中位改善 +126.658 ms，相对项目直写/LRU 参考 0/12 胜。R3–R5 的九次实际任务与元调用复用了晋级源码。封存的递归臂内存程序来自 R0 初始生成器，留出对直写/LRU 参考 0/12 胜、配对中位改善 −29.172 ms，对固定生成器 6/12 胜、配对中位改善 −0.142 ms。 |
| SGLang 集成 | 实现了 HiSparse 热容量和冷 KV 层放置。正式递归搜索与训练选优手写对照仍待通过资格门槛。方案预登记两轮、6 个验证区块和 12 个留出区块。服务使用随机初始化后经玩具文本微调的架构测试 checkpoint，实测输出为 EOS。资格检查覆盖各 rank 的真实 packed KV 行、输出 IDs 和实际派发。任务质量和已训练模型的 KV 局部性超出这组回放范围。 |
| Stock SGLang 独立探针 | TP2 主干的 attention DP2 验证了各 attention rank 的真实派发，每 rank 八个本地 query heads。独立 UnifiedRadixCache 探针验证两分支共享 1,536 个物理前缀行，并各保留 128 个互不重叠的后缀行。该 radix fixture 的缓存与隔离推理输出 IDs 均为 EOS。 |

生成器源码的晋级和后续复用属于源码任务。封存程序的留出结果属于显存管理任务。[v6 首轮审计](results/cuda-rsi-v6/agent_tools/AUDIT_R0_ZH.md) · [v7 六轮与留出审计](results/cuda-rsi-v7/agent_tools/AUDIT_PROGRESS_ZH.md) · [SGLang 资格流程](integrations/topology_memory/SGLANG.md) · [SGLang 探针证据](results/sglang-qualification/evidence_manifest.json) · [SGLang 手写对照与预算](docs/SG_HAND_SWEEP.md)

## 准备本地配置

Python 3.10 或更新版本可运行控制器和离线报告。CUDA 裁判主机使用支持目标设备的 PyTorch。SGLang 版本和依赖以独立集成文档为准。

```powershell
python -m pip install -e .
python -B -m unittest discover -s tests
```

构建可重复的 CUDA 部署源码包。

```powershell
python -B -m rsi_memory.source_bundle --output deploy/cuda-source.zip
```

1. 在裁判主机运行 `python -B -m integrations.topology_memory.torch_profile --output link-profile.json`，保留两张实际 GPU 各自的 pinned host H2D、D2H 原始测量、UUID 和容量。测量文件用于构建真实有向拓扑。副本容量和路线在实验开始前固定。
2. 将部署包解压到裁判工作目录下的新源码目录。`SOURCE_MANIFEST.json` 的 `files` 字段将相对文件路径映射到字节 SHA-256，覆盖裁判及其全部可导入文件。把打包命令返回的 `source_manifest_sha256` 固定在实验输入中。执行器通过现有 OpenSSH 配置连接，并在运行前检查源文件、设备身份及 GPU 占用。
3. 准备本地 `private-build-inputs.json`，按下表提供构建器输入。目标配置、主机地址、设备标识和凭据保存在自己的实验目录。控制器可从本机 `OPENCODE_GO_API_KEY` 或通过 `--key-file` 读取模型凭据。

| 输入字段 | 内容 |
| --- | --- |
| `experiment_id`、`output_root` | 独立实验名和本地结果根目录。下面的命令使用 `runs`。 |
| `profiles` | 四种场景分别提供 `topology`、`target`、`compute_node`、`device_map`、`compile`。`compile` 固定页大小、维度、层数、top-k 和文字到行的转换参数。 |
| `executor` | `host`、`worker`、`root`、`python`、`source`、`gpu_indices`、`gpu_uuids`。可选 `environment` 仅接受执行器声明的配置项。 |
| `calibration`、`source_manifest_sha256` | 指向有向链路测量文件并提供固定源码清单的 SHA-256。 |
| `initial_program`、`manual_program` | 两个完整 `MemoryProgram` 对象。可读入仓库中的原生 LRU 等价策略和手写策略作为起点与对照。 |
| `workload_directory` | 四个主 fixture 与 `variants/` 的目录。示例为 `examples/workloads`。 |
| `paired_blocks`、`warmup`、`samples`、`timeout` | 分别固定每个验证和留出集的区块数、每臂预热和计时样本数、工作进程超时。 |

构建器校验 GPU 容量、固定计算节点和每条 pinned host 连接是否匹配实际 profile。它为每个场景分别写训练、验证和留出配置。训练可用同一自编内容的两个不同固定种子，验证和测试使用不同内容的变体。[构建器](rsi_memory/experiment_cases.py) · [手写与 LRU 对照](examples/policies/README.md)

```powershell
python -B -m rsi_memory.experiment_cases `
  --inputs private-build-inputs.json --output sealed-configs
```

## 运行与留出

选择一份封存场景配置和新的控制器目录。两臂从同一个种子开始。递归臂每轮给活动父代和子代同量候选槽。固定臂保留原生成器，获得同样的候选和调用预算，其元调用产物弃用。台账分开记录预算上限、已知实际用量和未知状态。

```powershell
$RunArgs = @(
  '--output', 'runs/agent_tools/controller',
  '--adapter', 'rsi_memory.cuda_domain:factory',
  '--adapter-config', 'sealed-configs/agent_tools.json',
  '--model', 'deepseek-v4.1-flash', '--rounds', '6', '--slots', '2',
  '--max-output-tokens', '65536', '--min-paired-blocks', '12',
  '--min-improvement', '0.5', '--wall-seconds', '43200'
)
python -B -m rsi_memory.topology_rsi run @RunArgs
```

发现阶段结算后检查失败、待完成和晋级记录。恢复使用相同源码、模型和实验合同，未知调用原样留档。确认发现阶段结束，再用同一组参数封存并打开独立留出评估。

```powershell
python -B -m rsi_memory.topology_rsi freeze @RunArgs
python -B -m rsi_memory.topology_rsi test @RunArgs
```

`journal.sqlite` 记录预登记方案、调用、训练裁判、配对区块和版本决定。`frozen.json` 绑定主策略和固定对照。留出结论读取 `pair/frozen/test`、对照差值和实际回执。晋级需要两入口在当轮同起点作出结构变化，且父子配对每区块方向一致，改善中位数超过预设门槛。下一轮复用需要实际任务和元请求都绑定晋级源码。运行时可行性、生成器晋级和相对原生的性能收益是独立证据。

## 离线报告

```powershell
python -B -m rsi_memory.topology_report `
  --run 'Agent=runs/agent_tools/controller' --receipts runs/agent_tools/receipts `
  --scenario examples/workloads/agent-water-inspection.json `
  --scenario examples/workloads/long-document-estuary-qa.json `
  --scenario examples/workloads/chatbot-trip-planning.json `
  --scenario examples/workloads/rollout-bridge-options.json `
  --output agent-evidence.html
```

打开 HTML，可切换运行、迭代和场景，查看候选程序、规则执行、评估前方案、源码差异和失败记录。需要显示拓扑时传 `--topology`。可用 `--scenario 类型=场景绑定.json` 按摘要核对实际 `MemoryScenario`。`--transfer` 可读取独立迁移研究目录，`--engineering` 可读取工程审计 JSON。无回执的场景显示输入状态。报告生成过程只读取已有台账和回执。[查看示例](examples/topology-report/README.md)

## 场景与集成范围

| 固定场景 | CUDA 裁判读取的机制证据 |
| --- | --- |
| Agent | 固定工具调用与返回事件、会话前缀和选中 KV。 |
| LongBench 风格长文问答 | 自编长文和问题、文本派生 KV、长上下文选集与输出核验。 |
| Chatbot | 多轮前缀保留与逐轮追加。 |
| Rollout | 分支共享页、物理写时复制、分支后缀及退出后的引用释放。 |

CUDA 裁判按固定外部逻辑时钟执行真实 KV 和稀疏注意力张量运算。`native_lru` 是本项目的直写/LRU 参考。decode 追加会物化不可变 KV 块版本，相应整块操作成本进入该执行器的计时。v7 分值是各场景耗时中位数之和，单位 ms，计入强制回收。预分配及编译在计时外。管理 KV 峰值按节点统计，PyTorch 分配峰值另列。声称使用第二张 GPU 时需出示该节点实际 KV 占用或链路传输回执。

SGLang 适配是独立模型服务路径。程序可先用 `configure/hot_capacity` 选择已测的原生热容量，再用 `allocate/place` 选择冷 KV 层放置。运行绑定模型、选择器、请求、计算 rank 及实测链路，后端继续管理原生热缓存。不同后端的性能、正确性和场景数据分别呈现。[场景契约](examples/workloads/README.md) · [SGLang 适配](integrations/topology_memory/SGLANG.md) · [模型来源与配置](docs/SG_CONFIGURABLE_RELEASE.md) · [证据方法](docs/RSI_EXECUTION_EVIDENCE_ZH.md)
