"""Render an offline evidence viewer from topology RSI runs and GPU receipts."""

from __future__ import annotations

import argparse
from collections import Counter
from contextlib import closing
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3

from .topology_report_assets import PAGE
from .topology_report_transfer import read_transfer


SCENARIOS = {
    "agent_tools": "Agent · 工具往返",
    "long_document_qa": "LongBench 风格 · 长文问答",
    "chatbot_growth": "Chatbot · 多轮增长",
    "rollout_cow": "Rollout · 分支与写时复制",
}
SHA = re.compile(r"[0-9a-f]{64}")
SGLANG_SCOPE = "real_model_sglang_hisparse_configurable_memory"


def _read(path):
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object in {path.name}")
    return value


def _fingerprint(value):
    data = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)
    return hashlib.sha256(data.encode()).hexdigest()


def _take(value, fields):
    return {key: value[key] for key in fields.split() if key in value} if isinstance(value, dict) else {}


def _number(value):
    return value if type(value) in (int, float) and math.isfinite(value) else None


def _metrics(value, depth=0):
    """Project recorded counters and identifiers without embedding prompts or raw evaluator text."""
    if not isinstance(value, dict) or depth > 3:
        return {}
    projected = {}
    for key, item in value.items():
        if type(item) is bool or _number(item) is not None:
            projected[key] = item
        elif isinstance(item, dict):
            nested = _metrics(item, depth + 1)
            if nested:
                projected[key] = nested
        elif key == "receipts" and isinstance(item, list):
            projected[key] = [value for value in item if isinstance(value, str) and len(value) <= 180]
        elif key == "case_metrics" and isinstance(item, list):
            projected[key] = [_metrics(value, depth + 1) for value in item]
        elif key == "execution_order" and isinstance(item, list):
            projected[key] = [{"block_id": row["block_id"], "order": row["order"]} for row in item
                              if isinstance(row, dict) and isinstance(row.get("block_id"), str)
                              and isinstance(row.get("order"), list)
                              and all(isinstance(label, str) for label in row["order"])]
        elif isinstance(item, str) and len(item) <= 180 and (
            key in {"scope", "status", "score_unit", "receipt", "receipt_id", "job_id", "arm", "fixture_kind",
                    "case_name", "error_type", "failure_category", "block_id", "backend", "evidence", "name", "kind",
                    "experiment_id", "backing"} or key.endswith("_sha256")
        ):
            projected[key] = item
    return projected


def _call(key, value):
    return {"id": key, **_take(value, "status seconds failure"),
            **_take(value.get("input", {}), "harness_sha256"),
            **_take(value.get("input", {}).get("payload", {}), "model max_tokens reasoning_effort"),
            "usage": _metrics(value.get("result", {}).get("usage", {})),
            **_take(value.get("result", {}), "finish_reason")}


def _evaluation(key, value):
    return {"id": key, **_take(value, "status seconds failure"), **_take(value.get("input", {}), "split"),
            **_take(value.get("result", {}), "score feasible"),
            "metrics": _metrics(value.get("result", {}).get("metrics", {}))}


def _pair(key, value):
    return {"id": key, **_take(value, "status seconds failure"),
            **_take(value.get("input", {}), "split block_ids"),
            "arms": {label: {**_take(arm, "feasible score"), "metrics": _metrics(arm.get("metrics")),
                             "samples": [_metrics(sample) for sample in arm.get("samples", [])]}
                     for label, arm in value.get("result", {}).items()}}


def _decision(value):
    return _take(value, "operator parents evidence rule mode") if isinstance(value, dict) else None


def _plan(value):
    return (_take(value, "observed_problem mechanism_change expected_effect falsification training_evidence_ids kind")
            if isinstance(value, dict) else None)


def _recorded_plan(key, value):
    return {"id": key, **_take(value, "arm parent_sha256 proposed_child_sha256 status failure"),
            "decision": _decision(value.get("decision")), "plan": _plan(value.get("plan"))}


def _trial(value):
    if not isinstance(value, dict):
        return None
    program = value.get("program")
    rejection = {key: text[:400] for key, text in _take(value.get("feedback"), "failure_category failure_type failure").items()
                 if isinstance(text, str)}
    return {**_take(value, "id status score failure origin program program_sha256 harness_sha256"),
            "decision": _decision(value.get("decision")), "feedback": _metrics(value.get("feedback")),
            "rejection": rejection,
            "program_hash_matches": _fingerprint(program) == value.get("program_sha256") if program is not None else None}


def _finalist(value):
    if not isinstance(value, dict):
        return None
    return {**_take(value, "score status"), "trial": _trial(value.get("trial"))}


def _task_outputs(value):
    if not isinstance(value, dict):
        raise ValueError("schema 2 round lacks its task output selection")
    effective = value.get("effective_program_sha256_by_raw_program")
    selected, fresh = value.get("selected"), value.get("fresh")
    if (not isinstance(effective, dict) or any(not SHA.fullmatch(k) or not isinstance(v, str) or not SHA.fullmatch(v)
                                               for k, v in effective.items())
            or not isinstance(selected, dict) or set(selected) != {"parent", "child", "fixed"}
            or not isinstance(fresh, dict) or set(fresh) != {"parent", "child", "fixed", "fixed_a", "fixed_b"}):
        raise ValueError("malformed schema 2 task output selection")
    for label, choice in selected.items():
        if (not isinstance(choice, dict) or choice.get("origin") not in {"fresh", "incumbent", "unavailable"}
                or (choice.get("trial") is None) != (choice["origin"] == "unavailable")):
            raise ValueError(f"malformed schema 2 selected output for {label}")
        if choice["origin"] == "incumbent" and choice["trial"] != value.get("fixed_incumbent" if label == "fixed" else "shared_incumbent"):
            raise ValueError(f"schema 2 selected output differs from its incumbent for {label}")
        if choice["origin"] == "fresh" and choice["trial"] != fresh[label]:
            raise ValueError(f"schema 2 selected output differs from its fresh trial for {label}")
    if value.get("parent_incumbent_aa") is not (selected["parent"]["origin"] == "incumbent"):
        raise ValueError("schema 2 A/A flag differs from the selected parent origin")
    def entry(trial):
        result = _trial(trial)
        if result is not None:
            digest = effective.get(result.get("program_sha256"))
            if digest is None:
                raise ValueError("measured task output lacks its effective fingerprint")
            result["effective_program_sha256"] = digest
        return result
    return {"shared_incumbent": entry(value.get("shared_incumbent")), "fixed_incumbent": entry(value.get("fixed_incumbent")),
            "selected": {label: {"origin": choice["origin"], "trial": entry(choice.get("trial"))}
                         for label, choice in selected.items()},
            "fresh": {label: entry(trial) for label, trial in fresh.items()},
            "parent_incumbent_aa": value.get("parent_incumbent_aa"),
            "effective_program_sha256_by_raw_program": effective,
            "fresh_paired_comparison": value.get("fresh_paired_comparison")}


def _round(value, schema):
    result = _take(value, "round active_before active_after proposed_child_sha256 decision reason source_diff "
                          "matched_context_sha256 child_fallback_to_parent previous_admission_reuse "
                          "paired_validation fixed_meta_failure fixed_meta_discarded_sha256 adaptive_meta_plan_id fixed_meta_plan_id")
    for name in ("parent", "child", "fixed"):
        result[name] = [_trial(trial) for trial in value.get(name, [])]
    for name in ("parent_validation", "child_validation"):
        result[name] = _finalist(value.get(name))
    result["fixed_validation"] = [_finalist(item) for item in value.get("fixed_validation", [])]
    result["adaptive_meta_decision"] = _decision(value.get("adaptive_meta_decision"))
    result["fixed_meta_decision"] = _decision(value.get("fixed_meta_decision"))
    result["adaptive_meta_plan"] = _plan(value.get("adaptive_meta_plan"))
    result["fixed_meta_plan"] = _plan(value.get("fixed_meta_plan"))
    result["controlled_behavior"] = {
        name: {"ast_changed": data.get("ast_changed"), "decisions": [
            {**_take(row, "slot changed_fields"), "before": _decision(row.get("before")),
             "after": _decision(row.get("after"))} for row in data.get("decisions", [])]}
        for name, data in (value.get("controlled_behavior") or {}).items()}
    if schema == 2:
        result["task_output_selection"] = _task_outputs(value.get("task_output_selection"))
        result["incumbent_validation"] = _finalist(value.get("incumbent_validation"))
    return result


def _records(directory):
    journal = directory / "journal.sqlite"
    if journal.is_file():
        with closing(sqlite3.connect(journal.resolve().as_uri() + "?mode=ro", uri=True, timeout=3)) as connection:
            connection.execute("PRAGMA query_only=ON")
            rows = connection.execute("SELECT key, data FROM records ORDER BY key").fetchall()
        return {key: json.loads(data) for key, data in rows}, "journal.sqlite"
    report = directory / "report.json"
    exported = _read(report) if report.is_file() else {}
    if not exported:
        manifest = directory / "manifest.json"
        if not manifest.is_file():
            raise ValueError(f"no topology RSI journal, report or manifest in {directory.name}")
        exported = {"manifest": _read(manifest)}
        frozen = directory / "frozen.json"
        if frozen.is_file():
            exported["frozen"] = _read(frozen)
        exported["rounds"] = [_read(path) for path in sorted((directory / "rounds").glob("r*.json"))]
    return {"manifest": exported.get("manifest"), "frozen": exported.get("frozen"),
            "test_comparisons": exported.get("test_comparisons"), "status": exported.get("status"),
            **{f"round/r{row['round']:04d}": row for row in exported.get("rounds", [])},
            **exported.get("calls", {}), **exported.get("evaluations", {}),
            **exported.get("paired_evaluations", {}), **exported.get("meta_plans", {})}, "report.json" if report.is_file() else "JSON checkpoints"


def _source(directory, sha):
    if not isinstance(sha, str) or not SHA.fullmatch(sha):
        return None
    path = directory / "harnesses" / f"{sha}.py"
    if not path.is_file() or not path.resolve().is_relative_to(directory.resolve()):
        return {"status": "missing"}
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != sha:
        return {"status": "hash_mismatch"}
    return {"status": "verified", "source": raw.decode("utf-8")}


def read_run(directory, label=None):
    records, origin = _records(directory)
    manifest = records.get("manifest")
    if not isinstance(manifest, dict) or not isinstance(manifest.get("config"), dict):
        raise ValueError(f"missing topology RSI manifest in {directory.name}")
    schema = manifest.get("schema", 1)
    if type(schema) is not int or schema not in (1, 2):
        raise ValueError(f"unsupported RSI manifest schema in {directory.name}")
    if schema == 2 and manifest.get("task_output_protocol") != "shared_measured_train_incumbent_v1":
        raise ValueError(f"unknown schema 2 output protocol in {directory.name}")
    rows = [value for key, value in records.items() if key.startswith("round/")]
    rows.sort(key=lambda value: value["round"])
    calls = [_call(key, value) for key, value in records.items() if key.startswith("api/")]
    evaluations = [_evaluation(key, value) for key, value in records.items() if key.startswith("eval/")]
    pairs = [_pair(key, value) for key, value in records.items() if key.startswith("pair/")]
    plans = [_recorded_plan(key, value) for key, value in records.items() if key.startswith("plan/")]
    frozen = records.get("frozen")
    frozen_view = None
    if isinstance(frozen, dict):
        frozen_view = {**_take(frozen, "rounds partial active_harness_sha256 native_validation_score "
                                      "manifest_sha256 rounds_sha256 admitted_harness_sha256s reused_harness_sha256s"),
                       "hashes_match": (frozen.get("manifest_sha256") == _fingerprint(manifest)
                                        and frozen.get("rounds_sha256") == _fingerprint(rows)),
                       "adaptive": _finalist(frozen.get("adaptive")), "fixed": _finalist(frozen.get("fixed")),
                       "adaptive_archive_best": _finalist(frozen.get("adaptive_archive_best"))}
    hashes = {manifest.get("seed_sha256")}
    for row in rows:
        hashes.update(row.get(key) for key in ("active_before", "active_after", "proposed_child_sha256"))
    contract = manifest.get("contract", {})
    return {"label": label or directory.name, "origin": origin, "recorded_status": records.get("status"), "schema": schema,
            "manifest_sha256": _fingerprint(manifest), "contract": _metrics(contract),
            "manifest": _take(manifest, "config paired_gate supported_actions started_unix seed_sha256 source_sha256 "
                                        "candidate_slots_per_arm_per_round provider_calls_per_arm_per_round_cap "
                                        "task_output_protocol effective_program_fingerprint validation_arms"),
            "rounds": [_round(row, schema) for row in rows], "frozen": frozen_view,
            "test_comparisons": records.get("test_comparisons"), "calls": calls,
            "evaluations": evaluations, "pairs": pairs, "meta_plans": plans,
            "sources": {sha: _source(directory, sha) for sha in sorted(sha for sha in hashes if isinstance(sha, str))}}


def _case(value, max_actions):
    diagnostic = value.get("diagnostic", {})
    actions = diagnostic.get("actions", [])
    return {**_take(value, "name case_sha256 median_elapsed_ns"),
            "diagnostic": {**_take(diagnostic, "status scope arm fixture_kind schedule_execution elapsed_ns transfer_wall_ns "
                                              "managed_peak_bytes_by_node managed_reserved_bytes_by_node "
                                              "cuda_peak_allocated_bytes_delta_by_node link_bytes shared_bottleneck_bytes "
                                              "live_references_at_end total_fetch_misses workload_sha256 schedule_sha256 "
                                              "program_sha256 topology_sha256 scenario_sha256 selected_and_output_sha256"),
                           "action_count": len(actions),
                           "action_types": dict(Counter(row.get("action", "unknown") for row in actions)),
                           "actions": actions[:max_actions], "semantics": diagnostic.get("semantics", [])},
            "timings_elapsed_ns": [row.get("elapsed_ns") for row in value.get("timings", [])]}


def _serving(value):
    compilation = value.get("memory_compilation", {})
    startup = _take(compilation.get("startup"), "hot_slots rule_index native_reference_override eligible_hot_slots "
                                                "metadata_bytes_reserved_by_node")
    metrics = value.get("metrics", {})
    ranks = [_take(row, "rank layer_tiers hot_slots packed_device_payload_bytes device_physical_rows "
                        "device_logical_row_capacity request_metadata_slots_including_pad hot_metadata_bytes worker_limits "
                        "pinned_host_bytes local_hbm_bytes peer_hbm_bytes relay_workspace_bytes "
                        "selected_miss_payload_bytes_by_tier backup_payload_bytes_by_tier relay torch_cuda_memory")
             for row in metrics.get("ranks", [])]
    return {**_take(value, "arm phase program_sha256 cold_program_sha256 compiled_plan_sha256 failure raw_result_sha256"),
            "case": _take(value.get("case"), "id manifest_sha256 target_sha256 topology_sha256 scenario_sha256 "
                                             "workload_sha256 schedule_sha256"),
            "memory_compilation": {**_take(compilation, "full_program_sha256 cold_program_sha256 placement_rule_indices_in_full_program "
                                                      "metadata_profile_sha256 base_target_sha256 base_topology_sha256 "
                                                      "external_scheduler_sha256 derived_target_sha256 derived_schedule_sha256 "
                                                      "derived_topology_sha256 derived_scenario_sha256 cold_plan_sha256 "
                                                      "total_incremental_bytes_by_node equivalent_to_strong_stock_control"),
                                   "startup": startup},
            "metrics": {**_take(metrics, "effective_schedule_sha256 dispatch_sha256 output_ids_sha256 packed_kv_sha256_by_rank "
                                         "runtime_sha256 input_tokenization_sha256 timing"), "ranks": ranks},
            "feedback": _take(value.get("feedback"), "cold_miss_rows_by_rank_layer kv_log_sha256_by_rank"),
            "cross_capacity_native_parity": _take(value.get("cross_capacity_native_parity"), "reference matched")}


def read_receipt(path, max_actions):
    value = _read(path)
    if value.get("schema") != 2 or not isinstance(value.get("job_id"), str):
        raise ValueError(f"expected a GPU execution v2 receipt in {path.name}")
    result = value.get("result")
    digest_matches = isinstance(result, dict) and value.get("result_canonical_sha256") == _fingerprint(result)
    serving = _serving(result) if digest_matches and result.get("scope") == SGLANG_SCOPE else None
    return {"file": path.name, **_take(value, "job_id status request_sha256 source_manifest_sha256 gpu_indices gpu_uuids "
                                             "utc_start utc_end elapsed_seconds returncode failure timeout environment_conflict "
                                             "result_sha256 result_canonical_sha256 log_sha256 remaining_compute_pids "
                                             "after_query_failure result_failure replayed_receipt process_group_remaining "
                                             "process_group_cleanup_required"),
            "canonical_result_matches": digest_matches if result is not None else None,
            "result": ({**_take(result, "scope score score_unit feasible hardware error_type"),
                        "cases": [_case(case, max_actions) for case in result.get("cases", [])],
                        **({"serving": serving} if serving is not None else {})}
                       if digest_matches else None)}


def _scenario(path, kind=None):
    value = _read(path)
    recorded_kind = value.get("kind")
    if recorded_kind in SCENARIOS and kind not in (None, recorded_kind):
        raise ValueError(f"scenario kind does not match {path.name}")
    if kind in SCENARIOS and {"rank_placement", "attention", "target_sha256", "workload_sha256", "schedule_sha256"} <= value.keys():
        return {"kind": kind, "file": path.name, "binding_sha256": _fingerprint(value),
                "binding": _take(value, "rank_placement attention target_sha256 workload_sha256 schedule_sha256")}
    if recorded_kind not in SCENARIOS:
        raise ValueError(f"unknown scenario kind in {path.name}")
    return {**_take(value, "kind name page_rows"), "file": path.name, "fixture_sha256": _fingerprint(value),
            "segments": len(value.get("segments", [])),
            "events": dict(Counter(row.get("kind", row.get("op", "unknown")) for row in value.get("events", [])))}


def _engineering(path):
    value = _read(path)
    if (value.get("kind") != "single_gpu_engineering_training_qualification" or value.get("gpu_count") != 1
            or value.get("heldout") is not False or value.get("model_generated_outcome") is not False):
        raise ValueError(f"expected a public single-GPU engineering audit in {path.name}")
    return {"file": path.name, "file_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            **_take(value, "scope source_manifest_sha256 preregistration_sha256 receipt_count fresh_process_count paired_blocks "
                           "environment_scope native_lru_link_bytes_and_misses_exact "
                           "exact_case_selected_bytes_and_outputs_across_arms "
                           "matches_v10_case_program_selected_output_actions_traffic_misses_and_managed_peaks"),
            "scopes": {name: _take(row, "median_ms descriptive_comparisons") for name, row in value["scopes"].items()}}


def render(output, *, runs=(), receipts=(), topologies=(), scenarios=(), transfers=(), engineering=(), max_actions=200):
    if not 0 <= max_actions <= 10000:
        raise ValueError("max_actions must be between 0 and 10000")
    graphs = []
    for path in topologies:
        value = _read(path)
        if not isinstance(value.get("nodes"), list) or not isinstance(value.get("links"), list):
            raise ValueError(f"expected topology nodes and links in {path.name}")
        graphs.append({"name": path.name, "sha256": _fingerprint(value),
                       **_take(value, "nodes links bottlenecks")})
    data = {"runs": [read_run(path, label) for label, path in runs],
            "receipts": [read_receipt(path, max_actions) for path in receipts], "topologies": graphs,
            "scenarios": [_scenario(*entry) if isinstance(entry, tuple) else _scenario(entry) for entry in scenarios],
            "transfers": [read_transfer(path) for path in transfers], "engineering": [_engineering(path) for path in engineering],
            "scenario_labels": SCENARIOS}
    embedded = json.dumps(data, ensure_ascii=False, allow_nan=False).replace("&", "\\u0026").replace("<", "\\u003c")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(PAGE.replace("/* EMBEDDED_RUN_DATA */", embedded, 1))
    return data


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run", action="append", default=[], metavar="[LABEL=]DIRECTORY")
    parser.add_argument("--receipt", type=Path, action="append", default=[])
    parser.add_argument("--receipts", type=Path, action="append", default=[], metavar="DIRECTORY")
    parser.add_argument("--topology", type=Path, action="append", default=[])
    parser.add_argument("--scenario", action="append", default=[], metavar="[KIND=]JSON")
    parser.add_argument("--transfer", type=Path, action="append", default=[], metavar="STUDY_DIRECTORY")
    parser.add_argument("--engineering", type=Path, action="append", default=[], metavar="AUDIT_JSON")
    parser.add_argument("--max-actions", type=int, default=200)
    args = parser.parse_args(argv)
    runs = []
    for entry in args.run:
        label, separator, path = entry.partition("=")
        runs.append((label, Path(path)) if separator else (None, Path(entry)))
    receipts = dict.fromkeys([*args.receipt, *(path for directory in args.receipts
                            for path in sorted(directory.glob("*.json")))])
    scenarios = []
    for entry in args.scenario:
        kind, separator, path = entry.partition("=")
        scenarios.append((Path(path), kind) if separator else Path(entry))
    render(args.output, runs=runs, receipts=receipts, topologies=args.topology, scenarios=scenarios,
           transfers=args.transfer, engineering=args.engineering,
           max_actions=args.max_actions)
    print(args.output.resolve())


if __name__ == "__main__":
    main()
