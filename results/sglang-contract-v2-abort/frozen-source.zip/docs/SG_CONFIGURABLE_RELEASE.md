# Configurable SGLang DP2 adapter

The configurable SGLang adapter tests cold KV placement and a bounded startup choice of native hot retention. It uses `inference-optimization/GLM-5.3-0.6B-A0.4B` at revision `20aae340d157bd2215b9d81165be87e94686dfdf`. The publisher randomly initialized this small checkpoint and then fine-tuned it on toy text for architecture testing. The observed replay emits EOS. This serving workload verifies integration and packed KV semantics under fixed inputs. Language quality and representative KV locality for trained models remain outside its scope. [Pinned publisher model card](https://huggingface.co/inference-optimization/GLM-5.3-0.6B-A0.4B/tree/20aae340d157bd2215b9d81165be87e94686dfdf)

`configure/hot_capacity` selects 4,096, 6,144 or 8,192 slots from real native qualification. The default is 4,096. `allocate/place` runs after the compiler reserves the observed metadata increase against the same HBM budget as backing and relay workspace. The engine owns request placement, scheduling, DSA selection and KV lifetimes. The runtime binds actual scheduler limits, selected packed KV, dispatch and output IDs before timing. The named stock comparison for the fixed short replay is native 6,144 with all-host backing.

## Dedicated deployment

Use the qualified Linux environment and bound model files. The worker expects two fixed visible physical GPUs, the source-gated SGLang installation, its DSA kernel and tokenizer dependencies, CUDA 13, and the pinned isolated NCCL 2.32.3 wheel. The launcher verifies the dedicated NCCL tree before adding it to the Python import path. The CUDA worker's general source bundler and this SGLang-specific source packer serve separate environments.

`pack_source.py` uses a closed file allowlist. Run it from source with a private, operator-supplied schema-2 `--launch` file and a new `--output` ZIP. The generated ZIP contains the private launch paths and should stay in the deployment workspace. Publish source separately without launch paths or credentials. The byte-identical `.source-manifest.json` sidecar binds controller configuration to that deployment. The leased supervisor checks its hash, physical CUDA UUIDs, process exit and cleanup. The launcher is executable on the GPU host.

Use three successful raw native parity results for the same public fixture to create the profile with `python -B -m topomem_sglang_rsi.collect_hot_profile`. Each result supplies observed per-rank physical and metadata geometry. Create the controller config with `python -B -m topomem_sglang_rsi.make_config`, the case manifest, frozen tokenization receipt, profile, launch and source identities. The adapter blocks before evaluation without the three measured observations. Pass `--adapter topomem_sglang_rsi.domain:factory` to the controller CLI. The final test is a separate operation after freezing the programs.

An independent [training-only hand-policy sweep](SG_HAND_SWEEP.md) can test whether a same-budget local slab improves on the stock 6,144-slot reference.

Formal SGLang search, hand-control selection and held-out comparisons remain pending. Repeated native probes produced a packed KV mismatch at 6,144 and 8,192 slots under the original arrival handling. A completed probe process or matching output IDs alone is insufficient to qualify a capacity. The frozen byte and replay gates still apply.

The Torch v11 adapter and the SGLang adapter qualify different execution paths. Torch tests dynamic sparse KV operations on fixed text-derived attention fixtures. SGLang tests the actual GLM architecture and startup capacity plus static cold backing. Their performance measurements stay separate. Published claims must follow the qualified runtime and fixed workload of each experiment.
