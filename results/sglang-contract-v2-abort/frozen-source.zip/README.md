# TopoMem RSI

[中文说明](README.zh-CN.md) · [Memory program contract](docs/MEMORY_PROGRAM_CONTRACT_ZH.md) · [Offline report](examples/topology-report/README.md)

TopoMem RSI searches for KV memory programs for a fixed sparse-attention implementation, hardware topology, and workload. The controller can also revise the code that generates those programs and the code that proposes the next revision.

| Task | Output | Evidence |
| --- | --- | --- |
| Generate a memory manager | A bounded `MemoryProgram` with event rules for placement, replication, migration, pressure-driven demotion, prefetch, eviction, and reclamation | Executed actions and data-movement receipts, byte and ownership checks, and paired timing of the resulting program against a frozen reference |
| Improve the generator | Versioned `build_prompt` and `build_meta_prompt` source, with a hypothesis and falsification condition recorded before evaluation | Matched parent–child decisions and results, an admission decision, and subsequent task and meta requests bound to the admitted source digest |

The target fixes attention and token selection, the physical GPU identities and links, capacity, compute ranks, request arrival and ordering, lifetimes, batching, and safe points. Generated code sees training evidence and chooses memory actions. The evaluator owns correctness and scoring. The controller freezes the finalists before opening the test split.

## Status

- **CUDA v6 Agent diagnostic.** One round settled before the run was stopped to correct the generation protocol. Its child changed both function ASTs and made the same structural decisions on that round's matched inputs. It was rejected. Across 12 paired validation blocks the median child score was 146.529 ms and the median write-through/LRU reference score was 120.898 ms. The reference was faster in all 12 blocks. All five measured arms had zero managed KV on the second GPU. The local audit covers 66 result receipts and preserves the partial next round. [v6 audit](results/cuda-rsi-v6/agent_tools/AUDIT_R0_ZH.md)
- **CUDA v7 Agent search.** All six DeepSeek rounds and 12 held-out blocks settled. R2 was the sole source admission. Its program recovered earlier behavior and beat the fresh parent in 12/12 validation blocks, with a +126.658 ms paired median gain, while losing all 12 to the CUDA write-through/LRU reference. The admitted source then drove nine actual task and meta requests across R3–R5. The frozen adaptive manager came from the original generator in R0. It lost 12/12 held-out blocks to the CUDA reference, with a −29.172 ms paired median gain, and won 6/12 against the fixed generator, with a −0.142 ms paired median gain. The source admission and reuse are distinct from the held-out manager result. [v7 audit](results/cuda-rsi-v7/agent_tools/AUDIT_PROGRESS_ZH.md)
- **Separate serving integration.** The SGLang HiSparse adapter implements startup `configure/hot_capacity` and `allocate/place` for cold KV layer placement. Formal recursive results and the training-selected hand comparison are pending qualification. The preregistration uses two rounds, six validation blocks and twelve test blocks. Its tiny architecture-test checkpoint was randomly initialized and fine-tuned on toy text. The observed replay emits EOS IDs. The serving checks cover actual packed KV rows, output IDs and dispatch. Model quality and representative KV locality for trained models are outside this workload's scope. [SGLang adapter and qualification procedure](integrations/topology_memory/SGLANG.md) · [Model and protocol](docs/SG_CONFIGURABLE_RELEASE.md) · [Hand control and budget](docs/SG_HAND_SWEEP.md)
- **Stock SGLang probes.** A TP2 backbone with attention DP2 verified one routed request per attention rank and eight local query heads on each rank. A separate stock UnifiedRadixCache probe verified 1,536 physically shared prefix rows and disjoint 128-row suffixes for each of two branches. The recorded cached and isolated outputs in the radix fixture consist of EOS IDs. [SGLang qualification evidence](results/sglang-qualification/evidence_manifest.json)

## Build and qualify

Python 3.10 or newer is required. The controller and offline report use the standard library. The CUDA evaluator runs in a CUDA-enabled PyTorch environment on the execution host. The SGLang adapter has its own runtime requirements.

```sh
python -m pip install -e .
python -B -m unittest discover -s tests
```

Build a reproducible source-only CUDA deployment bundle.

```sh
python -B -m rsi_memory.source_bundle --output deploy/cuda-source.zip
```

Unpack it into a fresh source directory under the worker's experiment root. Pin the reported `source_manifest_sha256` in the experiment input. The manifest covers the archive's source files and fixtures by relative path. On the target GPU host, measure its directed pinned-host copies using `python -B -m integrations.topology_memory.torch_profile --output link-profile.json`. Configure the execution client with the target's SSH configuration, worker and Python locations, GPU ordinals and UUIDs, and pinned source. Keep local configuration and provider credentials outside the shared source and reports.

The case builder reads the measured profile, topology, fixed workload content, and control programs. Its input keys and topology requirements are described in the [Chinese guide](README.zh-CN.md#准备本地配置).

```sh
python -B -m rsi_memory.experiment_cases --inputs private-build-inputs.json --output sealed-configs
```

## Run, freeze, test

In Bash, point `args` at a new output directory and one sealed scenario config. Set `OPENCODE_GO_API_KEY` in the controller's environment before running discovery.

```bash
args=(--output runs/agent_tools/controller
      --adapter rsi_memory.cuda_domain:factory
      --adapter-config sealed-configs/agent_tools.json
      --model deepseek-v4.1-flash --rounds 6 --slots 2 --max-output-tokens 65536
      --min-paired-blocks 12 --min-improvement 0.5 --wall-seconds 43200)
python -B -m rsi_memory.topology_rsi run "${args[@]}"
```

After discovery settles, review the journal and freeze the primary and fixed-generator finalists. Then run the separate held-out test with the same configuration.

```bash
python -B -m rsi_memory.topology_rsi freeze "${args[@]}"
python -B -m rsi_memory.topology_rsi test "${args[@]}"
```

The journal keeps failed and interrupted attempts. Resuming requires the same source and run contract. An attempt with an unknown outcome is preserved as unknown. The primary finalist comes from the seed or admitted generator lineage. The unrestricted archive best is recorded separately at validation scope.

## Inspect actual evidence

Point the viewer at the run directory and its locally recorded execution receipts. The viewer writes one offline HTML file and reads the journal in read-only mode.

```sh
python -B -m rsi_memory.topology_report \
  --run Agent=runs/agent_tools/controller --receipts runs/agent_tools/receipts \
  --scenario examples/workloads/agent-water-inspection.json \
  --scenario examples/workloads/long-document-estuary-qa.json \
  --scenario examples/workloads/chatbot-trip-planning.json \
  --scenario examples/workloads/rollout-bridge-options.json \
  --output agent-evidence.html
```

Use `--transfer` for a separate transfer-study directory and `--engineering` for an engineering audit JSON. The viewer keeps measured results, preregistration, and pending phases labeled separately.

The CUDA evaluator executes text-derived block-sparse attention with real CUDA allocations and data movement. Its `native_lru` arm is the project's write-through/LRU reference. Its objective sums each case's median elapsed milliseconds, including immutable block materialization during decode appends and any resulting whole-block moves. The authored Agent, long-document QA, chatbot, and rollout fixtures test different lifecycles. The long-document fixture uses a LongBench-style task form. Report CUDA evaluator and model-serving results under their own scopes. [Workload contracts](examples/workloads/README.md) · [Framework audit](docs/RSI_FRAMEWORK_REEVALUATION_20261110_ZH.md)
